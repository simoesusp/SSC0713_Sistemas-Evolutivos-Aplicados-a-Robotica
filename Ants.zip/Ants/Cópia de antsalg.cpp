//---------------------------------------------------------------------------

// virar 180 graus?!
// seguir ferom�nio no estado 3 (vai ficar nas bordas)

#pragma hdrstop

#include "main.h"
#include "antsalg.h"
#include <stdlib.h>
#include <string.h>
#include <math.h>

//---------------------------------------------------------------------------

#pragma package(smart_init)

#define RAND_MAX 2147483647

int WIDTH;
int HEIGHT;

SFormiga *F;
int **Formiga;
int **Casa;
int **Comida;
int **F1;
int **Obstaculo;
int Updates=0;
int id_formigas=1;
int *prob_virar;
float converteangulo[72][2];
int quantidade_comida;
int INTERACOES;
int RateF1, IntervalF1;
int estado1_FollowF1, estado2_FollowF1;
int estado1_FollowF1ThrMin, estado2_FollowF1ThrMin;
int estado1_FollowF1ThrMax, estado2_FollowF1ThrMax;
int estado1_AgainstF1, estado2_AgainstF1;
int estado1_AgainstF1ThrMin, estado2_AgainstF1ThrMin;
int estado1_AgainstF1ThrMax, estado2_AgainstF1ThrMax;
int estado1_FoodDeposit, estado2_FoodDeposit;
int estado1_RaioSensor, estado2_RaioSensor;
int estado1_PosSensor, estado2_PosSensor;
int estado1_Time, estado2_Time;
bool HardFollow;
int ProbExplorar;
int anguloParaVirar;
float decay;

float tabelapow[256];

//---------------------------------------------------------------------------
void __fastcall prepara() {
        int i;

        for(i=0; i<72; i++) {
                converteangulo[i][0] = (int)(cos(M_PI/(180.0/((i+1)*5.0)))*10000.0 + 0.5);
                converteangulo[i][1] = (int)(sin(M_PI/(180.0/((i+1)*5.0)))*10000.0 + 0.5);
        }
}
//---------------------------------------------------------------------------


void __fastcall configurar(int _WIDTH, int _HEIGHT, int *_prob_virar, int _RateF1, int _IntervalF1, int _estado1_FoodDeposit, int _estado2_FoodDeposit, int _estado1_FollowF1, int _estado2_FollowF1, int _estado1_FollowF1ThrMin, int _estado2_FollowF1ThrMin, int _estado1_FollowF1ThrMax, int _estado2_FollowF1ThrMax, int _estado1_AgainstF1, int _estado2_AgainstF1, int _estado1_AgainstF1ThrMin, int _estado2_AgainstF1ThrMin, int _estado1_AgainstF1ThrMax, int _estado2_AgainstF1ThrMax, int _estado1_Time, int _estado2_Time, int _estado1_RaioSensor, int _estado2_RaioSensor, int _estado1_PosSensor, int _estado2_PosSensor, int _id_formigas, SFormiga *_F, int **_Formiga, int **_Casa, int **_Comida, int **_F1, int **_Obstaculo, bool _HardFollow, int _ProbExplorar, int _anguloParaVirar, float _decay) {
        int i;

	WIDTH = _WIDTH;
	HEIGHT = _HEIGHT;
        prob_virar = _prob_virar;
	RateF1 = _RateF1;
	IntervalF1 = _IntervalF1;
	estado1_FoodDeposit = _estado1_FoodDeposit;
	estado2_FoodDeposit = _estado2_FoodDeposit;
	estado1_FollowF1 = _estado1_FollowF1;
	estado2_FollowF1 = _estado2_FollowF1;
	estado1_FollowF1ThrMin = _estado1_FollowF1ThrMin;
	estado2_FollowF1ThrMin = _estado2_FollowF1ThrMin;
	estado1_FollowF1ThrMax = _estado1_FollowF1ThrMax;
	estado2_FollowF1ThrMax = _estado2_FollowF1ThrMax;
	estado1_AgainstF1 = _estado1_AgainstF1;
	estado2_AgainstF1 = _estado2_AgainstF1;
	estado1_AgainstF1ThrMin = _estado1_AgainstF1ThrMin;
	estado2_AgainstF1ThrMin = _estado2_AgainstF1ThrMin;
	estado1_AgainstF1ThrMax = _estado1_AgainstF1ThrMax;
	estado2_AgainstF1ThrMax = _estado2_AgainstF1ThrMax;
	estado1_Time = _estado1_Time;
	estado2_Time = _estado2_Time;
	estado1_RaioSensor = _estado1_RaioSensor;
	estado2_RaioSensor = _estado2_RaioSensor;
	estado1_PosSensor = _estado1_PosSensor;
	estado2_PosSensor = _estado2_PosSensor;
	id_formigas = _id_formigas;
	F = _F;
	Formiga = _Formiga;
	Casa = _Casa;
	Comida = _Comida;
	F1 = _F1;
	Obstaculo = _Obstaculo;
        HardFollow = _HardFollow;
        ProbExplorar = _ProbExplorar;
        anguloParaVirar = _anguloParaVirar;
        decay = _decay;

        for(i=0; i<256; i++) {
                tabelapow[i] = pow(decay,i);
        }
}
//---------------------------------------------------------------------------

int __fastcall vira(int forcar) {
        int i;
        int r;
        int total=0;

        if (forcar) {
                for(i=1; i<7; i++) {
                        total += prob_virar[i];
                }

                r = (int)(rand()%(total+1));

                total = 0;
                for(i=1; i<7; i++) {
                        total+=prob_virar[i];
                        if (total >= r) {
                                return ((i <= 3) ? i : (75-i));
                        }
                }
        }
        else {
                r = (int)(rand()%1000);
                
                for(i=0; i<7; i++) {
                        total+=prob_virar[i];
                        if (total >= r) {
                                return ((i <= 3) ? i : (75-i));
                        }
                }
        }

        return ((i <= 3) ? i : (75-i));
}
//---------------------------------------------------------------------------

void __fastcall antstep(int *x, int *y, int *erroxy, int dirx, int diry) {
        int xstep, ystep;

	if (abs(dirx) > abs(diry)) {
		xstep = ((dirx >= 0) ? 1 : -1);
		ystep = ((diry >= 0) ? 1 : -1);
		dirx = abs(dirx);
		diry = abs(diry);

		*x += xstep;

		*erroxy += diry;
		if (2*(*erroxy) >= dirx) {
			*y += ystep;
			*erroxy -= dirx;
		}
	}
	else {
		xstep = ((dirx >= 0) ? 1 : -1);
		ystep = ((diry >= 0) ? 1 : -1);
		dirx = abs(dirx);
		diry = abs(diry);

		*y += ystep;

		*erroxy += dirx;
		if (2*(*erroxy) >= diry) {
			*x += xstep;
			*erroxy -= diry;
		}
	}
}

void __fastcall coberturaF1(int x, int y, int dirx, int diry, int raio, int pos, int lado, int *comidaLado, int *casaLado, int *F1Lado) {
        int i, j;
        int tmp;
        int erroxy=0;
        int andado;

        *comidaLado = 0;
        *casaLado = 0;
        *F1Lado = 0;

        pos = -raio/2+pos;

        // direita
        if (lado == 0) {
		tmp = dirx;
		dirx = -diry;
		diry = tmp;

                antstep(&x, &y, &erroxy, dirx, diry);
                if ((x >= 0) && (x <= WIDTH-1) && (y >= 0) && (y <= HEIGHT-1)) {
                        *comidaLado += Comida[x][y];
                        *casaLado += Casa[x][y];
                        *F1Lado += F1[x][y];
//Form1->Chao->Canvas->Pixels[x][y] = RGB(200, 200, 220);
//Form1->Chao->Refresh();
                }

		tmp = dirx;
		dirx = diry;
		diry = -tmp;


		for(i=0; i<raio+pos; i++) {
			antstep(&x, &y, &erroxy, dirx, diry);
                        if ((x >= 0) && (x <= WIDTH-1) && (y >= 0) && (y <= HEIGHT-1)) {
                                if (Obstaculo[x][y]) {
                                        break;
                                }

                                *comidaLado += Comida[x][y];
                                *casaLado += Casa[x][y];
                                *F1Lado += F1[x][y]*tabelapow[i];
//Form1->Chao->Canvas->Pixels[x][y] = RGB(200, 200, 220);
//Form1->Chao->Refresh();
                        }
		}

		dirx = -dirx;
		diry = -diry;

		for(i=0; i<raio; i++) {
			antstep(&x, &y, &erroxy, dirx, diry);
                        if ((x >= 0) && (x <= WIDTH-1) && (y >= 0) && (y <= HEIGHT-1)) {
                                if (Obstaculo[x][y]) {
                                        break;
                                }

                                *comidaLado += Comida[x][y];
                                *casaLado += Casa[x][y];
                                *F1Lado += F1[x][y]*tabelapow[i];
//Form1->Chao->Canvas->Pixels[x][y] = RGB(200, 200, 220);
//Form1->Chao->Refresh();
                        }
		}

		for(j=0; j<raio/2-1; j++) {
			tmp = dirx;
			if (j % 2 == 0) {
				dirx = diry;
				diry = -tmp;
			}
			else {
				dirx = -diry;
				diry = tmp;
			}

			antstep(&x, &y, &erroxy, dirx, diry);
                        if ((x >= 0) && (x <= WIDTH-1) && (y >= 0) && (y <= HEIGHT-1)) {
                                *comidaLado += Comida[x][y];
                                *casaLado += Casa[x][y];
                                *F1Lado += F1[x][y]*tabelapow[j];
//Form1->Chao->Canvas->Pixels[x][y] = RGB(200, 200, 220);
                        }

			tmp = dirx;
			if (j % 2 == 0) {
				dirx = diry;
				diry = -tmp;
			}
			else {
				dirx = -diry;
				diry = tmp;
			}

			for(i=0; i<raio; i++) {
				antstep(&x, &y, &erroxy, dirx, diry);
                                if ((x >= 0) && (x <= WIDTH-1) && (y >= 0) && (y <= HEIGHT-1)) {
                                        if (Obstaculo[x][y]) {
                                                break;
                                        }

                                        *comidaLado += Comida[x][y];
                                        *casaLado += Casa[x][y];
                                        *F1Lado += F1[x][y]*tabelapow[decay,(i+j)];
//Form1->Chao->Canvas->Pixels[x][y] = RGB(200, 200, 220);
//Form1->Chao->Refresh();
                                }
			}
		}
	}
        else {        //esquerda
		tmp = dirx;
		dirx = diry;
		diry = -tmp;

                antstep(&x, &y, &erroxy, dirx, diry);
                if ((x >= 0) && (x <= WIDTH-1) && (y >= 0) && (y <= HEIGHT-1)) {
                        *comidaLado += Comida[x][y];
                        *casaLado += Casa[x][y];
                        *F1Lado += F1[x][y];
//Form1->Chao->Canvas->Pixels[x][y] = RGB(220, 200, 200);
//Form1->Chao->Refresh();
                }

		tmp = dirx;
		dirx = -diry;
		diry = tmp;

		for(i=0; i<raio+pos; i++) {
			antstep(&x, &y, &erroxy, dirx, diry);
                        if ((x >= 0) && (x <= WIDTH-1) && (y >= 0) && (y <= HEIGHT-1)) {
                                if (Obstaculo[x][y]) {
                                        break;
                                }

                                *comidaLado += Comida[x][y];
                                *casaLado += Casa[x][y];
                                *F1Lado += F1[x][y]*tabelapow[i];
//Form1->Chao->Canvas->Pixels[x][y] = RGB(220, 200, 200);
//Form1->Chao->Refresh();
                        }
		}

		dirx = -dirx;
		diry = -diry;

		for(i=0; i<raio; i++) {
			antstep(&x, &y, &erroxy, dirx, diry);
                        if ((x >= 0) && (x <= WIDTH-1) && (y >= 0) && (y <= HEIGHT-1)) {
                                if (Obstaculo[x][y]) {
                                        break;
                                }

                                *comidaLado += Comida[x][y];
                                *casaLado += Casa[x][y];
                                *F1Lado += F1[x][y]*tabelapow[i];
//Form1->Chao->Canvas->Pixels[x][y] = RGB(220, 200, 200);
//Form1->Chao->Refresh();
                        }
		}

		for(j=0; j<raio/2-1; j++) {
			tmp = dirx;
			if (j % 2 == 0) {
				dirx = -diry;
				diry = tmp;
			}
			else {
				dirx = diry;
				diry = -tmp;
			}

			antstep(&x, &y, &erroxy, dirx, diry);
                        if ((x >= 0) && (x <= WIDTH-1) && (y >= 0) && (y <= HEIGHT-1)) {
                                if (Obstaculo[x][y]) {
                                        break;
                                }

                                *comidaLado += Comida[x][y];
                                *casaLado += Casa[x][y];
                                *F1Lado += F1[x][y]*tabelapow[j];
//Form1->Chao->Canvas->Pixels[x][y] = RGB(220, 200, 200);
//Form1->Chao->Refresh();
                        }

			tmp = dirx;
			if (j % 2 == 0) {
				dirx = -diry;
				diry = tmp;
			}
			else {
				dirx = diry;
				diry = -tmp;
			}

			for(i=0; i<raio; i++) {
				antstep(&x, &y, &erroxy, dirx, diry);
                                if ((x >= 0) && (x <= WIDTH-1) && (y >= 0) && (y <= HEIGHT-1)) {
                                        if (Obstaculo[x][y]) {
                                                break;
                                        }
                                                   
                                        *comidaLado += Comida[x][y];
                                        *casaLado += Casa[x][y];
                                        *F1Lado += F1[x][y]*tabelapow[(i+j)];
//Form1->Chao->Canvas->Pixels[x][y] = RGB(220, 200, 200);
//Form1->Chao->Refresh();
                                }
       			}
		}
        }

//if (Form1->SpeedButton4->Down) { Form1->Chao->Refresh(); }
}
//---------------------------------------------------------------------------
int __fastcall fitness(int INTERACOES) {
        int a;
        int f, i, j;

        int xstep, ystep;
        int meudirx, meudiry;
        int meux, meuy;
        int xanterior, yanterior;
        int sorteio;
        int F1Esq, F1Dir;
        int casaEsq, casaDir;
        int comidaEsq, comidaDir;

//        quantidade_comida = (30-prob_virar[1])*prob_virar[1] - (50+prob_virar[2])*prob_virar[2] + 3*prob_virar[3];
//max: 465
//        return quantidade_comida;

                quantidade_comida = 0;
                for(a=0; a<INTERACOES; a++) {
                                for(f=0;f<id_formigas;f++) {
					checaestado:

                                        // BUSCANDO COMIDA (EXPLORANDO)
                                        // Ideia:
                                        // pouco feromonio
                                        // foge feromonio
                                        // raio do sensor simetrico
                                        if (F[f].estado==1) {
                                                if (F[f].contadorCasa++ > estado1_Time) {
							F[f].estado = 4;
                                                        F[f].angulo = (F[f].angulo+anguloParaVirar)%72;

							goto checaestado;
                                                }

						if (Comida[F[f].x][F[f].y]) {
                                                        F[f].contadorComida = 0;
							F[f].estado = 2;
                                                        F[f].angulo = (F[f].angulo+anguloParaVirar)%72;

							goto checaestado;

						}

                                                coberturaF1(F[f].x, F[f].y, F[f].dirx, F[f].diry, estado1_RaioSensor, estado1_PosSensor, 1, &comidaEsq, &casaEsq, &F1Esq);
                                                coberturaF1(F[f].x, F[f].y, F[f].dirx, F[f].diry, estado1_RaioSensor, estado1_PosSensor, 0, &comidaDir, &casaDir, &F1Dir);

                                                if (comidaEsq > comidaDir) {
                                                        F[f].angulo = (F[f].angulo+70)%72;
                                                }
                                                else if (comidaEsq < comidaDir) {
                                                        F[f].angulo = (F[f].angulo+2)%72;
                                                }
                                                else {
                                                        sorteio = rand() % 1000;
                                	                if (sorteio < estado1_FollowF1) {
                                                                if ((abs(F1Esq - F1Dir) >= estado1_FollowF1ThrMin) && (abs(F1Esq - F1Dir) <= estado1_FollowF1ThrMax)) {
                                                                        if (HardFollow) sorteio = (F1Esq > F1Dir) ? F1Esq - 1 : F1Dir;
                                                                        else sorteio = rand()%(F1Esq+F1Dir+1);
                	                                                if (sorteio < F1Esq+1) {
                                        	                                F[f].angulo = (F[f].angulo+70)%72;
                                                        	        }
                                                	                else {
                                                                        	F[f].angulo = (F[f].angulo+2)%72;
                        	                                        }
                                                                }
        	                                        }
                                	                else if (sorteio < estado1_FollowF1+estado1_AgainstF1) {
                                                                if ((abs(F1Esq - F1Dir) >= estado1_AgainstF1ThrMin) && (abs(F1Esq - F1Dir) <= estado1_AgainstF1ThrMax)) {
                                                                        if (HardFollow) sorteio = (F1Esq > F1Dir) ? F1Esq - 1 : F1Dir;
                                                                        else sorteio = rand()%(F1Esq+F1Dir+1);

                	                                                if (sorteio < F1Esq+1) {
                                        	                                F[f].angulo = (F[f].angulo+2)%72;
                                                        	        }
                                                	                else {
                                                                        	F[f].angulo = (F[f].angulo+70)%72;
                        	                                        }
                                                                }
        	                                        }
                                                        else {
                                                                F[f].angulo = (F[f].angulo+vira(0))%72;
                                                        }
                                                }

                                                if (F1[F[f].x+1][F[f].y+1] <= 10000) F1[F[f].x+1][F[f].y+1] += estado1_FoodDeposit>>2;
                                                if (F1[F[f].x+1][F[f].y+0] <= 10000) F1[F[f].x+1][F[f].y+0] += estado1_FoodDeposit>>2;
                                                if (F1[F[f].x+1][F[f].y-1] <= 10000) F1[F[f].x+1][F[f].y-1] += estado1_FoodDeposit>>2;
                                                if (F1[F[f].x+0][F[f].y+1] <= 10000) F1[F[f].x+0][F[f].y+1] += estado1_FoodDeposit>>2;
                                                if (F1[F[f].x+0][F[f].y+0] <= 10000) F1[F[f].x+0][F[f].y+0] += estado1_FoodDeposit>>1;
                                                if (F1[F[f].x+0][F[f].y-1] <= 10000) F1[F[f].x-0][F[f].y-1] += estado1_FoodDeposit>>2;
                                                if (F1[F[f].x-1][F[f].y+1] <= 10000) F1[F[f].x-1][F[f].y+1] += estado1_FoodDeposit>>2;
                                                if (F1[F[f].x-1][F[f].y+0] <= 10000) F1[F[f].x-1][F[f].y+0] += estado1_FoodDeposit>>2;
                                                if (F1[F[f].x-1][F[f].y-1] <= 10000) F1[F[f].x-1][F[f].y-1] += estado1_FoodDeposit>>2;
                                        }
                                        // COM COMIDA (LEVAR AO NINHO)
                                        // Ideia:
                                        // muito feromonio
                                        // segue feromonio
                                        // raio do sensor frontal
                                        else if (F[f].estado==2) {
                                                if (F[f].contadorComida++ > estado2_Time) {
							F[f].estado = 3;
                                                        F[f].angulo = (F[f].angulo+anguloParaVirar)%72;

							goto checaestado;
                                                }

						if (Casa[F[f].x][F[f].y]) {
                                                        F[f].contadorCasa = 0;
                                                        F[f].contadorComida = 0;

							F[f].estado = 4;
                                                        F[f].angulo = (F[f].angulo+anguloParaVirar)%72;

                                                        F[f].dirx = converteangulo[F[f].angulo][0];
                                                        F[f].diry = converteangulo[F[f].angulo][1];
                                                        while(Casa[F[f].x][F[f].y]) {
                                                                Formiga[F[f].x][F[f].y]=0;
                                                                antstep(&F[f].x, &F[f].y, &F[f].erroxy, F[f].dirx, F[f].diry);
                                                                Formiga[F[f].x][F[f].y]=1;
                                                        }

                                                        quantidade_comida++;
							goto checaestado;
						}

                                                coberturaF1(F[f].x, F[f].y, F[f].dirx, F[f].diry, estado2_RaioSensor, estado2_PosSensor, 1, &comidaEsq, &casaEsq, &F1Esq);
                                                coberturaF1(F[f].x, F[f].y, F[f].dirx, F[f].diry, estado2_RaioSensor, estado2_PosSensor, 0, &comidaDir, &casaDir, &F1Dir);

                                                if (casaEsq > casaDir) {
                                                        F[f].angulo = (F[f].angulo+70)%72;
                                                }
                                                else if (casaEsq < casaDir) {
                                                        F[f].angulo = (F[f].angulo+2)%72;
                                                }
                                                else {
                                                        sorteio = rand() % 1000;

                                	                if (sorteio < estado2_FollowF1) {
                                                                if ((abs(F1Esq - F1Dir) >= estado2_FollowF1ThrMin) && (abs(F1Esq - F1Dir) <= estado2_FollowF1ThrMax)) {
                                                                        if (HardFollow) sorteio = (F1Esq > F1Dir) ? F1Esq - 1 : F1Dir;
                                                                        else sorteio = rand()%(F1Esq+F1Dir+1);

                	                                                if (sorteio < F1Esq+1) {
                                                                        	F[f].angulo = (F[f].angulo+70)%72;
                                                        	        }
                                                	                else {
                                        	                                F[f].angulo = (F[f].angulo+2)%72;
                        	                                        }
                                                                }
        	                                        }
                                	                else if (sorteio < estado2_FollowF1+estado2_AgainstF1) {
                                                                if ((abs(F1Esq - F1Dir) >= estado2_AgainstF1ThrMin) && (abs(F1Esq - F1Dir) <= estado2_AgainstF1ThrMax)) {
                                                                        if (HardFollow) sorteio = (F1Esq > F1Dir) ? F1Esq - 1 : F1Dir;
                                                                        else sorteio = rand()%(F1Esq+F1Dir+1);

                	                                                if (sorteio < F1Esq+1) {
                                                                        	F[f].angulo = (F[f].angulo+2)%72;
                                                        	        }
                                                	                else {
                                        	                                F[f].angulo = (F[f].angulo+70)%72;
                        	                                        }
                                                                }
        	                                        }
                                                        else {
                                                                F[f].angulo = (F[f].angulo+vira(0))%72;
                                                        }
                                                }

                                                if (F1[F[f].x+1][F[f].y+1] <= 10000) F1[F[f].x+1][F[f].y+1] += estado2_FoodDeposit>>2;
                                                if (F1[F[f].x+1][F[f].y+0] <= 10000) F1[F[f].x+1][F[f].y+0] += estado2_FoodDeposit>>2;
                                                if (F1[F[f].x+1][F[f].y-1] <= 10000) F1[F[f].x+1][F[f].y-1] += estado2_FoodDeposit>>2;
                                                if (F1[F[f].x+0][F[f].y+1] <= 10000) F1[F[f].x+0][F[f].y+1] += estado2_FoodDeposit>>2;
                                                if (F1[F[f].x+0][F[f].y+0] <= 10000) F1[F[f].x+0][F[f].y+0] += estado2_FoodDeposit>>1;
                                                if (F1[F[f].x+0][F[f].y-1] <= 10000) F1[F[f].x-0][F[f].y-1] += estado2_FoodDeposit>>2;
                                                if (F1[F[f].x-1][F[f].y+1] <= 10000) F1[F[f].x-1][F[f].y+1] += estado2_FoodDeposit>>2;
                                                if (F1[F[f].x-1][F[f].y+0] <= 10000) F1[F[f].x-1][F[f].y+0] += estado2_FoodDeposit>>2;
                                                if (F1[F[f].x-1][F[f].y-1] <= 10000) F1[F[f].x-1][F[f].y-1] += estado2_FoodDeposit>>2;
                                        }
                                        // SE PERDEU (COM COMIDA)
                                        // Ideia:
                                        // pouco feromonio
                                        // segue feromonio
                                        // raio do sensor frontal
                                        else if (F[f].estado==3) {
						if (Casa[F[f].x][F[f].y]) {
							F[f].estado = 4;

                                                        if (rand() % 2 == 0) F[f].angulo = (F[f].angulo+anguloParaVirar)%72;
                                                        else F[f].angulo = (F[f].angulo+(72-anguloParaVirar))%72;

                                                        F[f].contadorCasa = 0;

//							goto checaestado;
						}

                                                if (rand() % ProbExplorar == 0) {
                                                        F[f].estado = 1;

                                                        F[f].contadorCasa = 0;
                                                        F[f].contadorComida = 0;

                                                        goto checaestado;
                                                }

                                                coberturaF1(F[f].x, F[f].y, F[f].dirx, F[f].diry, estado2_RaioSensor, estado2_PosSensor, 1, &comidaEsq, &casaEsq, &F1Esq);
                                                coberturaF1(F[f].x, F[f].y, F[f].dirx, F[f].diry, estado2_RaioSensor, estado2_PosSensor, 0, &comidaDir, &casaDir, &F1Dir);

                                                if (casaEsq > casaDir) {
                                                        F[f].angulo = (F[f].angulo+70)%72;
                                                }
                                                else if (casaEsq < casaDir) {
                                                        F[f].angulo = (F[f].angulo+2)%72;
                                                }
                                                else {
                                                        sorteio = rand() % 1000;
                                	                if (sorteio < estado2_FollowF1) {
                                                                if ((abs(F1Esq - F1Dir) >= estado2_FollowF1ThrMin) && (abs(F1Esq - F1Dir) <= estado2_FollowF1ThrMax)) {
                                                                        if (HardFollow) sorteio = (F1Esq > F1Dir) ? F1Esq - 1 : F1Dir;
                                                                        else sorteio = rand()%(F1Esq+F1Dir+1);

                	                                                if (sorteio < F1Esq+1) {
                                                                        	F[f].angulo = (F[f].angulo+70)%72;
                                                        	        }
                                                	                else {
                                        	                                F[f].angulo = (F[f].angulo+2)%72;
                        	                                        }
                                                                }
        	                                        }
                                	                else if (sorteio < estado2_FollowF1+estado2_AgainstF1) {
                                                                if ((abs(F1Esq - F1Dir) >= estado2_AgainstF1ThrMin) && (abs(F1Esq - F1Dir) <= estado2_AgainstF1ThrMax)) {
                                                                        if (HardFollow) sorteio = (F1Esq > F1Dir) ? F1Esq - 1 : F1Dir;
                                                                        else sorteio = rand()%(F1Esq+F1Dir+1);

                	                                                if (sorteio < F1Esq+1) {
                                                                        	F[f].angulo = (F[f].angulo+2)%72;
                                                        	        }
                                                	                else {
                                        	                                F[f].angulo = (F[f].angulo+70)%72;
                        	                                        }
                                                                }
                                                        }
                                                        else {
                                                                F[f].angulo = (F[f].angulo+vira(0))%72;
                                                        }
                                                }

                                                if (F1[F[f].x+1][F[f].y+1] <= 10000) F1[F[f].x+1][F[f].y+1] += estado1_FoodDeposit>>2;
                                                if (F1[F[f].x+1][F[f].y+0] <= 10000) F1[F[f].x+1][F[f].y+0] += estado1_FoodDeposit>>2;
                                                if (F1[F[f].x+1][F[f].y-1] <= 10000) F1[F[f].x+1][F[f].y-1] += estado1_FoodDeposit>>2;
                                                if (F1[F[f].x+0][F[f].y+1] <= 10000) F1[F[f].x+0][F[f].y+1] += estado1_FoodDeposit>>2;
                                                if (F1[F[f].x+0][F[f].y+0] <= 10000) F1[F[f].x+0][F[f].y+0] += estado1_FoodDeposit>>1;
                                                if (F1[F[f].x+0][F[f].y-1] <= 10000) F1[F[f].x-0][F[f].y-1] += estado1_FoodDeposit>>2;
                                                if (F1[F[f].x-1][F[f].y+1] <= 10000) F1[F[f].x-1][F[f].y+1] += estado1_FoodDeposit>>2;
                                                if (F1[F[f].x-1][F[f].y+0] <= 10000) F1[F[f].x-1][F[f].y+0] += estado1_FoodDeposit>>2;
                                                if (F1[F[f].x-1][F[f].y-1] <= 10000) F1[F[f].x-1][F[f].y-1] += estado1_FoodDeposit>>2;
                                        }
                                        // SE PERDEU (SEM COMIDA)
                                        // Ideia:
                                        // pouco feromonio
                                        // segue feromonio
                                        // raio do sensor frontal
                                        else if (F[f].estado==4) {
                                                if (Comida[F[f].x][F[f].y]) {
							F[f].estado = 2;

                                                        if (rand() % 2 == 0) F[f].angulo = (F[f].angulo+anguloParaVirar)%72;
                                                        else F[f].angulo = (F[f].angulo+(72-anguloParaVirar))%72;

                                                        F[f].contadorComida = 0;

							goto checaestado;
						}

                                                if (rand() % ProbExplorar == 0) {
                                                        F[f].estado = 1;

                                                        F[f].contadorCasa = 0;
                                                        F[f].contadorComida = 0;

                                                        goto checaestado;
                                                }

                                                coberturaF1(F[f].x, F[f].y, F[f].dirx, F[f].diry, estado2_RaioSensor, estado2_PosSensor, 1, &comidaEsq, &casaEsq, &F1Esq);
                                                coberturaF1(F[f].x, F[f].y, F[f].dirx, F[f].diry, estado2_RaioSensor, estado2_PosSensor, 0, &comidaDir, &casaDir, &F1Dir);

                                                if (comidaEsq > comidaDir) {
                                                        F[f].angulo = (F[f].angulo+70)%72;
                                                }
                                                else if (comidaEsq < comidaDir) {
                                                        F[f].angulo = (F[f].angulo+2)%72;
                                                }
                                                else {
                                                        sorteio = rand() % 1000;

                                	                if (sorteio < estado2_FollowF1) {
                                                                if ((abs(F1Esq - F1Dir) >= estado2_FollowF1ThrMin) && (abs(F1Esq - F1Dir) <= estado2_FollowF1ThrMax)) {
                                                                        if (HardFollow) sorteio = (F1Esq > F1Dir) ? F1Esq - 1 : F1Dir;
                                                                        else sorteio = rand()%(F1Esq+F1Dir+1);

                	                                                if (sorteio < F1Esq+1) {
                                                                        	F[f].angulo = (F[f].angulo+70)%72;
                                                        	        }
                                                	                else {
                                        	                                F[f].angulo = (F[f].angulo+2)%72;
                        	                                        }
                                                                }
        	                                        }
                                	                else if (sorteio < estado2_FollowF1+estado2_AgainstF1) {
                                                                if ((abs(F1Esq - F1Dir) >= estado2_AgainstF1ThrMin) && (abs(F1Esq - F1Dir) <= estado2_AgainstF1ThrMax)) {
                                                                        if (HardFollow) sorteio = (F1Esq > F1Dir) ? F1Esq - 1 : F1Dir;
                                                                        else sorteio = rand()%(F1Esq+F1Dir+1);

                	                                                if (sorteio < F1Esq+1) {
                                                                        	F[f].angulo = (F[f].angulo+2)%72;
                                                        	        }
                                                	                else {
                                        	                                F[f].angulo = (F[f].angulo+70)%72;
                        	                                        }
                                                                }
                                                        }
                                                        else {
                                                                F[f].angulo = (F[f].angulo+vira(0))%72;
                                                        }
                                                }

                                                if (F1[F[f].x+1][F[f].y+1] <= 10000) F1[F[f].x+1][F[f].y+1] += estado1_FoodDeposit>>2;
                                                if (F1[F[f].x+1][F[f].y+0] <= 10000) F1[F[f].x+1][F[f].y+0] += estado1_FoodDeposit>>2;
                                                if (F1[F[f].x+1][F[f].y-1] <= 10000) F1[F[f].x+1][F[f].y-1] += estado1_FoodDeposit>>2;
                                                if (F1[F[f].x+0][F[f].y+1] <= 10000) F1[F[f].x+0][F[f].y+1] += estado1_FoodDeposit>>2;
                                                if (F1[F[f].x+0][F[f].y+0] <= 10000) F1[F[f].x+0][F[f].y+0] += estado1_FoodDeposit>>1;
                                                if (F1[F[f].x+0][F[f].y-1] <= 10000) F1[F[f].x-0][F[f].y-1] += estado1_FoodDeposit>>2;
                                                if (F1[F[f].x-1][F[f].y+1] <= 10000) F1[F[f].x-1][F[f].y+1] += estado1_FoodDeposit>>2;
                                                if (F1[F[f].x-1][F[f].y+0] <= 10000) F1[F[f].x-1][F[f].y+0] += estado1_FoodDeposit>>2;
                                                if (F1[F[f].x-1][F[f].y-1] <= 10000) F1[F[f].x-1][F[f].y-1] += estado1_FoodDeposit>>2;
                                        }
                                        Formiga[F[f].x][F[f].y]=0;

                                        // movimenta
                                        movimenta:

                                        xanterior = F[f].x;
                                        yanterior = F[f].y;

                                        antstep(&F[f].x, &F[f].y, &F[f].erroxy, F[f].dirx, F[f].diry);

                                        if (Obstaculo[F[f].x][F[f].y]) {
                                                F[f].x = xanterior;
                                                F[f].y = yanterior;

                                                F[f].angulo = (F[f].angulo+1)%72;
//                                                F[f].angulo = (F[f].angulo+vira(1))%72;
                                                F[f].dirx = converteangulo[F[f].angulo][0];
                                                F[f].diry = converteangulo[F[f].angulo][1];

                                                goto movimenta;
                                        }

                                        Formiga[F[f].x][F[f].y]=1;

                                        F[f].dirx = converteangulo[F[f].angulo][0];
                                        F[f].diry = converteangulo[F[f].angulo][1];
                                }

				if (Updates % IntervalF1 == 0) {
					for(i=0; i<WIDTH; i++) {
						for(j=0; j<HEIGHT; j++) {
							F1[i][j] -= RateF1;
							if (F1[i][j] < 0) F1[i][j] = 0;
						}
					}
				}

                                Updates++;
                }

        return quantidade_comida;
}
//---------------------------------------------------------------------------



