//---------------------------------------------------------------------------

#ifndef threadexecucaoH
#define threadexecucaoH
//---------------------------------------------------------------------------
#include <Classes.hpp>
//---------------------------------------------------------------------------
class execucao : public TThread
{            
private:
protected:
        void __fastcall Execute();
public:
        __fastcall execucao(bool CreateSuspended);
};
//---------------------------------------------------------------------------
#endif
