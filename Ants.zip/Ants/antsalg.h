//---------------------------------------------------------------------------

#ifndef antsalgH
#define antsalgH
//---------------------------------------------------------------------------
#define min(a,b) ((a<b)?a:b)
#define max(a,b) ((a>b)?a:b)

typedef struct _SFormiga {
        int x;
        int y;
        int angulo;
        int dirx;
        int diry;
        int erroxy;
        int estado;
        int contador[5];
        int varialadosensor;
} SFormiga;

typedef struct _parametros {
        int myprob_virar[7];

        int myRateF1;
        int myIntervalF1;
        int mySaturation;
        float mydecay;

        int myconf_FollowF1[3];
        int myconf_FollowF1ThrMin[3];
        int myconf_FollowF1ThrMax[3];
        int myconf_AgainstF1[3];
        int myconf_AgainstF1ThrMin[3];
        int myconf_AgainstF1ThrMax[3];
        int myconf_HardFollow[3];
        int myconf_ThrRelativo[3];

	int myestado_F1Deposit[5];
	int myestado_TimeLimit[5];
	int myestado_RaioSensor[5];
	int myestado_PosSensor[5];
	int myestado_BehaviorConfig[5];
	int myestado_1EstadoProb[5];
	int myestado_1EstadoProbValor[5];
	int myestado_2EstadoProb[5];
	int myestado_2EstadoProbValor[5];

        int myanguloTransicao[14];

        float nota;
} parametros;

extern float converteangulo[72][2];
extern Updates;

void __fastcall prepara();
void __fastcall configurar(int _WIDTH, int _HEIGHT, int _id_formigas, SFormiga *_F, int **_Formiga, int **_Casa, int **_Comida, int **_F1, int **_Obstaculo, int *_prob_virar, int _RateF1, int _IntervalF1, int _Saturation, float _decay, int *_conf_FollowF1, int *_conf_FollowF1ThrMin, int *_conf_FollowF1ThrMax, int *_conf_AgainstF1, int *_conf_AgainstF1ThrMin, int *_conf_AgainstF1ThrMax, int *_conf_HardFollow, int *_conf_ThrRelativo, int *_estado_F1Deposit, int *_estado_TimeLimit, int *_estado_RaioSensor, int *_estado_PosSensor, int *_estado_BehaviorConfig, int *_estado_1EstadoProb, int *_estado_1EstadoProbValor, int *_estado_2EstadoProb, int *_estado_2EstadoProbValor, int *_anguloTransicao);
int __fastcall vira(int forcar);
void __fastcall antstep(int *, int *, int *, int, int);
void __fastcall coberturaF1(int x, int y, int angulo, int raio, int pos, int lado, int varialadosensor, int *comidaLado, int *casaLado, int *F1Lado, int *obsLado);
float __fastcall fitness(int);
//---------------------------------------------------------------------------
#endif
