//---------------------------------------------------------------------------

#pragma hdrstop

#include "main.h"
#include "antsalg.h"
#include <stdlib.h>
#include <string.h>
#include <math.h>

//---------------------------------------------------------------------------

#pragma package(smart_init)

int WIDTH;
int HEIGHT;

SFormiga *F;
int **Formiga;
int **Casa;
int **Comida;
int **F1;
int **Obstaculo;
int Updates=0;
int id_formigas=1;
float converteangulo[72][2];
float quantidade_comida;
int INTERACOES;
parametros _myFilho;

float tabelapow[256];

//---------------------------------------------------------------------------
void __fastcall prepara() {
        int i;

        for(i=0; i<72; i++) {
                converteangulo[i][0] = (int)(cos((5*i*M_PI)/180.0)*10000.0 + 0.5);
                converteangulo[i][1] = (int)(sin((5*i*M_PI)/180.0)*10000.0 + 0.5);
        }
}
//---------------------------------------------------------------------------


void __fastcall configurar(int _WIDTH, int _HEIGHT, int _id_formigas, SFormiga *_F, int **_Formiga, int **_Casa, int **_Comida, int **_F1, int **_Obstaculo, int *_prob_virar, int _RateF1, int _IntervalF1, int _Saturation, float _decay, int *_conf_FollowF1, int *_conf_FollowF1ThrMin, int *_conf_FollowF1ThrMax, int *_conf_AgainstF1, int *_conf_AgainstF1ThrMin, int *_conf_AgainstF1ThrMax, int *_conf_HardFollow, int *_conf_ThrRelativo, int *_estado_F1Deposit, int *_estado_TimeLimit, int *_estado_RaioSensor, int *_estado_PosSensor, int *_estado_BehaviorConfig, int *_estado_1EstadoProb, int *_estado_1EstadoProbValor, int *_estado_2EstadoProb, int *_estado_2EstadoProbValor, int *_anguloTransicao) {
        int i;

	WIDTH = _WIDTH;
	HEIGHT = _HEIGHT;

	memcpy(_myFilho.myprob_virar, _prob_virar, sizeof(_myFilho.myprob_virar));

	_myFilho.myRateF1 = _RateF1;
	_myFilho.myIntervalF1 = _IntervalF1;
	_myFilho.mySaturation = _Saturation;

	_myFilho.mydecay = _decay;

	memcpy(_myFilho.myconf_FollowF1, _conf_FollowF1, sizeof(_myFilho.myconf_FollowF1));
	memcpy(_myFilho.myconf_FollowF1ThrMin, _conf_FollowF1ThrMin, sizeof(_myFilho.myconf_FollowF1ThrMin));
	memcpy(_myFilho.myconf_FollowF1ThrMax, _conf_FollowF1ThrMax, sizeof(_myFilho.myconf_FollowF1ThrMax));
	memcpy(_myFilho.myconf_AgainstF1, _conf_AgainstF1, sizeof(_myFilho.myconf_AgainstF1));
	memcpy(_myFilho.myconf_AgainstF1ThrMin, _conf_AgainstF1ThrMin, sizeof(_myFilho.myconf_AgainstF1ThrMin));
	memcpy(_myFilho.myconf_AgainstF1ThrMax, _conf_AgainstF1ThrMax, sizeof(_myFilho.myconf_AgainstF1ThrMax));
	memcpy(_myFilho.myconf_HardFollow, _conf_HardFollow, sizeof(_myFilho.myconf_HardFollow));
	memcpy(_myFilho.myconf_ThrRelativo, _conf_ThrRelativo, sizeof(_myFilho.myconf_ThrRelativo));

	memcpy(_myFilho.myestado_F1Deposit, _estado_F1Deposit, sizeof(_myFilho.myestado_F1Deposit));
	memcpy(_myFilho.myestado_TimeLimit, _estado_TimeLimit, sizeof(_myFilho.myestado_TimeLimit));
	memcpy(_myFilho.myestado_RaioSensor, _estado_RaioSensor, sizeof(_myFilho.myestado_RaioSensor));
	memcpy(_myFilho.myestado_PosSensor, _estado_PosSensor, sizeof(_myFilho.myestado_PosSensor));
	memcpy(_myFilho.myestado_BehaviorConfig, _estado_BehaviorConfig, sizeof(_myFilho.myestado_BehaviorConfig));
	memcpy(_myFilho.myestado_1EstadoProb, _estado_1EstadoProb, sizeof(_myFilho.myestado_1EstadoProb));
	memcpy(_myFilho.myestado_1EstadoProbValor, _estado_1EstadoProbValor, sizeof(_myFilho.myestado_1EstadoProbValor));
	memcpy(_myFilho.myestado_2EstadoProb, _estado_2EstadoProb, sizeof(_myFilho.myestado_2EstadoProb));
	memcpy(_myFilho.myestado_2EstadoProbValor, _estado_2EstadoProbValor, sizeof(_myFilho.myestado_2EstadoProbValor));

        memcpy(_myFilho.myanguloTransicao, _anguloTransicao, sizeof(_myFilho.myanguloTransicao));

	id_formigas = _id_formigas;
	F = _F;
	Formiga = _Formiga;
	Casa = _Casa;
	Comida = _Comida;
	F1 = _F1;
	Obstaculo = _Obstaculo;

        for(i=0; i<256; i++) {
                tabelapow[i] = pow(_myFilho.mydecay,i);
        }
}
//---------------------------------------------------------------------------

int __fastcall vira(int forcar) {
        int i;
        int r;
        int total=0;

        if (forcar) {
                for(i=1; i<7; i++) {
                        total += _myFilho.myprob_virar[i];
                }

                r = (int)(rand()%(total+1));

                total = 0;
                for(i=1; i<7; i++) {
                        total+=_myFilho.myprob_virar[i];
                        if (total >= r) {
                                return ((i <= 3) ? i : (75-i));
                        }
                }
        }
        else {
                r = (int)(rand()%1000);
                
                for(i=0; i<7; i++) {
                        total+=_myFilho.myprob_virar[i];
                        if (total >= r) {
                                return ((i <= 3) ? i : (75-i));
                        }
                }
        }

        return ((i <= 3) ? i : (75-i));
}
//---------------------------------------------------------------------------

void __fastcall antstep(int *x, int *y, int *erroxy, int dirx, int diry) {
        int xstep, ystep;

	if (abs(dirx) > abs(diry)) {
		xstep = ((dirx >= 0) ? 1 : -1);
		ystep = ((diry >= 0) ? 1 : -1);
		dirx = abs(dirx);
		diry = abs(diry);

		*x += xstep;

		*erroxy += diry;
		if (2*(*erroxy) >= dirx) {
			*y += ystep;
			*erroxy -= dirx;
		}
	}
	else {
		xstep = ((dirx >= 0) ? 1 : -1);
		ystep = ((diry >= 0) ? 1 : -1);
		dirx = abs(dirx);
		diry = abs(diry);

		*y += ystep;

		*erroxy += dirx;
		if (2*(*erroxy) >= diry) {
			*x += xstep;
			*erroxy -= diry;
		}
	}
}

void __fastcall coberturaF1(int x, int y, int angulo, int raio, int pos, int lado, int varialadosensor, int *comidaLado, int *casaLado, int *F1Lado, int *obsLado) {
        int i, j;
        int tmp;
        int erroxy=0;
        int andado;
        static int dirx;
        static int diry;
        static int ireal;
        int ix;
        int iy;
        int xanterior, yanterior;

        pos = pos - raio;

	// vai para posicao onde comeca o radar
	if (pos < 0) {
		pos = abs(pos);

		dirx = converteangulo[(angulo+36)%72][0];
		diry = converteangulo[(angulo+36)%72][1];
	}
	else {
		dirx = converteangulo[angulo][0];
		diry = converteangulo[angulo][1];

	}

        for(i=0; i<pos; i++) {
                xanterior=x;
                yanterior=y;
	        antstep(&x, &y, &erroxy, dirx, diry);
                if (Obstaculo[x][y]) {
                        x=xanterior;
                        y=yanterior;
                        break;
                }
        }

/*
        if (varialadosensor == 1) {
		dirx = converteangulo[(angulo+18)%72][0];
		diry = converteangulo[(angulo+18)%72][1];
        }
        else {
		dirx = converteangulo[(angulo+54)%72][0];
		diry = converteangulo[(angulo+54)%72][1];
        }

        xanterior=x;
        yanterior=y;
	antstep(&x, &y, &erroxy, dirx, diry);
        if (Obstaculo[x][y]) {
                x=xanterior;
                y=yanterior;
        }
*/

        ix = x;
        iy = y;

        *F1Lado = 0;
        if (lado == 99) { // frente
        	x = ix;
        	y = iy;
                for(j=0; j<raio; j++) {
        		antstep(&x, &y, &erroxy, dirx, diry);
        		if (Obstaculo[x][y]) break;

                        *F1Lado += F1[x][y]*tabelapow[j];
//Form1->Chao->Canvas->Pixels[x][y] = RGB(255, 0, 0);
                }

                *F1Lado *=  5;
        }
        else {
                *comidaLado = 0;
                *casaLado = 0;
                *obsLado = 0;

                if (lado == 0) lado = 1;
                else lado = 37;

/****************************************************************************
*****************************************************************************
** ATENCAO: SE MEXER NESSE "5" TEM QUE MEXER NA PROPORCAO DO LADO=FRENTE!! **
*****************************************************************************
****************************************************************************/
                for(i=0; i<5 /*LEIA ACIMA*/; i++) {
                        switch(i) {
                                case 0: ireal=0; break;
                                case 1: ireal=8; break;
                                case 2: ireal=17; break;
                                case 3: ireal=26; break;
                                case 4: ireal=34; break;
                        }

        		dirx=converteangulo[(angulo+lado+ireal)%72][0];
        		diry=converteangulo[(angulo+lado+ireal)%72][1];

        		x = ix;
        		y = iy;

        		for(j=0; j<raio; j++) {
        			antstep(&x, &y, &erroxy, dirx, diry);
        			if (Obstaculo[x][y]) {
                                        *obsLado += 1;
                                        break;
                                }

                                *comidaLado += Comida[x][y];
                                *casaLado += Casa[x][y];
                                *F1Lado += F1[x][y]*tabelapow[j];
//Form1->Chao->Canvas->Pixels[x][y] = RGB(100+lado*3, 200, 200);
                        }
		}
	}

//if (Form1->SpeedButton4->Down) Form1->Chao->Refresh();
}
//---------------------------------------------------------------------------
float __fastcall fitness(int INTERACOES) {
        int a;
        int f, i, j;

        int xstep, ystep;
        int meudirx, meudiry;
        int meux, meuy;
        int xanterior, yanterior;
        int sorteio;
        int F1Esq, F1Dir;
        int casaEsq, casaDir;
        int comidaEsq, comidaDir;
        int obsEsq, obsDir;
        int Thr;
        int viraesquerda, viradireita;

/*
        quantidade_comida = 32000000/((fabs(20 - prob_virar[1])/1000.00+1)*(fabs(20 - prob_virar[2])/1000.00+1)*(fabs(20 - prob_virar[3])/1000.00+1)*(fabs(20 - prob_virar[4])/1000.00+1)*(fabs(20 - prob_virar[5])/1000.00+1)*(fabs(20 - prob_virar[6])/1000.00+1)*(fabs(1 - RateF1)/1000.00+1)*(fabs(32 - IntervalF1)/1000.00+1)*(fabs(1 - HardFollow)/1000.00+1)*(fabs(36 - anguloParaVirar)/1000.00+1)*(fabs(0.95 - decay)+1)*(fabs(16000 - ProbExplorar)/1000.00+1)*(fabs(16 - estado1_FoodDeposit)/1000.00+1)*(fabs(64 - estado2_FoodDeposit)/1000.00+1)*(fabs(0 - estado1_FollowF1)/1000.00+1)*(fabs(990 - estado2_FollowF1)/1000.00+1)*(fabs(1000 - estado1_AgainstF1)/1000.00+1)*(fabs(0 - estado2_AgainstF1)/1000.00+1)*(fabs(0 - estado1_FollowF1ThrMin)/1000.00+1)*(fabs(12800 - estado2_FollowF1ThrMin)/1000.00+1)*(fabs(0 - estado1_FollowF1ThrMax)/1000.00+1)*(fabs(10 - estado2_FollowF1ThrMax)/1000.00+1)*(fabs(32000 - estado1_AgainstF1ThrMin)/1000.00+1)*
	                    (fabs(0 - estado2_AgainstF1ThrMin)/1000.00+1)*(fabs(0 - estado1_AgainstF1ThrMax)/1000.00+1)*(fabs(0 - estado2_AgainstF1ThrMax)/1000.00+1)*(fabs(32 - estado1_RaioSensor)/1000.00+1)*(fabs(32 - estado2_RaioSensor)/1000.00+1)*(fabs(32 - estado1_PosSensor)/1000.00+1)*(fabs(60 - estado2_PosSensor)/1000.00+1)*(fabs(256 - estado1_Time)/1000.00+1)*(fabs(1600 - estado2_Time)/1000.00+1));

//max = 1000000;
        return quantidade_comida;
*/

                quantidade_comida = 0;
                for(a=0; a<INTERACOES; a++) {
                                for(f=0;f<id_formigas;f++) {
                                        if ((rand() % _myFilho.myestado_1EstadoProbValor[F[f].estado-1]) == 0) {
                                                F[f].estado = _myFilho.myestado_1EstadoProb[F[f].estado-1];

                                                F[f].contador[F[f].estado-1] = 0;

                                                if (rand() % 2 == 0) F[f].angulo = (F[f].angulo+_myFilho.myanguloTransicao[10])%72;
                                                else F[f].angulo = (F[f].angulo+(72-_myFilho.myanguloTransicao[10]))%72;
                                        }
                                        if ((rand() % _myFilho.myestado_2EstadoProbValor[F[f].estado-1]) == 0) {
                                                F[f].estado = _myFilho.myestado_2EstadoProb[F[f].estado-1];

                                                F[f].contador[F[f].estado-1] = 0;

                                                if (rand() % 2 == 0) F[f].angulo = (F[f].angulo+_myFilho.myanguloTransicao[11])%72;
                                                else F[f].angulo = (F[f].angulo+(72-_myFilho.myanguloTransicao[11]))%72;
                                        }

					coberturaF1(F[f].x, F[f].y, F[f].angulo, _myFilho.myestado_RaioSensor[F[f].estado-1], _myFilho.myestado_PosSensor[F[f].estado-1], 1, F[f].varialadosensor, &comidaEsq, &casaEsq, &F1Esq, &obsEsq);
					coberturaF1(F[f].x, F[f].y, F[f].angulo, _myFilho.myestado_RaioSensor[F[f].estado-1], _myFilho.myestado_PosSensor[F[f].estado-1], 0, F[f].varialadosensor, &comidaDir, &casaDir, &F1Dir, &obsDir);


					checaestado:

                                        if (F[f].estado==1) {
                                                F[f].contador[0]++;

						if (Comida[F[f].x][F[f].y]) {
							F[f].estado = 2;
                                                        F[f].contador[0] = 0;

                                                        if (rand() % 2 == 0) F[f].angulo = (F[f].angulo+_myFilho.myanguloTransicao[0])%72;
                                                        else F[f].angulo = (F[f].angulo+(72-_myFilho.myanguloTransicao[0]))%72;

							goto fimestados;

						}

                                                if (F[f].contador[0] > _myFilho.myestado_TimeLimit[0]) {
							F[f].estado = 5;
                                                        F[f].contador[0] = 0;

                                                        if (rand() % 2 == 0) F[f].angulo = (F[f].angulo+_myFilho.myanguloTransicao[1])%72;
                                                        else F[f].angulo = (F[f].angulo+(72-_myFilho.myanguloTransicao[1]))%72;

							goto fimestados;
                                                }

                                                viraesquerda = 0;
                                                viradireita = 0;
	        				if (comidaEsq > comidaDir) viraesquerda = 1;
        					else if (comidaEsq < comidaDir) viradireita = 1;
                                        }
                                        else if (F[f].estado==2) {
                                                F[f].contador[1]++;

						if (Casa[F[f].x][F[f].y]) {
                                                        quantidade_comida++;

							F[f].estado = 4;
                                                        F[f].contador[1] = 0;

                                                        if (rand() % 2 == 0) F[f].angulo = (F[f].angulo+_myFilho.myanguloTransicao[4])%72;
                                                        else F[f].angulo = (F[f].angulo+(72-_myFilho.myanguloTransicao[4]))%72;

							goto fimestados;

						}

                                                if (F[f].contador[1] > _myFilho.myestado_TimeLimit[1]) {
							F[f].estado = 3;
                                                        F[f].contador[1] = 0;

                                                        if (rand() % 2 == 0) F[f].angulo = (F[f].angulo+_myFilho.myanguloTransicao[3])%72;
                                                        else F[f].angulo = (F[f].angulo+(72-_myFilho.myanguloTransicao[3]))%72;

							goto fimestados;
                                                }

                                                viraesquerda = 0;
                                                viradireita = 0;
	        				if (casaEsq > casaDir) viraesquerda = 1;
        					else if (casaEsq < casaDir) viradireita = 1;
                                        }
                                        else if (F[f].estado==3) {
                                                F[f].contador[2]++;

						if (Casa[F[f].x][F[f].y]) {
                                                        quantidade_comida++;

							F[f].estado = 4;
                                                        F[f].contador[2] = 0;

                                                        if (rand() % 2 == 0) F[f].angulo = (F[f].angulo+_myFilho.myanguloTransicao[4])%72;
                                                        else F[f].angulo = (F[f].angulo+(72-_myFilho.myanguloTransicao[4]))%72;

							goto fimestados;

						}

						if (Comida[F[f].x][F[f].y]) {
							F[f].estado = 2;
                                                        F[f].contador[2] = 0;

                                                        if (rand() % 2 == 0) F[f].angulo = (F[f].angulo+_myFilho.myanguloTransicao[5])%72;
                                                        else F[f].angulo = (F[f].angulo+(72-_myFilho.myanguloTransicao[5]))%72;

							goto fimestados;
                                                }

                                                if (F[f].contador[2] > _myFilho.myestado_TimeLimit[2]) {
							F[f].estado = 1;
                                                        F[f].contador[2] = 0;

                                                        if (rand() % 2 == 0) F[f].angulo = (F[f].angulo+_myFilho.myanguloTransicao[12])%72;
                                                        else F[f].angulo = (F[f].angulo+(72-_myFilho.myanguloTransicao[12]))%72;

							goto fimestados;
                                                }

                                                viraesquerda = 0;
                                                viradireita = 0;
	        				if (comidaEsq > comidaDir) viraesquerda = 1;
        					else if (comidaEsq < comidaDir) viradireita = 1;
	        				if (casaEsq > casaDir) viraesquerda = 1;
        					else if (casaEsq < casaDir) viradireita = 1;
                                        }
                                        else if (F[f].estado==4) {
                                                F[f].contador[3]++;

						if (Comida[F[f].x][F[f].y]) {
							F[f].estado = 2;
                                                        F[f].contador[3] = 0;

                                                        if (rand() % 2 == 0) F[f].angulo = (F[f].angulo+_myFilho.myanguloTransicao[7])%72;
                                                        else F[f].angulo = (F[f].angulo+(72-_myFilho.myanguloTransicao[7]))%72;

							goto fimestados;

						}

                                                if (F[f].contador[3] > _myFilho.myestado_TimeLimit[3]) {
							F[f].estado = 1;
                                                        F[f].contador[3] = 0;

                                                        if (rand() % 2 == 0) F[f].angulo = (F[f].angulo+_myFilho.myanguloTransicao[6])%72;
                                                        else F[f].angulo = (F[f].angulo+(72-_myFilho.myanguloTransicao[6]))%72;

							goto fimestados;
                                                }

                                                viraesquerda = 0;
                                                viradireita = 0;
	        				if (comidaEsq > comidaDir) viraesquerda = 1;
        					else if (comidaEsq < comidaDir) viradireita = 1;
                                        }
                                        else if (F[f].estado==5) {
                                                F[f].contador[4]++;

						if (Comida[F[f].x][F[f].y]) {
							F[f].estado = 2;
                                                        F[f].contador[4] = 0;

                                                        if (rand() % 2 == 0) F[f].angulo = (F[f].angulo+_myFilho.myanguloTransicao[8])%72;
                                                        else F[f].angulo = (F[f].angulo+(72-_myFilho.myanguloTransicao[8]))%72;

							goto fimestados;

						}

                                                if (Casa[F[f].x][F[f].y]) {
							F[f].estado = 1;
                                                        F[f].contador[4] = 0;

                                                        if (rand() % 2 == 0) F[f].angulo = (F[f].angulo+_myFilho.myanguloTransicao[9])%72;
                                                        else F[f].angulo = (F[f].angulo+(72-_myFilho.myanguloTransicao[9]))%72;

							goto fimestados;
                                                }

                                                if (F[f].contador[4] > _myFilho.myestado_TimeLimit[4]) {
							F[f].estado = 1;
                                                        F[f].contador[4] = 0;

                                                        if (rand() % 2 == 0) F[f].angulo = (F[f].angulo+_myFilho.myanguloTransicao[13])%72;
                                                        else F[f].angulo = (F[f].angulo+(72-_myFilho.myanguloTransicao[13]))%72;

							goto fimestados;
                                                }

                                                viraesquerda = 0;
                                                viradireita = 0;
	        				if (casaEsq > casaDir) viraesquerda = 1;
        					else if (casaEsq < casaDir) viradireita = 1;
	        				if (comidaEsq > comidaDir) viraesquerda = 1;
        					else if (comidaEsq < comidaDir) viradireita = 1;
                                        }

                                        fimestados:
					if (viraesquerda) {
						F[f].angulo = (F[f].angulo+70)%72;
					}
					else if (viradireita) {
						F[f].angulo = (F[f].angulo+2)%72;
					}
					else {
						if (obsEsq > obsDir) {
                					coberturaF1(F[f].x, F[f].y, F[f].angulo, _myFilho.myestado_RaioSensor[F[f].estado-1], _myFilho.myestado_PosSensor[F[f].estado-1], 99, F[f].varialadosensor, NULL, NULL, &F1Esq, NULL);
                                                }
						else if (obsEsq < obsDir) {
                					coberturaF1(F[f].x, F[f].y, F[f].angulo, _myFilho.myestado_RaioSensor[F[f].estado-1], _myFilho.myestado_PosSensor[F[f].estado-1], 99, F[f].varialadosensor, NULL, NULL, &F1Dir, NULL);
                                                }

						if (_myFilho.myconf_ThrRelativo[_myFilho.myestado_BehaviorConfig[F[f].estado-1]-1]) Thr = (100*(max(F1Esq,F1Dir)+1)) / (min(F1Esq,F1Dir)+1);
                                                else Thr = abs(F1Esq - F1Dir);

						sorteio = rand() % 1000;
						if ((sorteio < _myFilho.myconf_FollowF1[_myFilho.myestado_BehaviorConfig[F[f].estado-1]-1]) && ((Thr >= _myFilho.myconf_FollowF1ThrMin[_myFilho.myestado_BehaviorConfig[F[f].estado-1]-1]) && (Thr <= _myFilho.myconf_FollowF1ThrMax[_myFilho.myestado_BehaviorConfig[F[f].estado-1]-1]))) {
							if (_myFilho.myconf_HardFollow[_myFilho.myestado_BehaviorConfig[F[f].estado-1]-1]) sorteio = (F1Esq > F1Dir) ? F1Esq - 1 : F1Dir;
							else sorteio = rand()%(F1Esq+F1Dir+1);

							if (sorteio < F1Esq+1) F[f].angulo = (F[f].angulo+70)%72;
                                                        else F[f].angulo = (F[f].angulo+2)%72;
						}
						else if ((sorteio < _myFilho.myconf_FollowF1[_myFilho.myestado_BehaviorConfig[F[f].estado-1]-1]+_myFilho.myconf_AgainstF1[_myFilho.myestado_BehaviorConfig[F[f].estado-1]-1]) && ((Thr >= _myFilho.myconf_AgainstF1ThrMin[_myFilho.myestado_BehaviorConfig[F[f].estado-1]-1]) && (Thr <= _myFilho.myconf_AgainstF1ThrMax[_myFilho.myestado_BehaviorConfig[F[f].estado-1]-1]))) {
							if (_myFilho.myconf_ThrRelativo[_myFilho.myestado_BehaviorConfig[F[f].estado-1]-1]) sorteio = (F1Esq > F1Dir) ? F1Esq - 1 : F1Dir;
							else sorteio = rand()%(F1Esq+F1Dir+1);

							if (sorteio < F1Esq+1) F[f].angulo = (F[f].angulo+2)%72;
                                                        else F[f].angulo = (F[f].angulo+70)%72;
						}
						else {
							F[f].angulo = (F[f].angulo+vira(0))%72;
						}
					}



					if (F1[F[f].x+1][F[f].y+1] <= _myFilho.mySaturation) F1[F[f].x+1][F[f].y+1] += _myFilho.myestado_F1Deposit[F[f].estado-1]>>2;
					if (F1[F[f].x+1][F[f].y+0] <= _myFilho.mySaturation) F1[F[f].x+1][F[f].y+0] += _myFilho.myestado_F1Deposit[F[f].estado-1]>>2;
					if (F1[F[f].x+1][F[f].y-1] <= _myFilho.mySaturation) F1[F[f].x+1][F[f].y-1] += _myFilho.myestado_F1Deposit[F[f].estado-1]>>2;
					if (F1[F[f].x+0][F[f].y+1] <= _myFilho.mySaturation) F1[F[f].x+0][F[f].y+1] += _myFilho.myestado_F1Deposit[F[f].estado-1]>>2;
					if (F1[F[f].x+0][F[f].y+0] <= _myFilho.mySaturation) F1[F[f].x+0][F[f].y+0] += _myFilho.myestado_F1Deposit[F[f].estado-1]>>1;
					if (F1[F[f].x+0][F[f].y-1] <= _myFilho.mySaturation) F1[F[f].x-0][F[f].y-1] += _myFilho.myestado_F1Deposit[F[f].estado-1]>>2;
					if (F1[F[f].x-1][F[f].y+1] <= _myFilho.mySaturation) F1[F[f].x-1][F[f].y+1] += _myFilho.myestado_F1Deposit[F[f].estado-1]>>2;
					if (F1[F[f].x-1][F[f].y+0] <= _myFilho.mySaturation) F1[F[f].x-1][F[f].y+0] += _myFilho.myestado_F1Deposit[F[f].estado-1]>>2;
					if (F1[F[f].x-1][F[f].y-1] <= _myFilho.mySaturation) F1[F[f].x-1][F[f].y-1] += _myFilho.myestado_F1Deposit[F[f].estado-1]>>2;


                                        Formiga[F[f].x][F[f].y]=0;

                                        // movimenta
                                        movimenta:

                                        xanterior = F[f].x;
                                        yanterior = F[f].y;

                                        antstep(&F[f].x, &F[f].y, &F[f].erroxy, F[f].dirx, F[f].diry);

                                        if (Obstaculo[F[f].x][F[f].y]) {
                                                F[f].x = xanterior;
                                                F[f].y = yanterior;

                                                do {
                                                        F[f].angulo = (F[f].angulo+1) % 72;
                                                } while((F[f].angulo != 0) && (F[f].angulo != 18) && (F[f].angulo != 36) && (F[f].angulo != 54));

                                                F[f].dirx = converteangulo[F[f].angulo][0];
                                                F[f].diry = converteangulo[F[f].angulo][1];

                                                goto movimenta;
                                        }

                                        Formiga[F[f].x][F[f].y]=1;

                                        F[f].dirx = converteangulo[F[f].angulo][0];
                                        F[f].diry = converteangulo[F[f].angulo][1];
                                }

				if (Updates % _myFilho.myIntervalF1 == 0) {
					for(i=0; i<WIDTH; i++) {
						for(j=0; j<HEIGHT; j++) {
							F1[i][j] -= _myFilho.myRateF1;
							if (F1[i][j] < 0) F1[i][j] = 0;
						}
					}
				}

                                Updates++;
                }

        return quantidade_comida;
}
//---------------------------------------------------------------------------




