//---------------------------------------------------------------------------

#include <vcl.h>
#include <math.h>
#pragma hdrstop

#include "main.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TForm1 *Form1;

#define max(a,b) ((a>b)?a:b)

// estado 1 = coloca F1, foge de F1
// estado 2 = coloca F2, segue F1
// estado 3 = coloca F2, segue F2

#define PROCESSMESSAGES 50

#define WIDTH 500
#define HEIGHT 500

typedef struct _SFormiga {
        float x;
        float y;
        float dirx;
        float diry;
        int estado;
} SFormiga;

SFormiga F[256];
int Formiga[WIDTH][HEIGHT];     // 0 = nenhuma, 1 = estado1 / 2 = estado2 / 3 = estado3
int Casa[WIDTH][HEIGHT];
int Comida[WIDTH][HEIGHT];
int F1[WIDTH][HEIGHT];
int F2[WIDTH][HEIGHT];
int Obstaculo[WIDTH][HEIGHT];
int Refresh=1;
int Updates=0;
int id_formigas=1;
int prob_virar[24];

float converteangulo[24][2];

//---------------------------------------------------------------------------
__fastcall TForm1::TForm1(TComponent* Owner)
        : TForm(Owner)
{
        int i;

        for(i=0; i<WIDTH; i++) {
                Obstaculo[i][0] = 1;
                Obstaculo[i][HEIGHT-1] = 1;
        }
        for(i=0; i<HEIGHT; i++) {
                Obstaculo[0][i] = 1;
                Obstaculo[WIDTH-1][i] = 1;
        }

        RefreshChao();

        converteangulo[0][0] = 1;
        converteangulo[0][1] = 0;
        converteangulo[1][0] = 1;
        converteangulo[1][1] = 0.26793663940;
        converteangulo[2][0] = 1;
        converteangulo[2][1] = 0.57736720554;
        converteangulo[3][0] = 1;
        converteangulo[3][1] = 1;

        for(i=0; i<3; i++) {
                converteangulo[i+4][0] = converteangulo[i][1];
                converteangulo[i+4][1] = converteangulo[i][0];
        }

        for(i=0; i<6; i++) {
                converteangulo[i+7][0] = converteangulo[i+1][0];
                converteangulo[i+7][1] = -converteangulo[i+1][1];
        }

        for(i=0; i<11; i++) {
                converteangulo[i+13][0] = -converteangulo[i+1][0];
                converteangulo[i+13][1] = converteangulo[i+1][1];
        }

        srand(time(0));
}
//---------------------------------------------------------------------------


void __fastcall TForm1::ChaoMouseDown(TObject *Sender, TMouseButton Button,
      TShiftState Shift, int X, int Y)
{
        int i, j;
        int r;
        int angulo;

        if (SetNest->Down) {
                SetNest->Down = false;
                memset(Casa, 0, WIDTH*HEIGHT*sizeof(int));

                r = StrToInt(Edit3->Text)/2;
                // casa
                for (i=0; i<2*r; i++) {
                        for (j=0; j<r; j++) {
                                Casa[X+i/2][Y+j]=1;
                                Casa[X+i/2][Y-j]=1;
                                Casa[X-i/2][Y+j]=1;
                                Casa[X-i/2][Y-j]=1;
                        }

                        // formigas
                        Formiga[X-i][Y]=id_formigas;
                        F[id_formigas].x = X-(r/2)+i;
                        F[id_formigas].y = Y;
                        F[id_formigas].estado = 1;
                        angulo = (id_formigas-1)%12; //(int)(rand()%24);
                        F[i].dirx = converteangulo[angulo][0];
                        F[i].diry = converteangulo[angulo][1];

                        id_formigas++;
                }

                RefreshChao();
        }


        if (SetFood->Down) {
                SetFood->Down = false;

                r = StrToInt(Edit51->Text)/2;
                for (i=0; i<r; i++) {
                        for (j=0; j<r; j++) {
                                Comida[X+i][Y+j]=1;
                                Comida[X+i][Y-j]=1;
                                Comida[X-i][Y+j]=1;
                                Comida[X-i][Y-j]=1;
                        }
                }

                RefreshChao();
        }
}
//---------------------------------------------------------------------------
int __fastcall TForm1::vira() {
        int i;
        int r=(int)(rand()%100);
        int total=0;

        for(i=0; i<r; i++) {
                total+=prob_virar[i];
                if (total >= r) {
                        return i;
                }
        }

        return i;
}
//---------------------------------------------------------------------------
void __fastcall TForm1::RefreshChao() {
        int i, j;

        Chao->Canvas->FillRect(Rect(0, 0, Chao->Width, Chao->Height));

        for(i=0; i<WIDTH; i++) {
                for(j=0; j<WIDTH; j++) {
                        if (Comida[i][j]) {
                                Chao->Canvas->Pixels[i][j] = (TColor)RGB(255, 0, 0);
                        }

                        if (Formiga[i][j]) {
                                Chao->Canvas->Pixels[i][j] = (TColor)RGB(150, 0, 150);
                        }

                        if (Casa[i][j]) {
                                Chao->Canvas->Pixels[i][j] = (TColor)RGB(200, 150, 0);
                        }

                        if (F1[i][j]) {
                                Chao->Canvas->Pixels[i][j] = (TColor)RGB(0, max(F1[i][j], 256), 0);
                        }

                        if (F2[i][j]) {
                                Chao->Canvas->Pixels[i][j] = (TColor)RGB(0, 0, max(F1[i][j], 256));
                        }

                        if (Obstaculo[i][j]) {
                                Chao->Canvas->Pixels[i][j] = (TColor)RGB(0, 0, 0);
                        }
                }
        }

        Chao->Refresh();
}
//---------------------------------------------------------------------------

void __fastcall TForm1::RunClick(TObject *Sender)
{
        static int sair;
        int a;
        int i, j;
        int angulo;
        int RateF1;
        int IntervalF1;
        int RateF2;
        int IntervalF2;
        int WithFoodDeposit;
        int WithoutFoodDeposit;

        if (Run->Down) {
                srand(time(0));

                prob_virar[0] = StrToInt(Edit7->Text);
                prob_virar[1] = StrToInt(Edit8->Text);
                prob_virar[2] = StrToInt(Edit9->Text);
                prob_virar[3] = StrToInt(Edit10->Text);
                prob_virar[4] = StrToInt(Edit11->Text);
                prob_virar[5] = StrToInt(Edit12->Text);
                prob_virar[6] = StrToInt(Edit13->Text);
                prob_virar[7] = StrToInt(Edit14->Text);
                prob_virar[8] = StrToInt(Edit15->Text);
                prob_virar[9] = StrToInt(Edit16->Text);
                prob_virar[10] = StrToInt(Edit17->Text);
                prob_virar[11] = StrToInt(Edit18->Text);
                prob_virar[12] = StrToInt(Edit27->Text);
                prob_virar[13] = StrToInt(Edit28->Text);
                prob_virar[14] = StrToInt(Edit29->Text);
                prob_virar[15] = StrToInt(Edit30->Text);
                prob_virar[16] = StrToInt(Edit31->Text);
                prob_virar[17] = StrToInt(Edit32->Text);
                prob_virar[18] = StrToInt(Edit33->Text);
                prob_virar[19] = StrToInt(Edit34->Text);
                prob_virar[20] = StrToInt(Edit35->Text);
                prob_virar[21] = StrToInt(Edit36->Text);
                prob_virar[22] = StrToInt(Edit37->Text);
                prob_virar[23] = StrToInt(Edit38->Text);

                RateF1 = StrToInt(Edit4->Text);
                IntervalF1 = StrToInt(Edit19->Text);
                RateF2 = StrToInt(Edit5->Text);
                IntervalF2 = StrToInt(Edit20->Text);

                WithFoodDeposit = StrToInt(Edit46->Text);
                WithoutFoodDeposit = StrToInt(Edit49->Text);

                sair=0;
                while(!sair) {
                        for(a=0; a<PROCESSMESSAGES; a++) {
                                for(i=1;i<id_formigas;i++) {
                                        if (F[i].estado==1) {
                                                F1[(int)(F[i].x+0.5)][(int)(F[i].y+0.5)] += WithoutFoodDeposit;
                                                if (F1[(int)(F[i].x+0.5)][(int)(F[i].y+0.5)] >= 10000) {
                                                        F1[(int)(F[i].x+0.5)][(int)(F[i].y+0.5)] = 10000;
                                                }
                                        }
                                        if (F[i].estado>=2) {
                                                F2[(int)(F[i].x+0.5)][(int)(F[i].y+0.5)] += WithFoodDeposit;

                                                if (F2[(int)(F[i].x+0.5)][(int)(F[i].y+0.5)] >= 10000) {
                                                        F2[(int)(F[i].x+0.5)][(int)(F[i].y+0.5)] = 10000;
                                                }
                                        }

                                        Formiga[(int)(F[i].x+0.5)][(int)(F[i].y+0.5)]=0;

                                        F[i].x += F[i].dirx;
                                        F[i].y += F[i].diry;

                                        if (Obstaculo[(int)(F[i].x+0.5)][(int)(F[i].y+0.5)]) {
                                                F[i].x -= F[i].dirx;
                                                F[i].y -= F[i].diry;
                                                // dar uma for�ada
                                                angulo = vira();
                                                F[i].dirx = converteangulo[angulo][0];
                                                F[i].diry = converteangulo[angulo][1];
                                        }

                                        Formiga[(int)(F[i].x+0.5)][(int)(F[i].y+0.5)]=1;

//                                        angulo = vira();
//                                        F[i].dirx = converteangulo[angulo][0];
//                                        F[i].diry = converteangulo[angulo][1];

                                        RefreshChao();
                                }

                                if (Updates % IntervalF1 == 0) {
                                        for(i=0; i<WIDTH; i++) {
                                                for(j=0; j<HEIGHT; j++) {
                                                        F1[i][j] -= RateF1;
                                                        if (F1[i][j] < 0) F1[i][j] = 0;
                                                }
                                        }
                                }
                                if (Updates % IntervalF2 == 0) {
                                        for(i=0; i<WIDTH; i++) {
                                                for(j=0; j<HEIGHT; j++) {
                                                        F2[i][j] -= RateF2;
                                                        if (F2[i][j] < 0) F2[i][j] = 0;
                                                }
                                        }
                                }

                                Updates++;
                        }
                        Application->ProcessMessages();
                }
        }
        else {
                sair=1;
        }
}
//---------------------------------------------------------------------------

