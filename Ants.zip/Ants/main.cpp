// http://en.wikipedia.org/wiki/Bresenham%27s_line_algorithm

//---------------------------------------------------------------------------

#include <vcl.h>
#include <math.h>
#include <stdio.h>
#pragma hdrstop

#include "main.h"
#include "antsalg.h"
#include "threadexecucao.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TForm1 *Form1;

extern int quantidade_comida;

#define PROCESSMESSAGES 500
#define MAXFORMIGAS 256
#define FILHOSPORGERACAO 37

int mutacao = 10; // 30/1000 = 3%
int crossover = 180;
float porcentagemmut=0.60;
int filhosaleatorios=10;
int acadaqtasgeracoes=3;

parametros myFilho;
parametros Filho[FILHOSPORGERACAO];
parametros TmpFilho[FILHOSPORGERACAO];
int geracao=0;
parametros melhoresParametros;

int myWIDTH=250;
int myHEIGHT=250;
SFormiga myF[256];
int **myFormiga=NULL;
int **myCasa=NULL;
int **myComida=NULL;
int **myF1=NULL;
int **myObstaculo=NULL;
int myid_formigas;
int myprob_virar[7];
int myINTERACOES = 6000;

int totalcomida=0;

bool DesenhandoObstaculo = false;
bool DesenhandoFero = false;

//---------------------------------------------------------------------------
__fastcall TForm1::TForm1(TComponent* Owner)
        : TForm(Owner)
{
        int i;

        DoubleBuffered=true;

        srand(time(0));
        prepara();
        Reset();
        RefreshChao();

srand(480);
//SetNestF(40, 150, 25);
SetNestF(185, 200, 25);
srand(0);
SetFoodF(90, 52, 30);
SetFoodF(170, 75, 30);
        RefreshChao();
}
//---------------------------------------------------------------------------

void __fastcall TForm1::Reset() {
        int i;

        if (myFormiga == NULL) {
        	myFormiga = (int **)malloc(myHEIGHT*sizeof(int*));
        	myCasa = (int **)malloc(myHEIGHT*sizeof(int*));
        	myComida = (int **)malloc(myHEIGHT*sizeof(int*));
        	myF1 = (int **)malloc(myHEIGHT*sizeof(int*));
        	myObstaculo = (int **)malloc(myHEIGHT*sizeof(int*));

        	for(i=0; i<myHEIGHT; i++) {
        		myFormiga[i] = (int *)malloc(myWIDTH*sizeof(int));
        		myCasa[i] = (int *)malloc(myWIDTH*sizeof(int));
        		myComida[i] = (int *)malloc(myWIDTH*sizeof(int));
        		myF1[i] = (int *)malloc(myWIDTH*sizeof(int));
        		myObstaculo[i] = (int *)malloc(myWIDTH*sizeof(int));
        	}
        }
        else {
        	myFormiga = (int **)realloc(myFormiga, myHEIGHT*sizeof(int*));
        	myCasa = (int **)realloc(myCasa, myHEIGHT*sizeof(int*));
        	myComida = (int **)realloc(myComida, myHEIGHT*sizeof(int*));
        	myF1 = (int **)realloc(myF1, myHEIGHT*sizeof(int*));
        	myObstaculo = (int **)realloc(myObstaculo, myHEIGHT*sizeof(int*));

        	for(i=0; i<myHEIGHT; i++) {
        		myFormiga[i] = (int *)realloc(myFormiga[i], myWIDTH*sizeof(int));
        		myCasa[i] = (int *)realloc(myCasa[i], myWIDTH*sizeof(int));
        		myComida[i] = (int *)realloc(myComida[i], myWIDTH*sizeof(int));
        		myF1[i] = (int *)realloc(myF1[i], myWIDTH*sizeof(int));
        		myObstaculo[i] = (int *)realloc(myObstaculo[i], myWIDTH*sizeof(int));
        	}
        }

        for(i=0; i<myHEIGHT; i++) {
                memset(myFormiga[i], 0, myWIDTH*sizeof(int));
                memset(myCasa[i], 0, myWIDTH*sizeof(int));
                memset(myComida[i], 0, myWIDTH*sizeof(int));
                memset(myF1[i], 0, myWIDTH*sizeof(int));
                memset(myObstaculo[i], 0, myWIDTH*sizeof(int));
        }

        for(i=0; i<myWIDTH; i++) {
                myObstaculo[i][0] = 1;
                myObstaculo[i][myHEIGHT-1] = 1;
        }
        for(i=0; i<myHEIGHT; i++) {
                myObstaculo[0][i] = 1;
                myObstaculo[myWIDTH-1][i] = 1;
        }

        totalcomida = 0;
}
//---------------------------------------------------------------------------
void __fastcall TForm1::SetFoodF(int X, int Y, int r) {
        int i, j;

        for (i=0; i<r/4; i++) {
                for (j=0; j<r/4; j++) {
                        myComida[X+i][Y+j]=1;
                        myComida[X+i][Y-j]=1;
                        myComida[X-i][Y+j]=1;
                        myComida[X-i][Y-j]=1;
                }
        }
}
//---------------------------------------------------------------------------
void __fastcall TForm1::SetNestF(int X, int Y, int r) {
        int i, j;
        int arredondado=0;

                for(i=0; i<myHEIGHT; i++) {
                        memset(myCasa[i], 0, myWIDTH*sizeof(int));
                        memset(myFormiga[i], 0, myWIDTH*sizeof(int));
                }

                myid_formigas = 0;

                // formigas
                for(i=-sqrt(r)/2-1; i<sqrt(r)/2+1; i++) {
                        for(j=-sqrt(r)/2-1; j<sqrt(r)/2+1; j++) {
                                myFormiga[X+i][Y+j]=myid_formigas;
                                myF[myid_formigas].x = X+i;
                                myF[myid_formigas].y = Y+j;
                                myF[myid_formigas].estado = 1;
                                myF[myid_formigas].erroxy = 0;
//                                myF[myid_formigas].angulo = (int)(rand()%72);
                                myF[myid_formigas].angulo = ((int)(myid_formigas*(72.0/r)))%72;
                                myF[myid_formigas].dirx = converteangulo[myF[myid_formigas].angulo][0];
                                myF[myid_formigas].diry = converteangulo[myF[myid_formigas].angulo][1];
                                myF[myid_formigas].contador[0] = 0;
                                myF[myid_formigas].contador[1] = 0;
                                myF[myid_formigas].contador[2] = 0;
                                myF[myid_formigas].contador[3] = 0;
                                myF[myid_formigas].contador[4] = 0;
                                myF[myid_formigas].varialadosensor = 1;

                                myid_formigas++;
                                if (++arredondado >= r) goto sairarredondado;
                        }
                }

                sairarredondado:
                if (r < 20) r = 20;
                // casa
                for (i=0; i<r/4; i++) {
                        for (j=0; j<r/4; j++) {
                                myCasa[X+i][Y+j]=1;
                                myCasa[X+i][Y-j]=1;
                                myCasa[X-i][Y+j]=1;
                                myCasa[X-i][Y-j]=1;
                        }
                }
}
//---------------------------------------------------------------------------
void __fastcall TForm1::ChaoMouseDown(TObject *Sender, TMouseButton Button,
      TShiftState Shift, int X, int Y)
{
        int i, j;
        int r;

        if (SetNest->Down) {
                SetNest->Down = false;

                r = StrToInt(Edit3->Text);
                SetNestF(X, Y, r);
                RefreshChao();
        }

        if (SetFood->Down) {
                SetFood->Down = false;

                r = StrToInt(Edit51->Text);
                SetFoodF(X, Y, r);
                RefreshChao();
        }

        if (SpeedButton6->Down) {
                DesenhandoObstaculo = true;
                myObstaculo[min(max(X-1, 0), myWIDTH-1)][min(max(Y-1, 0), myHEIGHT-1)] = 1;
                myObstaculo[min(max(X-1, 0), myWIDTH-1)][min(max(Y+0, 0), myHEIGHT-1)] = 1;
                myObstaculo[min(max(X-1, 0), myWIDTH-1)][min(max(Y+1, 0), myHEIGHT-1)] = 1;
                myObstaculo[min(max(X+0, 0), myWIDTH-1)][min(max(Y-1, 0), myHEIGHT-1)] = 1;
                myObstaculo[min(max(X+0, 0), myWIDTH-1)][min(max(Y+0, 0), myHEIGHT-1)] = 1;
                myObstaculo[min(max(X+0, 0), myWIDTH-1)][min(max(Y+1, 0), myHEIGHT-1)] = 1;
                myObstaculo[min(max(X+1, 0), myWIDTH-1)][min(max(Y-1, 0), myHEIGHT-1)] = 1;
                myObstaculo[min(max(X+1, 0), myWIDTH-1)][min(max(Y+0, 0), myHEIGHT-1)] = 1;
                myObstaculo[min(max(X+1, 0), myWIDTH-1)][min(max(Y+1, 0), myHEIGHT-1)] = 1;
                RefreshChao();
        }
        if (SpeedButton5->Down) {
                DesenhandoFero = true;
                myF1[min(max(X-1, 0), myWIDTH-1)][min(max(Y-1, 0), myHEIGHT-1)] += StrToInt(Edit15->Text);
                myF1[min(max(X-1, 0), myWIDTH-1)][min(max(Y+0, 0), myHEIGHT-1)] += StrToInt(Edit15->Text);
                myF1[min(max(X-1, 0), myWIDTH-1)][min(max(Y+1, 0), myHEIGHT-1)] += StrToInt(Edit15->Text);
                myF1[min(max(X+0, 0), myWIDTH-1)][min(max(Y-1, 0), myHEIGHT-1)] += StrToInt(Edit15->Text);
                myF1[min(max(X+0, 0), myWIDTH-1)][min(max(Y+0, 0), myHEIGHT-1)] += StrToInt(Edit15->Text);
                myF1[min(max(X+0, 0), myWIDTH-1)][min(max(Y+1, 0), myHEIGHT-1)] += StrToInt(Edit15->Text);
                myF1[min(max(X+1, 0), myWIDTH-1)][min(max(Y-1, 0), myHEIGHT-1)] += StrToInt(Edit15->Text);
                myF1[min(max(X+1, 0), myWIDTH-1)][min(max(Y+0, 0), myHEIGHT-1)] += StrToInt(Edit15->Text);
                myF1[min(max(X+1, 0), myWIDTH-1)][min(max(Y+1, 0), myHEIGHT-1)] += StrToInt(Edit15->Text);
                RefreshChao();
        }
}
//---------------------------------------------------------------------------
void __fastcall TForm1::RefreshChao() {
        static TColor corFormiga;
        int i, j, k;
        int c;

        Chao->Canvas->FillRect(Rect(0, 0, Chao->Width, Chao->Height));

        for(i=0; i<myWIDTH; i++) {
                for(j=0; j<myHEIGHT; j++) {
                        if (myComida[i][j]) {
                                Chao->Canvas->Pixels[i][j] = (TColor)RGB(255, 0, 0);
                        }

                        if (myF1[i][j]) {
                                c=255-min(myF1[i][j]>>3, 255);
                                if (c < 50) c = 50;
                                Chao->Canvas->Pixels[i][j] = (TColor)RGB(c-50, c, c-50);
                        }

                        if (myCasa[i][j]) {
                                Chao->Canvas->Pixels[i][j] = (TColor)RGB(200, 150, 0);
                        }

                        if (myObstaculo[i][j]) {
                                Chao->Canvas->Pixels[i][j] = (TColor)RGB(0, 0, 0);
                        }

			if (myFormiga[i][j]) {
				for(k=0; k<myid_formigas; k++) {
					if ((myF[k].x != i) || (myF[k].y != j)) continue;

					if (myF[k].estado == 1) corFormiga = (TColor)RGB(0, 0, 0);
					else if (myF[k].estado == 2) corFormiga = (TColor)RGB(255, 0, 0);
					else if (myF[k].estado == 3) corFormiga = (TColor)RGB(255, 150, 150);
					else if (myF[k].estado == 4) corFormiga = (TColor)RGB(150, 150, 150);
					else if (myF[k].estado == 5) corFormiga = (TColor)RGB(200, 200, 200);

					Chao->Canvas->Pixels[i-1][j-1] = corFormiga;
					Chao->Canvas->Pixels[i-1][j+0] = corFormiga;
					Chao->Canvas->Pixels[i-1][j+1] = corFormiga;
					Chao->Canvas->Pixels[i+0][j-1] = corFormiga;
					Chao->Canvas->Pixels[i+0][j+0] = corFormiga;
					Chao->Canvas->Pixels[i+0][j+1] = corFormiga;
					Chao->Canvas->Pixels[i+1][j-1] = corFormiga;
					Chao->Canvas->Pixels[i+1][j+0] = corFormiga;
					Chao->Canvas->Pixels[i+1][j+1] = corFormiga;
				}
                        }
                }
        }

        Chao->Refresh();
}
//---------------------------------------------------------------------------
void __fastcall TForm1::RunClick(TObject *Sender)
{
        static int sair;
        int Refreshes = StrToInt(Edit6->Text);
        int a;

	myFilho.myprob_virar[0] = StrToInt(Edit7->Text);
	myFilho.myprob_virar[1] = StrToInt(Edit8->Text);
	myFilho.myprob_virar[2] = StrToInt(Edit9->Text);
	myFilho.myprob_virar[3] = StrToInt(Edit10->Text);
	myFilho.myprob_virar[4] = StrToInt(Edit11->Text);
	myFilho.myprob_virar[5] = StrToInt(Edit37->Text);
	myFilho.myprob_virar[6] = StrToInt(Edit38->Text);

	myFilho.myRateF1 = StrToInt(Edit4->Text);
	myFilho.myIntervalF1 = StrToInt(Edit5->Text);
	myFilho.mySaturation = StrToInt(Edit1->Text);

	myFilho.mydecay = StrToFloat(Edit17->Text);

	myFilho.myconf_FollowF1[0] = StrToInt(Edit34->Text);
	myFilho.myconf_FollowF1ThrMin[0] = StrToInt(Edit43->Text);
	myFilho.myconf_FollowF1ThrMax[0] = StrToInt(Edit42->Text);
	myFilho.myconf_AgainstF1[0] = StrToInt(Edit39->Text);
	myFilho.myconf_AgainstF1ThrMin[0] = StrToInt(Edit35->Text);
	myFilho.myconf_AgainstF1ThrMax[0] = StrToInt(Edit36->Text);
	myFilho.myconf_HardFollow[0] = CheckBox1->Checked;
	myFilho.myconf_ThrRelativo[0] = CheckBox2->Checked;
	myFilho.myconf_FollowF1[1] = StrToInt(Edit12->Text);
	myFilho.myconf_FollowF1ThrMin[1] = StrToInt(Edit13->Text);
	myFilho.myconf_FollowF1ThrMax[1] = StrToInt(Edit14->Text);
	myFilho.myconf_AgainstF1[1] = StrToInt(Edit24->Text);
	myFilho.myconf_AgainstF1ThrMin[1] = StrToInt(Edit23->Text);
	myFilho.myconf_AgainstF1ThrMax[1] = StrToInt(Edit21->Text);
	myFilho.myconf_HardFollow[1] = CheckBox3->Checked;
	myFilho.myconf_ThrRelativo[1] = CheckBox4->Checked;
	myFilho.myconf_FollowF1[2] = StrToInt(Edit25->Text);
	myFilho.myconf_FollowF1ThrMin[2] = StrToInt(Edit27->Text);
	myFilho.myconf_FollowF1ThrMax[2] = StrToInt(Edit28->Text);
	myFilho.myconf_AgainstF1[2] = StrToInt(Edit31->Text);
	myFilho.myconf_AgainstF1ThrMin[2] = StrToInt(Edit30->Text);
	myFilho.myconf_AgainstF1ThrMax[2] = StrToInt(Edit29->Text);
	myFilho.myconf_HardFollow[2] = CheckBox5->Checked;
	myFilho.myconf_ThrRelativo[2] = CheckBox6->Checked;

	myFilho.myestado_F1Deposit[0] = StrToInt(Edit19->Text);
	myFilho.myestado_TimeLimit[0] = StrToInt(Edit26->Text);
	myFilho.myestado_RaioSensor[0] = StrToInt(Edit44->Text);
	myFilho.myestado_PosSensor[0] = StrToInt(Edit45->Text);
	myFilho.myestado_BehaviorConfig[0] = StrToInt(Edit18->Text);
	myFilho.myestado_1EstadoProb[0] = StrToInt(Edit20->Text);
	myFilho.myestado_1EstadoProbValor[0] = StrToInt(Edit22->Text);
	myFilho.myestado_2EstadoProb[0] = StrToInt(Edit40->Text);
	myFilho.myestado_2EstadoProbValor[0] = StrToInt(Edit41->Text);
	myFilho.myestado_F1Deposit[1] = StrToInt(Edit53->Text);
	myFilho.myestado_TimeLimit[1] = StrToInt(Edit49->Text);
	myFilho.myestado_RaioSensor[1] = StrToInt(Edit52->Text);
	myFilho.myestado_PosSensor[1] = StrToInt(Edit50->Text);
	myFilho.myestado_BehaviorConfig[1] = StrToInt(Edit48->Text);
	myFilho.myestado_1EstadoProb[1] = StrToInt(Edit46->Text);
	myFilho.myestado_1EstadoProbValor[1] = StrToInt(Edit47->Text);
	myFilho.myestado_2EstadoProb[1] = StrToInt(Edit33->Text);
	myFilho.myestado_2EstadoProbValor[1] = StrToInt(Edit32->Text);
	myFilho.myestado_F1Deposit[2] = StrToInt(Edit80->Text);
	myFilho.myestado_TimeLimit[2] = StrToInt(Edit77->Text);
	myFilho.myestado_RaioSensor[2] = StrToInt(Edit79->Text);
	myFilho.myestado_PosSensor[2] = StrToInt(Edit78->Text);
	myFilho.myestado_BehaviorConfig[2] = StrToInt(Edit76->Text);
	myFilho.myestado_1EstadoProb[2] = StrToInt(Edit74->Text);
	myFilho.myestado_1EstadoProbValor[2] = StrToInt(Edit75->Text);
	myFilho.myestado_2EstadoProb[2] = StrToInt(Edit73->Text);
	myFilho.myestado_2EstadoProbValor[2] = StrToInt(Edit72->Text);
	myFilho.myestado_F1Deposit[3] = StrToInt(Edit71->Text);
	myFilho.myestado_TimeLimit[3] = StrToInt(Edit68->Text);
	myFilho.myestado_RaioSensor[3] = StrToInt(Edit70->Text);
	myFilho.myestado_PosSensor[3] = StrToInt(Edit69->Text);
	myFilho.myestado_BehaviorConfig[3] = StrToInt(Edit67->Text);
	myFilho.myestado_1EstadoProb[3] = StrToInt(Edit65->Text);
	myFilho.myestado_1EstadoProbValor[3] = StrToInt(Edit66->Text);
	myFilho.myestado_2EstadoProb[3] = StrToInt(Edit64->Text);
	myFilho.myestado_2EstadoProbValor[3] = StrToInt(Edit63->Text);
	myFilho.myestado_F1Deposit[4] = StrToInt(Edit62->Text);
	myFilho.myestado_TimeLimit[4] = StrToInt(Edit59->Text);
	myFilho.myestado_RaioSensor[4] = StrToInt(Edit61->Text);
	myFilho.myestado_PosSensor[4] = StrToInt(Edit60->Text);
	myFilho.myestado_BehaviorConfig[4] = StrToInt(Edit58->Text);
	myFilho.myestado_1EstadoProb[4] = StrToInt(Edit56->Text);
	myFilho.myestado_1EstadoProbValor[4] = StrToInt(Edit57->Text);
	myFilho.myestado_2EstadoProb[4] = StrToInt(Edit55->Text);
	myFilho.myestado_2EstadoProbValor[4] = StrToInt(Edit54->Text);

	myFilho.myanguloTransicao[0] = StrToInt(Edit2->Text);
	myFilho.myanguloTransicao[1] = StrToInt(Edit81->Text);
	myFilho.myanguloTransicao[2] = StrToInt(Edit82->Text);
	myFilho.myanguloTransicao[3] = StrToInt(Edit83->Text);
	myFilho.myanguloTransicao[4] = StrToInt(Edit84->Text);
	myFilho.myanguloTransicao[5] = StrToInt(Edit90->Text);
	myFilho.myanguloTransicao[6] = StrToInt(Edit85->Text);
	myFilho.myanguloTransicao[7] = StrToInt(Edit86->Text);
	myFilho.myanguloTransicao[8] = StrToInt(Edit87->Text);
	myFilho.myanguloTransicao[9] = StrToInt(Edit88->Text);
	myFilho.myanguloTransicao[10] = StrToInt(Edit89->Text);
	myFilho.myanguloTransicao[11] = StrToInt(Edit91->Text);
	myFilho.myanguloTransicao[12] = StrToInt(Edit16->Text);
	myFilho.myanguloTransicao[13] = StrToInt(Edit92->Text);

        if (Run->Down) {
                configurar(myWIDTH, myHEIGHT, myid_formigas, myF, myFormiga, myCasa, myComida, myF1, myObstaculo, myFilho.myprob_virar, myFilho.myRateF1, myFilho.myIntervalF1, myFilho.mySaturation, myFilho.mydecay, myFilho.myconf_FollowF1, myFilho.myconf_FollowF1ThrMin, myFilho.myconf_FollowF1ThrMax, myFilho.myconf_AgainstF1, myFilho.myconf_AgainstF1ThrMin, myFilho.myconf_AgainstF1ThrMax, myFilho.myconf_HardFollow, myFilho.myconf_ThrRelativo, myFilho.myestado_F1Deposit, myFilho.myestado_TimeLimit, myFilho.myestado_RaioSensor, myFilho.myestado_PosSensor, myFilho.myestado_BehaviorConfig, myFilho.myestado_1EstadoProb, myFilho.myestado_1EstadoProbValor, myFilho.myestado_2EstadoProb, myFilho.myestado_2EstadoProbValor, myFilho.myanguloTransicao);

                sair = 0;

                quantidade_comida = fitness(Refreshes);
                totalcomida += quantidade_comida;
                Label24->Caption = IntToStr(Updates);
                Label75->Caption = IntToStr(totalcomida);
                Label24->Refresh();
                Label75->Refresh();
                RefreshChao();
                Application->ProcessMessages();
                for(a=0; a<10; a++) {
                        Sleep(100);
                        Application->ProcessMessages();
                }

                sair = !Run->Down;

                while(!sair) {
                        quantidade_comida = fitness(Refreshes);
                        totalcomida += quantidade_comida;
			Label24->Caption = IntToStr(Updates);
			Label75->Caption = IntToStr(totalcomida);
			Label24->Refresh();
                        Label75->Refresh();
                        RefreshChao();
                        Application->ProcessMessages();
                }
        }
        else {
                sair=1;
        }
}

void __fastcall TForm1::SpeedButton1Click(TObject *Sender) {
        myWIDTH = StrToInt(Edit1->Text);
        myHEIGHT = StrToInt(Edit2->Text);
        Chao->Width = myWIDTH;
        Chao->Height = myHEIGHT;
}
//---------------------------------------------------------------------------
int comparar(const void *a, const void *b) {
	return(((parametros*)b)->nota - ((parametros*)a)->nota);
}
//---------------------------------------------------------------------------
void __fastcall geraFilhoRandomico(int i) {
	Filho[i].myprob_virar[1] = (rand() % 9);
	Filho[i].myprob_virar[2] = (rand() % 9);
	Filho[i].myprob_virar[3] = (rand() % 9);
	Filho[i].myprob_virar[4] = (rand() % 9);
	Filho[i].myprob_virar[5] = (rand() % 9);
	Filho[i].myprob_virar[6] = (rand() % 9);

	Filho[i].myRateF1 = (rand() % 5);
	Filho[i].myIntervalF1 = (rand() % 6);
	Filho[i].mySaturation = (rand() % 6);

	Filho[i].mydecay = (rand() % 12);

	Filho[i].myconf_FollowF1[0] = 19 - (rand() % 20);
	Filho[i].myconf_FollowF1ThrMin[0] = (rand() % 18);
	Filho[i].myconf_FollowF1ThrMax[0] = (rand() % 18);
	Filho[i].myconf_AgainstF1[0] = (rand() % ((19-Filho[i].myconf_FollowF1[0])+1));
	Filho[i].myconf_AgainstF1ThrMin[0] = (rand() % 18);
	Filho[i].myconf_AgainstF1ThrMax[0] = (rand() % 18);
	Filho[i].myconf_HardFollow[0] = (rand() % 2);
	Filho[i].myconf_ThrRelativo[0] = (rand() % 2);
	Filho[i].myconf_FollowF1[1] = 19 - (rand() % 20);
	Filho[i].myconf_FollowF1ThrMin[1] = (rand() % 18);
	Filho[i].myconf_FollowF1ThrMax[1] = (rand() % 18);
	Filho[i].myconf_AgainstF1[1] = (rand() % ((19-Filho[i].myconf_FollowF1[1])+1));
	Filho[i].myconf_AgainstF1ThrMin[1] = (rand() % 18);
	Filho[i].myconf_AgainstF1ThrMax[1] = (rand() % 18);
	Filho[i].myconf_HardFollow[1] = (rand() % 2);
	Filho[i].myconf_ThrRelativo[1] = (rand() % 2);
	Filho[i].myconf_FollowF1[2] = 19 - (rand() % 20);
	Filho[i].myconf_FollowF1ThrMin[2] = (rand() % 18);
	Filho[i].myconf_FollowF1ThrMax[2] = (rand() % 18);
	Filho[i].myconf_AgainstF1[2] = (rand() % ((19-Filho[i].myconf_FollowF1[2])+1));
	Filho[i].myconf_AgainstF1ThrMin[2] = (rand() % 18);
	Filho[i].myconf_AgainstF1ThrMax[2] = (rand() % 18);
	Filho[i].myconf_HardFollow[2] = (rand() % 2);
	Filho[i].myconf_ThrRelativo[2] = (rand() % 2);

	Filho[i].myestado_F1Deposit[0] = (rand() % 6);
	Filho[i].myestado_TimeLimit[0] = (rand() % 13);
	Filho[i].myestado_RaioSensor[0] = (rand() % 3);
	Filho[i].myestado_PosSensor[0] = (rand() % 6);
	Filho[i].myestado_BehaviorConfig[0] = (rand() % 3)+1;
//	Filho[i].myestado_1EstadoProb[0] = (rand() % 2);
	Filho[i].myestado_1EstadoProbValor[0] = (rand() % 17);
//	Filho[i].myestado_2EstadoProb[0] = (rand() % 2);
	Filho[i].myestado_2EstadoProbValor[0] = (rand() % 17);
	Filho[i].myestado_F1Deposit[1] = (rand() % 6);
	Filho[i].myestado_TimeLimit[1] = (rand() % 13);
	Filho[i].myestado_RaioSensor[1] = (rand() % 3);
	Filho[i].myestado_PosSensor[1] = (rand() % 6);
	Filho[i].myestado_BehaviorConfig[1] = (rand() % 3)+1;
//	Filho[i].myestado_1EstadoProb[1] = (rand() % 1);
	Filho[i].myestado_1EstadoProbValor[1] = (rand() % 17);
//	Filho[i].myestado_2EstadoProb[1] = (rand() % 1);
//	Filho[i].myestado_2EstadoProbValor[1] = (rand() % 17);
	Filho[i].myestado_F1Deposit[2] = (rand() % 6);
	Filho[i].myestado_TimeLimit[2] = (rand() % 13);
	Filho[i].myestado_RaioSensor[2] = (rand() % 3);
	Filho[i].myestado_PosSensor[2] = (rand() % 6);
	Filho[i].myestado_BehaviorConfig[2] = (rand() % 3)+1;
//	Filho[i].myestado_1EstadoProb[2] = (rand() % 1);
	Filho[i].myestado_1EstadoProbValor[2] = (rand() % 17);
//	Filho[i].myestado_2EstadoProb[2] = (rand() % 1);
//	Filho[i].myestado_2EstadoProbValor[2] = (rand() % 17);
	Filho[i].myestado_F1Deposit[3] = (rand() % 6);
	Filho[i].myestado_TimeLimit[3] = (rand() % 13);
	Filho[i].myestado_RaioSensor[3] = (rand() % 3);
	Filho[i].myestado_PosSensor[3] = (rand() % 6);
	Filho[i].myestado_BehaviorConfig[3] = (rand() % 3)+1;
//	Filho[i].myestado_1EstadoProb[3] = (rand() % 2);
	Filho[i].myestado_1EstadoProbValor[3] = (rand() % 17);
//	Filho[i].myestado_2EstadoProb[3] = (rand() % 2);
	Filho[i].myestado_2EstadoProbValor[3] = (rand() % 17);
	Filho[i].myestado_F1Deposit[4] = (rand() % 6);
	Filho[i].myestado_TimeLimit[4] = (rand() % 13);
	Filho[i].myestado_RaioSensor[4] = (rand() % 3);
	Filho[i].myestado_PosSensor[4] = (rand() % 6);
	Filho[i].myestado_BehaviorConfig[4] = (rand() % 3)+1;
//	Filho[i].myestado_1EstadoProb[4] = (rand() % 2);
	Filho[i].myestado_1EstadoProbValor[4] = (rand() % 17);
//	Filho[i].myestado_2EstadoProb[4] = (rand() % 2);
	Filho[i].myestado_2EstadoProbValor[4] = (rand() % 17);

	Filho[i].myanguloTransicao[0] = (rand() % 9);
	Filho[i].myanguloTransicao[1] = (rand() % 9);
	Filho[i].myanguloTransicao[2] = (rand() % 9);
	Filho[i].myanguloTransicao[3] = (rand() % 9);
	Filho[i].myanguloTransicao[4] = (rand() % 9);
	Filho[i].myanguloTransicao[5] = (rand() % 9);
	Filho[i].myanguloTransicao[6] = (rand() % 9);
	Filho[i].myanguloTransicao[7] = (rand() % 9);
	Filho[i].myanguloTransicao[8] = (rand() % 9);
	Filho[i].myanguloTransicao[9] = (rand() % 9);
	Filho[i].myanguloTransicao[10] = (rand() % 9);
	Filho[i].myanguloTransicao[11] = (rand() % 9);
	Filho[i].myanguloTransicao[12] = (rand() % 9);
	Filho[i].myanguloTransicao[13] = (rand() % 9);
}
//---------------------------------------------------------------------------
int __fastcall do_crossover(int p1, int p2) {
        static int crossvalue;
        static int p;

        return (p1+p2)/2;

         
        crossvalue = (p1+p2)/2;
        p = rand() % 100;

        if (p < 25) {
                return max(0, p1 - crossvalue);
        }
        else if (p < 50) {
                return p1 + crossvalue;       // =
        }
        else if (p < 75) {
                return max(0, p2 - crossvalue);       // =
        }
        else {
                return p2 + crossvalue;
        }
}
//---------------------------------------------------------------------------
void __fastcall cruza(int i, int f1, int f2) {
        Filho[i] = TmpFilho[f1];

        // cross over
	if (rand()%1000 < crossover) Filho[i].myprob_virar[1] = do_crossover(TmpFilho[f1].myprob_virar[1], TmpFilho[f2].myprob_virar[1]);
	if (rand()%1000 < crossover) Filho[i].myprob_virar[2] = do_crossover(TmpFilho[f1].myprob_virar[2], TmpFilho[f2].myprob_virar[2]);
	if (rand()%1000 < crossover) Filho[i].myprob_virar[3] = do_crossover(TmpFilho[f1].myprob_virar[3], TmpFilho[f2].myprob_virar[3]);
	if (rand()%1000 < crossover) Filho[i].myprob_virar[4] = do_crossover(TmpFilho[f1].myprob_virar[4], TmpFilho[f2].myprob_virar[4]);
	if (rand()%1000 < crossover) Filho[i].myprob_virar[5] = do_crossover(TmpFilho[f1].myprob_virar[5], TmpFilho[f2].myprob_virar[5]);
	if (rand()%1000 < crossover) Filho[i].myprob_virar[6] = do_crossover(TmpFilho[f1].myprob_virar[6], TmpFilho[f2].myprob_virar[6]);

	if (rand()%1000 < crossover) Filho[i].myRateF1 = do_crossover(TmpFilho[f1].myRateF1, TmpFilho[f2].myRateF1);
	if (rand()%1000 < crossover) Filho[i].myIntervalF1 = do_crossover(TmpFilho[f1].myIntervalF1, TmpFilho[f2].myIntervalF1);
	if (rand()%1000 < crossover) Filho[i].mySaturation = do_crossover(TmpFilho[f1].mySaturation, TmpFilho[f2].mySaturation);

	if (rand()%1000 < crossover) Filho[i].mydecay = do_crossover(TmpFilho[f1].mydecay, TmpFilho[f2].mydecay);

	if (rand()%1000 < crossover) Filho[i].myconf_FollowF1[0] = do_crossover(TmpFilho[f1].myconf_FollowF1[0], TmpFilho[f2].myconf_FollowF1[0]);
	if (rand()%1000 < crossover) Filho[i].myconf_FollowF1ThrMin[0] = do_crossover(TmpFilho[f1].myconf_FollowF1ThrMin[0], TmpFilho[f2].myconf_FollowF1ThrMin[0]);
	if (rand()%1000 < crossover) Filho[i].myconf_FollowF1ThrMax[0] = do_crossover(TmpFilho[f1].myconf_FollowF1ThrMax[0], TmpFilho[f2].myconf_FollowF1ThrMax[0]);
	if (rand()%1000 < crossover) Filho[i].myconf_AgainstF1[0] = do_crossover(TmpFilho[f1].myconf_AgainstF1[0], TmpFilho[f2].myconf_AgainstF1[0]);
	if (rand()%1000 < crossover) Filho[i].myconf_AgainstF1ThrMin[0] = do_crossover(TmpFilho[f1].myconf_AgainstF1ThrMin[0], TmpFilho[f2].myconf_AgainstF1ThrMin[0]);
	if (rand()%1000 < crossover) Filho[i].myconf_AgainstF1ThrMax[0] = do_crossover(TmpFilho[f1].myconf_AgainstF1ThrMax[0], TmpFilho[f2].myconf_AgainstF1ThrMax[0]);
	if (rand()%1000 < crossover) Filho[i].myconf_HardFollow[0] = do_crossover(TmpFilho[f1].myconf_HardFollow[0], TmpFilho[f2].myconf_HardFollow[0]);
	if (rand()%1000 < crossover) Filho[i].myconf_ThrRelativo[0] = do_crossover(TmpFilho[f1].myconf_ThrRelativo[0], TmpFilho[f2].myconf_ThrRelativo[0]);
	if (rand()%1000 < crossover) Filho[i].myconf_FollowF1[1] = do_crossover(TmpFilho[f1].myconf_FollowF1[1], TmpFilho[f2].myconf_FollowF1[1]);
	if (rand()%1000 < crossover) Filho[i].myconf_FollowF1ThrMin[1] = do_crossover(TmpFilho[f1].myconf_FollowF1ThrMin[1], TmpFilho[f2].myconf_FollowF1ThrMin[1]);
	if (rand()%1000 < crossover) Filho[i].myconf_FollowF1ThrMax[1] = do_crossover(TmpFilho[f1].myconf_FollowF1ThrMax[1], TmpFilho[f2].myconf_FollowF1ThrMax[1]);
	if (rand()%1000 < crossover) Filho[i].myconf_AgainstF1[1] = do_crossover(TmpFilho[f1].myconf_AgainstF1[1], TmpFilho[f2].myconf_AgainstF1[1]);
	if (rand()%1000 < crossover) Filho[i].myconf_AgainstF1ThrMin[1] = do_crossover(TmpFilho[f1].myconf_AgainstF1ThrMin[1], TmpFilho[f2].myconf_AgainstF1ThrMin[1]);
	if (rand()%1000 < crossover) Filho[i].myconf_AgainstF1ThrMax[1] = do_crossover(TmpFilho[f1].myconf_AgainstF1ThrMax[1], TmpFilho[f2].myconf_AgainstF1ThrMax[1]);
	if (rand()%1000 < crossover) Filho[i].myconf_HardFollow[1] = do_crossover(TmpFilho[f1].myconf_HardFollow[1], TmpFilho[f2].myconf_HardFollow[1]);
	if (rand()%1000 < crossover) Filho[i].myconf_ThrRelativo[1] = do_crossover(TmpFilho[f1].myconf_ThrRelativo[1], TmpFilho[f2].myconf_ThrRelativo[1]);
	if (rand()%1000 < crossover) Filho[i].myconf_FollowF1[2] = do_crossover(TmpFilho[f1].myconf_FollowF1[2], TmpFilho[f2].myconf_FollowF1[2]);
	if (rand()%1000 < crossover) Filho[i].myconf_FollowF1ThrMin[2] = do_crossover(TmpFilho[f1].myconf_FollowF1ThrMin[2], TmpFilho[f2].myconf_FollowF1ThrMin[2]);
	if (rand()%1000 < crossover) Filho[i].myconf_FollowF1ThrMax[2] = do_crossover(TmpFilho[f1].myconf_FollowF1ThrMax[2], TmpFilho[f2].myconf_FollowF1ThrMax[2]);
	if (rand()%1000 < crossover) Filho[i].myconf_AgainstF1[2] = do_crossover(TmpFilho[f1].myconf_AgainstF1[2], TmpFilho[f2].myconf_AgainstF1[2]);
	if (rand()%1000 < crossover) Filho[i].myconf_AgainstF1ThrMin[2] = do_crossover(TmpFilho[f1].myconf_AgainstF1ThrMin[2], TmpFilho[f2].myconf_AgainstF1ThrMin[2]);
	if (rand()%1000 < crossover) Filho[i].myconf_AgainstF1ThrMax[2] = do_crossover(TmpFilho[f1].myconf_AgainstF1ThrMax[2], TmpFilho[f2].myconf_AgainstF1ThrMax[2]);
	if (rand()%1000 < crossover) Filho[i].myconf_HardFollow[2] = do_crossover(TmpFilho[f1].myconf_HardFollow[2], TmpFilho[f2].myconf_HardFollow[2]);
	if (rand()%1000 < crossover) Filho[i].myconf_ThrRelativo[2] = do_crossover(TmpFilho[f1].myconf_ThrRelativo[2], TmpFilho[f2].myconf_ThrRelativo[2]);

	if (rand()%1000 < crossover) Filho[i].myestado_F1Deposit[0] = do_crossover(TmpFilho[f1].myestado_F1Deposit[0], TmpFilho[f2].myestado_F1Deposit[0]);
	if (rand()%1000 < crossover) Filho[i].myestado_TimeLimit[0] = do_crossover(TmpFilho[f1].myestado_TimeLimit[0], TmpFilho[f2].myestado_TimeLimit[0]);
	if (rand()%1000 < crossover) Filho[i].myestado_RaioSensor[0] = do_crossover(TmpFilho[f1].myestado_RaioSensor[0], TmpFilho[f2].myestado_RaioSensor[0]);
	if (rand()%1000 < crossover) Filho[i].myestado_PosSensor[0] = do_crossover(TmpFilho[f1].myestado_PosSensor[0], TmpFilho[f2].myestado_PosSensor[0]);
	if (rand()%1000 < crossover) Filho[i].myestado_BehaviorConfig[0] = do_crossover(TmpFilho[f1].myestado_BehaviorConfig[0], TmpFilho[f2].myestado_BehaviorConfig[0]);
//	if (rand()%1000 < crossover) Filho[i].myestado_1EstadoProb[0] = do_crossover(TmpFilho[f1].myestado_1EstadoProb[0], TmpFilho[f2].myestado_1EstadoProb[0]);
	if (rand()%1000 < crossover) Filho[i].myestado_1EstadoProbValor[0] = do_crossover(TmpFilho[f1].myestado_1EstadoProbValor[0], TmpFilho[f2].myestado_1EstadoProbValor[0]);
//	if (rand()%1000 < crossover) Filho[i].myestado_2EstadoProb[0] = do_crossover(TmpFilho[f1].myestado_2EstadoProb[0], TmpFilho[f2].myestado_2EstadoProb[0]);
	if (rand()%1000 < crossover) Filho[i].myestado_2EstadoProbValor[0] = do_crossover(TmpFilho[f1].myestado_2EstadoProbValor[0], TmpFilho[f2].myestado_2EstadoProbValor[0]);
	if (rand()%1000 < crossover) Filho[i].myestado_F1Deposit[1] = do_crossover(TmpFilho[f1].myestado_F1Deposit[1], TmpFilho[f2].myestado_F1Deposit[1]);
	if (rand()%1000 < crossover) Filho[i].myestado_TimeLimit[1] = do_crossover(TmpFilho[f1].myestado_TimeLimit[1], TmpFilho[f2].myestado_TimeLimit[1]);
	if (rand()%1000 < crossover) Filho[i].myestado_RaioSensor[1] = do_crossover(TmpFilho[f1].myestado_RaioSensor[1], TmpFilho[f2].myestado_RaioSensor[1]);
	if (rand()%1000 < crossover) Filho[i].myestado_PosSensor[1] = do_crossover(TmpFilho[f1].myestado_PosSensor[1], TmpFilho[f2].myestado_PosSensor[1]);
	if (rand()%1000 < crossover) Filho[i].myestado_BehaviorConfig[1] = do_crossover(TmpFilho[f1].myestado_BehaviorConfig[1], TmpFilho[f2].myestado_BehaviorConfig[1]);
//	if (rand()%1000 < crossover) Filho[i].myestado_1EstadoProb[1] = do_crossover(TmpFilho[f1].myestado_1EstadoProb[1], TmpFilho[f2].myestado_1EstadoProb[1]);
	if (rand()%1000 < crossover) Filho[i].myestado_1EstadoProbValor[1] = do_crossover(TmpFilho[f1].myestado_1EstadoProbValor[1], TmpFilho[f2].myestado_1EstadoProbValor[1]);
//	if (rand()%1000 < crossover) Filho[i].myestado_2EstadoProb[1] = do_crossover(TmpFilho[f1].myestado_2EstadoProb[1], TmpFilho[f2].myestado_2EstadoProb[1]);
//	if (rand()%1000 < crossover) Filho[i].myestado_2EstadoProbValor[1] = do_crossover(TmpFilho[f1].myestado_2EstadoProbValor[1], TmpFilho[f2].myestado_2EstadoProbValor[1]);
	if (rand()%1000 < crossover) Filho[i].myestado_F1Deposit[2] = do_crossover(TmpFilho[f1].myestado_F1Deposit[2], TmpFilho[f2].myestado_F1Deposit[2]);
	if (rand()%1000 < crossover) Filho[i].myestado_TimeLimit[2] = do_crossover(TmpFilho[f1].myestado_TimeLimit[2], TmpFilho[f2].myestado_TimeLimit[2]);
	if (rand()%1000 < crossover) Filho[i].myestado_RaioSensor[2] = do_crossover(TmpFilho[f1].myestado_RaioSensor[2], TmpFilho[f2].myestado_RaioSensor[2]);
	if (rand()%1000 < crossover) Filho[i].myestado_PosSensor[2] = do_crossover(TmpFilho[f1].myestado_PosSensor[2], TmpFilho[f2].myestado_PosSensor[2]);
	if (rand()%1000 < crossover) Filho[i].myestado_BehaviorConfig[2] = do_crossover(TmpFilho[f1].myestado_BehaviorConfig[2], TmpFilho[f2].myestado_BehaviorConfig[2]);
//	if (rand()%1000 < crossover) Filho[i].myestado_1EstadoProb[2] = do_crossover(TmpFilho[f1].myestado_1EstadoProb[2], TmpFilho[f2].myestado_1EstadoProb[2]);
	if (rand()%1000 < crossover) Filho[i].myestado_1EstadoProbValor[2] = do_crossover(TmpFilho[f1].myestado_1EstadoProbValor[2], TmpFilho[f2].myestado_1EstadoProbValor[2]);
//	if (rand()%1000 < crossover) Filho[i].myestado_2EstadoProb[2] = do_crossover(TmpFilho[f1].myestado_2EstadoProb[2], TmpFilho[f2].myestado_2EstadoProb[2]);
//	if (rand()%1000 < crossover) Filho[i].myestado_2EstadoProbValor[2] = do_crossover(TmpFilho[f1].myestado_2EstadoProbValor[2], TmpFilho[f2].myestado_2EstadoProbValor[2]);
	if (rand()%1000 < crossover) Filho[i].myestado_F1Deposit[3] = do_crossover(TmpFilho[f1].myestado_F1Deposit[3], TmpFilho[f2].myestado_F1Deposit[3]);
	if (rand()%1000 < crossover) Filho[i].myestado_TimeLimit[3] = do_crossover(TmpFilho[f1].myestado_TimeLimit[3], TmpFilho[f2].myestado_TimeLimit[3]);
	if (rand()%1000 < crossover) Filho[i].myestado_RaioSensor[3] = do_crossover(TmpFilho[f1].myestado_RaioSensor[3], TmpFilho[f2].myestado_RaioSensor[3]);
	if (rand()%1000 < crossover) Filho[i].myestado_PosSensor[3] = do_crossover(TmpFilho[f1].myestado_PosSensor[3], TmpFilho[f2].myestado_PosSensor[3]);
	if (rand()%1000 < crossover) Filho[i].myestado_BehaviorConfig[3] = do_crossover(TmpFilho[f1].myestado_BehaviorConfig[3], TmpFilho[f2].myestado_BehaviorConfig[3]);
//	if (rand()%1000 < crossover) Filho[i].myestado_1EstadoProb[3] = do_crossover(TmpFilho[f1].myestado_1EstadoProb[3], TmpFilho[f2].myestado_1EstadoProb[3]);
	if (rand()%1000 < crossover) Filho[i].myestado_1EstadoProbValor[3] = do_crossover(TmpFilho[f1].myestado_1EstadoProbValor[3], TmpFilho[f2].myestado_1EstadoProbValor[3]);
//	if (rand()%1000 < crossover) Filho[i].myestado_2EstadoProb[3] = do_crossover(TmpFilho[f1].myestado_2EstadoProb[3], TmpFilho[f2].myestado_2EstadoProb[3]);
	if (rand()%1000 < crossover) Filho[i].myestado_2EstadoProbValor[3] = do_crossover(TmpFilho[f1].myestado_2EstadoProbValor[3], TmpFilho[f2].myestado_2EstadoProbValor[3]);
	if (rand()%1000 < crossover) Filho[i].myestado_F1Deposit[4] = do_crossover(TmpFilho[f1].myestado_F1Deposit[4], TmpFilho[f2].myestado_F1Deposit[4]);
	if (rand()%1000 < crossover) Filho[i].myestado_TimeLimit[4] = do_crossover(TmpFilho[f1].myestado_TimeLimit[4], TmpFilho[f2].myestado_TimeLimit[4]);
	if (rand()%1000 < crossover) Filho[i].myestado_RaioSensor[4] = do_crossover(TmpFilho[f1].myestado_RaioSensor[4], TmpFilho[f2].myestado_RaioSensor[4]);
	if (rand()%1000 < crossover) Filho[i].myestado_PosSensor[4] = do_crossover(TmpFilho[f1].myestado_PosSensor[4], TmpFilho[f2].myestado_PosSensor[4]);
	if (rand()%1000 < crossover) Filho[i].myestado_BehaviorConfig[4] = do_crossover(TmpFilho[f1].myestado_BehaviorConfig[4], TmpFilho[f2].myestado_BehaviorConfig[4]);
//	if (rand()%1000 < crossover) Filho[i].myestado_1EstadoProb[4] = do_crossover(TmpFilho[f1].myestado_1EstadoProb[4], TmpFilho[f2].myestado_1EstadoProb[4]);
	if (rand()%1000 < crossover) Filho[i].myestado_1EstadoProbValor[4] = do_crossover(TmpFilho[f1].myestado_1EstadoProbValor[4], TmpFilho[f2].myestado_1EstadoProbValor[4]);
//	if (rand()%1000 < crossover) Filho[i].myestado_2EstadoProb[4] = do_crossover(TmpFilho[f1].myestado_2EstadoProb[4], TmpFilho[f2].myestado_2EstadoProb[4]);
	if (rand()%1000 < crossover) Filho[i].myestado_2EstadoProbValor[4] = do_crossover(TmpFilho[f1].myestado_2EstadoProbValor[4], TmpFilho[f2].myestado_2EstadoProbValor[4]);

	if (rand()%1000 < crossover) Filho[i].myanguloTransicao[0] = do_crossover(TmpFilho[f1].myanguloTransicao[0], TmpFilho[f2].myanguloTransicao[0]);
	if (rand()%1000 < crossover) Filho[i].myanguloTransicao[1] = do_crossover(TmpFilho[f1].myanguloTransicao[1], TmpFilho[f2].myanguloTransicao[1]);
	if (rand()%1000 < crossover) Filho[i].myanguloTransicao[2] = do_crossover(TmpFilho[f1].myanguloTransicao[2], TmpFilho[f2].myanguloTransicao[2]);
	if (rand()%1000 < crossover) Filho[i].myanguloTransicao[3] = do_crossover(TmpFilho[f1].myanguloTransicao[3], TmpFilho[f2].myanguloTransicao[3]);
	if (rand()%1000 < crossover) Filho[i].myanguloTransicao[4] = do_crossover(TmpFilho[f1].myanguloTransicao[4], TmpFilho[f2].myanguloTransicao[4]);
	if (rand()%1000 < crossover) Filho[i].myanguloTransicao[5] = do_crossover(TmpFilho[f1].myanguloTransicao[5], TmpFilho[f2].myanguloTransicao[5]);
	if (rand()%1000 < crossover) Filho[i].myanguloTransicao[6] = do_crossover(TmpFilho[f1].myanguloTransicao[6], TmpFilho[f2].myanguloTransicao[6]);
	if (rand()%1000 < crossover) Filho[i].myanguloTransicao[7] = do_crossover(TmpFilho[f1].myanguloTransicao[7], TmpFilho[f2].myanguloTransicao[7]);
	if (rand()%1000 < crossover) Filho[i].myanguloTransicao[8] = do_crossover(TmpFilho[f1].myanguloTransicao[8], TmpFilho[f2].myanguloTransicao[8]);
	if (rand()%1000 < crossover) Filho[i].myanguloTransicao[9] = do_crossover(TmpFilho[f1].myanguloTransicao[9], TmpFilho[f2].myanguloTransicao[9]);
	if (rand()%1000 < crossover) Filho[i].myanguloTransicao[10] = do_crossover(TmpFilho[f1].myanguloTransicao[10], TmpFilho[f2].myanguloTransicao[10]);
	if (rand()%1000 < crossover) Filho[i].myanguloTransicao[11] = do_crossover(TmpFilho[f1].myanguloTransicao[11], TmpFilho[f2].myanguloTransicao[11]);
	if (rand()%1000 < crossover) Filho[i].myanguloTransicao[12] = do_crossover(TmpFilho[f1].myanguloTransicao[12], TmpFilho[f2].myanguloTransicao[12]);
	if (rand()%1000 < crossover) Filho[i].myanguloTransicao[13] = do_crossover(TmpFilho[f1].myanguloTransicao[13], TmpFilho[f2].myanguloTransicao[13]);


        // mutacao (10% de chance de mudar cada par�metro entre -25% a 25%)

	if (rand()%1000 < mutacao) Filho[i].myprob_virar[1] += Filho[i].myprob_virar[1]*(porcentagemmut) - (rand()%((int)(Filho[i].myprob_virar[1]*(porcentagemmut*2))+1));
	if (rand()%1000 < mutacao) Filho[i].myprob_virar[2] += Filho[i].myprob_virar[2]*(porcentagemmut) - (rand()%((int)(Filho[i].myprob_virar[2]*(porcentagemmut*2))+1));
	if (rand()%1000 < mutacao) Filho[i].myprob_virar[3] += Filho[i].myprob_virar[3]*(porcentagemmut) - (rand()%((int)(Filho[i].myprob_virar[3]*(porcentagemmut*2))+1));
	if (rand()%1000 < mutacao) Filho[i].myprob_virar[4] += Filho[i].myprob_virar[4]*(porcentagemmut) - (rand()%((int)(Filho[i].myprob_virar[4]*(porcentagemmut*2))+1));
	if (rand()%1000 < mutacao) Filho[i].myprob_virar[5] += Filho[i].myprob_virar[5]*(porcentagemmut) - (rand()%((int)(Filho[i].myprob_virar[5]*(porcentagemmut*2))+1));
	if (rand()%1000 < mutacao) Filho[i].myprob_virar[6] += Filho[i].myprob_virar[6]*(porcentagemmut) - (rand()%((int)(Filho[i].myprob_virar[6]*(porcentagemmut*2))+1));

	if (rand()%1000 < mutacao) Filho[i].myRateF1 += Filho[i].myRateF1*(porcentagemmut) - (rand()%((int)(Filho[i].myRateF1*(porcentagemmut*2))+1));
	if (rand()%1000 < mutacao) Filho[i].myIntervalF1 += Filho[i].myIntervalF1*(porcentagemmut) - (rand()%((int)(Filho[i].myIntervalF1*(porcentagemmut*2))+1));
	if (rand()%1000 < mutacao) Filho[i].mySaturation += Filho[i].mySaturation*(porcentagemmut) - (rand()%((int)(Filho[i].mySaturation*(porcentagemmut*2))+1));

	if (rand()%1000 < mutacao) Filho[i].mydecay += Filho[i].mydecay*(porcentagemmut) - (rand()%((int)(Filho[i].mydecay*(porcentagemmut*2))+1));

	if (rand()%1000 < mutacao) Filho[i].myconf_FollowF1[0] += Filho[i].myconf_FollowF1[0]*(porcentagemmut) - (rand()%((int)(Filho[i].myconf_FollowF1[0]*(porcentagemmut*2))+1));
	if (rand()%1000 < mutacao) Filho[i].myconf_FollowF1ThrMin[0] += Filho[i].myconf_FollowF1ThrMin[0]*(porcentagemmut) - (rand()%((int)(Filho[i].myconf_FollowF1ThrMin[0]*(porcentagemmut*2))+1));
	if (rand()%1000 < mutacao) Filho[i].myconf_FollowF1ThrMax[0] += Filho[i].myconf_FollowF1ThrMax[0]*(porcentagemmut) - (rand()%((int)(Filho[i].myconf_FollowF1ThrMax[0]*(porcentagemmut*2))+1));
	if (rand()%1000 < mutacao) Filho[i].myconf_AgainstF1[0] += Filho[i].myconf_AgainstF1[0]*(porcentagemmut) - (rand()%((int)(Filho[i].myconf_AgainstF1[0]*(porcentagemmut*2))+1));
	if (rand()%1000 < mutacao) Filho[i].myconf_AgainstF1ThrMin[0] += Filho[i].myconf_AgainstF1ThrMin[0]*(porcentagemmut) - (rand()%((int)(Filho[i].myconf_AgainstF1ThrMin[0]*(porcentagemmut*2))+1));
	if (rand()%1000 < mutacao) Filho[i].myconf_AgainstF1ThrMax[0] += Filho[i].myconf_AgainstF1ThrMax[0]*(porcentagemmut) - (rand()%((int)(Filho[i].myconf_AgainstF1ThrMax[0]*(porcentagemmut*2))+1));
	if (rand()%1000 < mutacao) Filho[i].myconf_HardFollow[0] = !Filho[i].myconf_HardFollow[0];
	if (rand()%1000 < mutacao) Filho[i].myconf_ThrRelativo[0] = !Filho[i].myconf_ThrRelativo[0];
	if (rand()%1000 < mutacao) Filho[i].myconf_FollowF1[1] += Filho[i].myconf_FollowF1[1]*(porcentagemmut) - (rand()%((int)(Filho[i].myconf_FollowF1[1]*(porcentagemmut*2))+1));
	if (rand()%1000 < mutacao) Filho[i].myconf_FollowF1ThrMin[1] += Filho[i].myconf_FollowF1ThrMin[1]*(porcentagemmut) - (rand()%((int)(Filho[i].myconf_FollowF1ThrMin[1]*(porcentagemmut*2))+1));
	if (rand()%1000 < mutacao) Filho[i].myconf_FollowF1ThrMax[1] += Filho[i].myconf_FollowF1ThrMax[1]*(porcentagemmut) - (rand()%((int)(Filho[i].myconf_FollowF1ThrMax[1]*(porcentagemmut*2))+1));
	if (rand()%1000 < mutacao) Filho[i].myconf_AgainstF1[1] += Filho[i].myconf_AgainstF1[1]*(porcentagemmut) - (rand()%((int)(Filho[i].myconf_AgainstF1[1]*(porcentagemmut*2))+1));
	if (rand()%1000 < mutacao) Filho[i].myconf_AgainstF1ThrMin[1] += Filho[i].myconf_AgainstF1ThrMin[1]*(porcentagemmut) - (rand()%((int)(Filho[i].myconf_AgainstF1ThrMin[1]*(porcentagemmut*2))+1));
	if (rand()%1000 < mutacao) Filho[i].myconf_AgainstF1ThrMax[1] += Filho[i].myconf_AgainstF1ThrMax[1]*(porcentagemmut) - (rand()%((int)(Filho[i].myconf_AgainstF1ThrMax[1]*(porcentagemmut*2))+1));
	if (rand()%1000 < mutacao) Filho[i].myconf_HardFollow[1] = !Filho[i].myconf_HardFollow[1];
	if (rand()%1000 < mutacao) Filho[i].myconf_ThrRelativo[1] = !Filho[i].myconf_ThrRelativo[1];
	if (rand()%1000 < mutacao) Filho[i].myconf_FollowF1[2] += Filho[i].myconf_FollowF1[2]*(porcentagemmut) - (rand()%((int)(Filho[i].myconf_FollowF1[2]*(porcentagemmut*2))+1));
	if (rand()%1000 < mutacao) Filho[i].myconf_FollowF1ThrMin[2] += Filho[i].myconf_FollowF1ThrMin[2]*(porcentagemmut) - (rand()%((int)(Filho[i].myconf_FollowF1ThrMin[2]*(porcentagemmut*2))+1));
	if (rand()%1000 < mutacao) Filho[i].myconf_FollowF1ThrMax[2] += Filho[i].myconf_FollowF1ThrMax[2]*(porcentagemmut) - (rand()%((int)(Filho[i].myconf_FollowF1ThrMax[2]*(porcentagemmut*2))+1));
	if (rand()%1000 < mutacao) Filho[i].myconf_AgainstF1[2] += Filho[i].myconf_AgainstF1[2]*(porcentagemmut) - (rand()%((int)(Filho[i].myconf_AgainstF1[2]*(porcentagemmut*2))+1));
	if (rand()%1000 < mutacao) Filho[i].myconf_AgainstF1ThrMin[2] += Filho[i].myconf_AgainstF1ThrMin[2]*(porcentagemmut) - (rand()%((int)(Filho[i].myconf_AgainstF1ThrMin[2]*(porcentagemmut*2))+1));
	if (rand()%1000 < mutacao) Filho[i].myconf_AgainstF1ThrMax[2] += Filho[i].myconf_AgainstF1ThrMax[2]*(porcentagemmut) - (rand()%((int)(Filho[i].myconf_AgainstF1ThrMax[2]*(porcentagemmut*2))+1));
	if (rand()%1000 < mutacao) Filho[i].myconf_HardFollow[2] = !Filho[i].myconf_HardFollow[2];
	if (rand()%1000 < mutacao) Filho[i].myconf_ThrRelativo[2] = !Filho[i].myconf_ThrRelativo[2];

	if (rand()%1000 < mutacao) Filho[i].myestado_F1Deposit[0] += Filho[i].myestado_F1Deposit[0]*(porcentagemmut) - (rand()%((int)(Filho[i].myestado_F1Deposit[0]*(porcentagemmut*2))+1));
	if (rand()%1000 < mutacao) Filho[i].myestado_TimeLimit[0] += Filho[i].myestado_TimeLimit[0]*(porcentagemmut) - (rand()%((int)(Filho[i].myestado_TimeLimit[0]*(porcentagemmut*2))+1));
	if (rand()%1000 < mutacao) Filho[i].myestado_RaioSensor[0] += Filho[i].myestado_RaioSensor[0]*(porcentagemmut) - (rand()%((int)(Filho[i].myestado_RaioSensor[0]*(porcentagemmut*2))+1));
	if (rand()%1000 < mutacao) Filho[i].myestado_PosSensor[0] += Filho[i].myestado_PosSensor[0]*(porcentagemmut) - (rand()%((int)(Filho[i].myestado_PosSensor[0]*(porcentagemmut*2))+1));
	if (rand()%1000 < mutacao) Filho[i].myestado_BehaviorConfig[0] += Filho[i].myestado_BehaviorConfig[0]*(porcentagemmut) - (rand()%((int)(Filho[i].myestado_BehaviorConfig[0]*(porcentagemmut*2))+1));
//	if (rand()%1000 < mutacao) Filho[i].myestado_1EstadoProb[0] += Filho[i].myestado_1EstadoProb[0]*(porcentagemmut) - (rand()%((int)(Filho[i].myestado_1EstadoProb[0]*(porcentagemmut*2))+1));
	if (rand()%1000 < mutacao) Filho[i].myestado_1EstadoProbValor[0] += Filho[i].myestado_1EstadoProbValor[0]*(porcentagemmut) - (rand()%((int)(Filho[i].myestado_1EstadoProbValor[0]*(porcentagemmut*2))+1));
//	if (rand()%1000 < mutacao) Filho[i].myestado_2EstadoProb[0] += Filho[i].myestado_2EstadoProb[0]*(porcentagemmut) - (rand()%((int)(Filho[i].myestado_2EstadoProb[0]*(porcentagemmut*2))+1));
	if (rand()%1000 < mutacao) Filho[i].myestado_2EstadoProbValor[0] += Filho[i].myestado_2EstadoProbValor[0]*(porcentagemmut) - (rand()%((int)(Filho[i].myestado_2EstadoProbValor[0]*(porcentagemmut*2))+1));
	if (rand()%1000 < mutacao) Filho[i].myestado_F1Deposit[1] += Filho[i].myestado_F1Deposit[1]*(porcentagemmut) - (rand()%((int)(Filho[i].myestado_F1Deposit[1]*(porcentagemmut*2))+1));
	if (rand()%1000 < mutacao) Filho[i].myestado_TimeLimit[1] += Filho[i].myestado_TimeLimit[1]*(porcentagemmut) - (rand()%((int)(Filho[i].myestado_TimeLimit[1]*(porcentagemmut*2))+1));
	if (rand()%1000 < mutacao) Filho[i].myestado_RaioSensor[1] += Filho[i].myestado_RaioSensor[1]*(porcentagemmut) - (rand()%((int)(Filho[i].myestado_RaioSensor[1]*(porcentagemmut*2))+1));
	if (rand()%1000 < mutacao) Filho[i].myestado_PosSensor[1] += Filho[i].myestado_PosSensor[1]*(porcentagemmut) - (rand()%((int)(Filho[i].myestado_PosSensor[1]*(porcentagemmut*2))+1));
	if (rand()%1000 < mutacao) Filho[i].myestado_BehaviorConfig[1] += Filho[i].myestado_BehaviorConfig[1]*(porcentagemmut) - (rand()%((int)(Filho[i].myestado_BehaviorConfig[1]*(porcentagemmut*2))+1));
//	if (rand()%1000 < mutacao) Filho[i].myestado_1EstadoProb[1] += Filho[i].myestado_1EstadoProb[1]*(porcentagemmut) - (rand()%((int)(Filho[i].myestado_1EstadoProb[1]*(porcentagemmut*2))+1));
	if (rand()%1000 < mutacao) Filho[i].myestado_1EstadoProbValor[1] += Filho[i].myestado_1EstadoProbValor[1]*(porcentagemmut) - (rand()%((int)(Filho[i].myestado_1EstadoProbValor[1]*(porcentagemmut*2))+1));
//	if (rand()%1000 < mutacao) Filho[i].myestado_2EstadoProb[1] += Filho[i].myestado_2EstadoProb[1]*(porcentagemmut) - (rand()%((int)(Filho[i].myestado_2EstadoProb[1]*(porcentagemmut*2))+1));
//	if (rand()%1000 < mutacao) Filho[i].myestado_2EstadoProbValor[1] += Filho[i].myestado_2EstadoProbValor[1]*(porcentagemmut) - (rand()%((int)(Filho[i].myestado_2EstadoProbValor[1]*(porcentagemmut*2))+1));
	if (rand()%1000 < mutacao) Filho[i].myestado_F1Deposit[2] += Filho[i].myestado_F1Deposit[2]*(porcentagemmut) - (rand()%((int)(Filho[i].myestado_F1Deposit[2]*(porcentagemmut*2))+1));
	if (rand()%1000 < mutacao) Filho[i].myestado_TimeLimit[2] += Filho[i].myestado_TimeLimit[2]*(porcentagemmut) - (rand()%((int)(Filho[i].myestado_TimeLimit[2]*(porcentagemmut*2))+1));
	if (rand()%1000 < mutacao) Filho[i].myestado_RaioSensor[2] += Filho[i].myestado_RaioSensor[2]*(porcentagemmut) - (rand()%((int)(Filho[i].myestado_RaioSensor[2]*(porcentagemmut*2))+1));
	if (rand()%1000 < mutacao) Filho[i].myestado_PosSensor[2] += Filho[i].myestado_PosSensor[2]*(porcentagemmut) - (rand()%((int)(Filho[i].myestado_PosSensor[2]*(porcentagemmut*2))+1));
	if (rand()%1000 < mutacao) Filho[i].myestado_BehaviorConfig[2] += Filho[i].myestado_BehaviorConfig[2]*(porcentagemmut) - (rand()%((int)(Filho[i].myestado_BehaviorConfig[2]*(porcentagemmut*2))+1));
//	if (rand()%1000 < mutacao) Filho[i].myestado_1EstadoProb[2] += Filho[i].myestado_1EstadoProb[2]*(porcentagemmut) - (rand()%((int)(Filho[i].myestado_1EstadoProb[2]*(porcentagemmut*2))+1));
	if (rand()%1000 < mutacao) Filho[i].myestado_1EstadoProbValor[2] += Filho[i].myestado_1EstadoProbValor[2]*(porcentagemmut) - (rand()%((int)(Filho[i].myestado_1EstadoProbValor[2]*(porcentagemmut*2))+1));
//	if (rand()%1000 < mutacao) Filho[i].myestado_2EstadoProb[2] += Filho[i].myestado_2EstadoProb[2]*(porcentagemmut) - (rand()%((int)(Filho[i].myestado_2EstadoProb[2]*(porcentagemmut*2))+1));
//	if (rand()%1000 < mutacao) Filho[i].myestado_2EstadoProbValor[2] += Filho[i].myestado_2EstadoProbValor[2]*(porcentagemmut) - (rand()%((int)(Filho[i].myestado_2EstadoProbValor[2]*(porcentagemmut*2))+1));
	if (rand()%1000 < mutacao) Filho[i].myestado_F1Deposit[3] += Filho[i].myestado_F1Deposit[3]*(porcentagemmut) - (rand()%((int)(Filho[i].myestado_F1Deposit[3]*(porcentagemmut*2))+1));
	if (rand()%1000 < mutacao) Filho[i].myestado_TimeLimit[3] += Filho[i].myestado_TimeLimit[3]*(porcentagemmut) - (rand()%((int)(Filho[i].myestado_TimeLimit[3]*(porcentagemmut*2))+1));
	if (rand()%1000 < mutacao) Filho[i].myestado_RaioSensor[3] += Filho[i].myestado_RaioSensor[3]*(porcentagemmut) - (rand()%((int)(Filho[i].myestado_RaioSensor[3]*(porcentagemmut*2))+1));
	if (rand()%1000 < mutacao) Filho[i].myestado_PosSensor[3] += Filho[i].myestado_PosSensor[3]*(porcentagemmut) - (rand()%((int)(Filho[i].myestado_PosSensor[3]*(porcentagemmut*2))+1));
	if (rand()%1000 < mutacao) Filho[i].myestado_BehaviorConfig[3] += Filho[i].myestado_BehaviorConfig[3]*(porcentagemmut) - (rand()%((int)(Filho[i].myestado_BehaviorConfig[3]*(porcentagemmut*2))+1));
//	if (rand()%1000 < mutacao) Filho[i].myestado_1EstadoProb[3] += Filho[i].myestado_1EstadoProb[3]*(porcentagemmut) - (rand()%((int)(Filho[i].myestado_1EstadoProb[3]*(porcentagemmut*2))+1));
	if (rand()%1000 < mutacao) Filho[i].myestado_1EstadoProbValor[3] += Filho[i].myestado_1EstadoProbValor[3]*(porcentagemmut) - (rand()%((int)(Filho[i].myestado_1EstadoProbValor[3]*(porcentagemmut*2))+1));
//	if (rand()%1000 < mutacao) Filho[i].myestado_2EstadoProb[3] += Filho[i].myestado_2EstadoProb[3]*(porcentagemmut) - (rand()%((int)(Filho[i].myestado_2EstadoProb[3]*(porcentagemmut*2))+1));
	if (rand()%1000 < mutacao) Filho[i].myestado_2EstadoProbValor[3] += Filho[i].myestado_2EstadoProbValor[3]*(porcentagemmut) - (rand()%((int)(Filho[i].myestado_2EstadoProbValor[3]*(porcentagemmut*2))+1));
	if (rand()%1000 < mutacao) Filho[i].myestado_F1Deposit[4] += Filho[i].myestado_F1Deposit[4]*(porcentagemmut) - (rand()%((int)(Filho[i].myestado_F1Deposit[4]*(porcentagemmut*2))+1));
	if (rand()%1000 < mutacao) Filho[i].myestado_TimeLimit[4] += Filho[i].myestado_TimeLimit[4]*(porcentagemmut) - (rand()%((int)(Filho[i].myestado_TimeLimit[4]*(porcentagemmut*2))+1));
	if (rand()%1000 < mutacao) Filho[i].myestado_RaioSensor[4] += Filho[i].myestado_RaioSensor[4]*(porcentagemmut) - (rand()%((int)(Filho[i].myestado_RaioSensor[4]*(porcentagemmut*2))+1));
	if (rand()%1000 < mutacao) Filho[i].myestado_PosSensor[4] += Filho[i].myestado_PosSensor[4]*(porcentagemmut) - (rand()%((int)(Filho[i].myestado_PosSensor[4]*(porcentagemmut*2))+1));
	if (rand()%1000 < mutacao) Filho[i].myestado_BehaviorConfig[4] += Filho[i].myestado_BehaviorConfig[4]*(porcentagemmut) - (rand()%((int)(Filho[i].myestado_BehaviorConfig[4]*(porcentagemmut*2))+1));
//	if (rand()%1000 < mutacao) Filho[i].myestado_1EstadoProb[4] += Filho[i].myestado_1EstadoProb[4]*(porcentagemmut) - (rand()%((int)(Filho[i].myestado_1EstadoProb[4]*(porcentagemmut*2))+1));
	if (rand()%1000 < mutacao) Filho[i].myestado_1EstadoProbValor[4] += Filho[i].myestado_1EstadoProbValor[4]*(porcentagemmut) - (rand()%((int)(Filho[i].myestado_1EstadoProbValor[4]*(porcentagemmut*2))+1));
//	if (rand()%1000 < mutacao) Filho[i].myestado_2EstadoProb[4] += Filho[i].myestado_2EstadoProb[4]*(porcentagemmut) - (rand()%((int)(Filho[i].myestado_2EstadoProb[4]*(porcentagemmut*2))+1));
	if (rand()%1000 < mutacao) Filho[i].myestado_2EstadoProbValor[4] += Filho[i].myestado_2EstadoProbValor[4]*(porcentagemmut) - (rand()%((int)(Filho[i].myestado_2EstadoProbValor[4]*(porcentagemmut*2))+1));

	if (rand()%1000 < mutacao) Filho[i].myanguloTransicao[0] += Filho[i].myanguloTransicao[0]*(porcentagemmut) - (rand()%((int)(Filho[i].myanguloTransicao[0]*(porcentagemmut*2))+1));
	if (rand()%1000 < mutacao) Filho[i].myanguloTransicao[1] += Filho[i].myanguloTransicao[1]*(porcentagemmut) - (rand()%((int)(Filho[i].myanguloTransicao[1]*(porcentagemmut*2))+1));
	if (rand()%1000 < mutacao) Filho[i].myanguloTransicao[2] += Filho[i].myanguloTransicao[2]*(porcentagemmut) - (rand()%((int)(Filho[i].myanguloTransicao[2]*(porcentagemmut*2))+1));
	if (rand()%1000 < mutacao) Filho[i].myanguloTransicao[3] += Filho[i].myanguloTransicao[3]*(porcentagemmut) - (rand()%((int)(Filho[i].myanguloTransicao[3]*(porcentagemmut*2))+1));
	if (rand()%1000 < mutacao) Filho[i].myanguloTransicao[4] += Filho[i].myanguloTransicao[4]*(porcentagemmut) - (rand()%((int)(Filho[i].myanguloTransicao[4]*(porcentagemmut*2))+1));
	if (rand()%1000 < mutacao) Filho[i].myanguloTransicao[5] += Filho[i].myanguloTransicao[5]*(porcentagemmut) - (rand()%((int)(Filho[i].myanguloTransicao[5]*(porcentagemmut*2))+1));
	if (rand()%1000 < mutacao) Filho[i].myanguloTransicao[6] += Filho[i].myanguloTransicao[6]*(porcentagemmut) - (rand()%((int)(Filho[i].myanguloTransicao[6]*(porcentagemmut*2))+1));
	if (rand()%1000 < mutacao) Filho[i].myanguloTransicao[7] += Filho[i].myanguloTransicao[7]*(porcentagemmut) - (rand()%((int)(Filho[i].myanguloTransicao[7]*(porcentagemmut*2))+1));
	if (rand()%1000 < mutacao) Filho[i].myanguloTransicao[8] += Filho[i].myanguloTransicao[8]*(porcentagemmut) - (rand()%((int)(Filho[i].myanguloTransicao[8]*(porcentagemmut*2))+1));
	if (rand()%1000 < mutacao) Filho[i].myanguloTransicao[9] += Filho[i].myanguloTransicao[9]*(porcentagemmut) - (rand()%((int)(Filho[i].myanguloTransicao[9]*(porcentagemmut*2))+1));
	if (rand()%1000 < mutacao) Filho[i].myanguloTransicao[10] += Filho[i].myanguloTransicao[10]*(porcentagemmut) - (rand()%((int)(Filho[i].myanguloTransicao[10]*(porcentagemmut*2))+1));
	if (rand()%1000 < mutacao) Filho[i].myanguloTransicao[11] += Filho[i].myanguloTransicao[11]*(porcentagemmut) - (rand()%((int)(Filho[i].myanguloTransicao[11]*(porcentagemmut*2))+1));
	if (rand()%1000 < mutacao) Filho[i].myanguloTransicao[12] += Filho[i].myanguloTransicao[12]*(porcentagemmut) - (rand()%((int)(Filho[i].myanguloTransicao[12]*(porcentagemmut*2))+1));
	if (rand()%1000 < mutacao) Filho[i].myanguloTransicao[13] += Filho[i].myanguloTransicao[12]*(porcentagemmut) - (rand()%((int)(Filho[i].myanguloTransicao[13]*(porcentagemmut*2))+1));

        // restricoes
        if (Filho[i].myprob_virar[1] < 0) Filho[i].myprob_virar[1] = 0;
        if (Filho[i].myprob_virar[1] > 8) Filho[i].myprob_virar[1] = 8;
        if (Filho[i].myprob_virar[2] < 0) Filho[i].myprob_virar[2] = 0;
        if (Filho[i].myprob_virar[2] > 8) Filho[i].myprob_virar[2] = 8;
        if (Filho[i].myprob_virar[3] < 0) Filho[i].myprob_virar[3] = 0;
        if (Filho[i].myprob_virar[3] > 8) Filho[i].myprob_virar[3] = 8;
        if (Filho[i].myprob_virar[4] < 0) Filho[i].myprob_virar[4] = 0;
        if (Filho[i].myprob_virar[4] > 8) Filho[i].myprob_virar[4] = 8;
        if (Filho[i].myprob_virar[5] < 0) Filho[i].myprob_virar[5] = 0;
        if (Filho[i].myprob_virar[5] > 8) Filho[i].myprob_virar[5] = 8;
        if (Filho[i].myprob_virar[6] < 0) Filho[i].myprob_virar[6] = 0;
        if (Filho[i].myprob_virar[6] > 8) Filho[i].myprob_virar[6] = 8;

	if (Filho[i].myRateF1 < 0) Filho[i].myRateF1 = 0;
	if (Filho[i].myRateF1 > 4) Filho[i].myRateF1 = 4;
	if (Filho[i].myIntervalF1 < 0) Filho[i].myIntervalF1 = 0;
	if (Filho[i].myIntervalF1 > 5) Filho[i].myIntervalF1 = 5;
	if (Filho[i].mySaturation < 0) Filho[i].mySaturation = 0;
	if (Filho[i].mySaturation > 5) Filho[i].mySaturation = 5;

	if (Filho[i].mydecay < 0) Filho[i].mydecay = 0;
	if (Filho[i].mydecay > 11) Filho[i].mydecay = 11;

	if (Filho[i].myconf_FollowF1[0] < 0) Filho[i].myconf_FollowF1[0] = 0;
	if (Filho[i].myconf_FollowF1[0] > 19) Filho[i].myconf_FollowF1[0] = 19;
	if (Filho[i].myconf_FollowF1ThrMin[0] < 0) Filho[i].myconf_FollowF1ThrMin[0] = 0;
	if (Filho[i].myconf_FollowF1ThrMin[0] > 17) Filho[i].myconf_FollowF1ThrMin[0] = 17;
	if (Filho[i].myconf_FollowF1ThrMax[0] < 0) Filho[i].myconf_FollowF1ThrMax[0] = 0;
	if (Filho[i].myconf_FollowF1ThrMax[0] > 17) Filho[i].myconf_FollowF1ThrMax[0] = 17;
	if (Filho[i].myconf_AgainstF1[0] < 0) Filho[i].myconf_AgainstF1[0] = 0;
	if (Filho[i].myconf_AgainstF1[0] > (19-Filho[i].myconf_FollowF1[0])) Filho[i].myconf_AgainstF1[0] = (19-Filho[i].myconf_FollowF1[0]);
	if (Filho[i].myconf_AgainstF1ThrMin[0] < 0) Filho[i].myconf_AgainstF1ThrMin[0] = 0;
	if (Filho[i].myconf_AgainstF1ThrMin[0] > 17) Filho[i].myconf_AgainstF1ThrMin[0] = 17;
	if (Filho[i].myconf_AgainstF1ThrMax[0] < 0) Filho[i].myconf_AgainstF1ThrMax[0] = 0;
	if (Filho[i].myconf_AgainstF1ThrMax[0] > 17) Filho[i].myconf_AgainstF1ThrMax[0] = 17;
	if (Filho[i].myconf_HardFollow[0] < 0) Filho[i].myconf_HardFollow[0] = 0;
	if (Filho[i].myconf_HardFollow[0] > 1) Filho[i].myconf_HardFollow[0] = 1;
	if (Filho[i].myconf_ThrRelativo[0] < 0) Filho[i].myconf_ThrRelativo[0] = 0;
	if (Filho[i].myconf_ThrRelativo[0] > 1) Filho[i].myconf_ThrRelativo[0] = 1;
	if (Filho[i].myconf_FollowF1[1] < 0) Filho[i].myconf_FollowF1[1] = 0;
	if (Filho[i].myconf_FollowF1[1] > 19) Filho[i].myconf_FollowF1[1] = 19;
	if (Filho[i].myconf_FollowF1ThrMin[1] < 0) Filho[i].myconf_FollowF1ThrMin[1] = 0;
	if (Filho[i].myconf_FollowF1ThrMin[1] > 17) Filho[i].myconf_FollowF1ThrMin[1] = 17;
	if (Filho[i].myconf_FollowF1ThrMax[1] < 0) Filho[i].myconf_FollowF1ThrMax[1] = 0;
	if (Filho[i].myconf_FollowF1ThrMax[1] > 17) Filho[i].myconf_FollowF1ThrMax[1] = 17;
	if (Filho[i].myconf_AgainstF1[1] < 0) Filho[i].myconf_AgainstF1[1] = 0;
	if (Filho[i].myconf_AgainstF1[1] > (19-Filho[i].myconf_FollowF1[1])) Filho[i].myconf_AgainstF1[1] = (19-Filho[i].myconf_FollowF1[1]);
	if (Filho[i].myconf_AgainstF1ThrMin[1] < 0) Filho[i].myconf_AgainstF1ThrMin[1] = 0;
	if (Filho[i].myconf_AgainstF1ThrMin[1] > 17) Filho[i].myconf_AgainstF1ThrMin[1] = 17;
	if (Filho[i].myconf_AgainstF1ThrMax[1] < 0) Filho[i].myconf_AgainstF1ThrMax[1] = 0;
	if (Filho[i].myconf_AgainstF1ThrMax[1] > 17) Filho[i].myconf_AgainstF1ThrMax[1] = 17;
	if (Filho[i].myconf_HardFollow[1] < 0) Filho[i].myconf_HardFollow[1] = 0;
	if (Filho[i].myconf_HardFollow[1] > 1) Filho[i].myconf_HardFollow[1] = 1;
	if (Filho[i].myconf_ThrRelativo[1] < 0) Filho[i].myconf_ThrRelativo[1] = 0;
	if (Filho[i].myconf_ThrRelativo[1] > 1) Filho[i].myconf_ThrRelativo[1] = 1;
	if (Filho[i].myconf_FollowF1[2] < 0) Filho[i].myconf_FollowF1[2] = 0;
	if (Filho[i].myconf_FollowF1[2] > 19) Filho[i].myconf_FollowF1[2] = 19;
	if (Filho[i].myconf_FollowF1ThrMin[2] < 0) Filho[i].myconf_FollowF1ThrMin[2] = 0;
	if (Filho[i].myconf_FollowF1ThrMin[2] > 17) Filho[i].myconf_FollowF1ThrMin[2] = 17;
	if (Filho[i].myconf_FollowF1ThrMax[2] < 0) Filho[i].myconf_FollowF1ThrMax[2] = 0;
	if (Filho[i].myconf_FollowF1ThrMax[2] > 17) Filho[i].myconf_FollowF1ThrMax[2] = 17;
	if (Filho[i].myconf_AgainstF1[2] < 0) Filho[i].myconf_AgainstF1[2] = 0;
	if (Filho[i].myconf_AgainstF1[2] > (19-Filho[i].myconf_FollowF1[2])) Filho[i].myconf_AgainstF1[2] = (19-Filho[i].myconf_FollowF1[2]);
	if (Filho[i].myconf_AgainstF1ThrMin[2] < 0) Filho[i].myconf_AgainstF1ThrMin[2] = 0;
	if (Filho[i].myconf_AgainstF1ThrMin[2] > 17) Filho[i].myconf_AgainstF1ThrMin[2] = 17;
	if (Filho[i].myconf_AgainstF1ThrMax[2] < 0) Filho[i].myconf_AgainstF1ThrMax[2] = 0;
	if (Filho[i].myconf_AgainstF1ThrMax[2] > 17) Filho[i].myconf_AgainstF1ThrMax[2] = 17;
	if (Filho[i].myconf_HardFollow[2] < 0) Filho[i].myconf_HardFollow[2] = 0;
	if (Filho[i].myconf_HardFollow[2] > 1) Filho[i].myconf_HardFollow[2] = 1;
	if (Filho[i].myconf_ThrRelativo[2] < 0) Filho[i].myconf_ThrRelativo[2] = 0;
	if (Filho[i].myconf_ThrRelativo[2] > 1) Filho[i].myconf_ThrRelativo[2] = 1;

	if (Filho[i].myestado_F1Deposit[0] < 0) Filho[i].myestado_F1Deposit[0] = 0;
	if (Filho[i].myestado_F1Deposit[0] > 5) Filho[i].myestado_F1Deposit[0] = 5;
	if (Filho[i].myestado_TimeLimit[0] < 0) Filho[i].myestado_TimeLimit[0] = 0;
	if (Filho[i].myestado_TimeLimit[0] > 12) Filho[i].myestado_TimeLimit[0] = 12;
	if (Filho[i].myestado_RaioSensor[0] < 0) Filho[i].myestado_RaioSensor[0] = 0;
	if (Filho[i].myestado_RaioSensor[0] > 2) Filho[i].myestado_RaioSensor[0] = 2;
	if (Filho[i].myestado_PosSensor[0] < 0) Filho[i].myestado_PosSensor[0] = 0;
	if (Filho[i].myestado_PosSensor[0] > 5) Filho[i].myestado_PosSensor[0] = 5;
	if (Filho[i].myestado_BehaviorConfig[0] < 1) Filho[i].myestado_BehaviorConfig[0] = 1;
	if (Filho[i].myestado_BehaviorConfig[0] > 3) Filho[i].myestado_BehaviorConfig[0] = 3;
//	if (Filho[i].myestado_1EstadoProb[0] < 0) Filho[i].myestado_1EstadoProb[0] = 0;
//	if (Filho[i].myestado_1EstadoProb[0] > 1) Filho[i].myestado_1EstadoProb[0] = 1;
	if (Filho[i].myestado_1EstadoProbValor[0] < 0) Filho[i].myestado_1EstadoProbValor[0] = 0;
	if (Filho[i].myestado_1EstadoProbValor[0] > 16) Filho[i].myestado_1EstadoProbValor[0] = 16;
//	if (Filho[i].myestado_2EstadoProb[0] < 0) Filho[i].myestado_2EstadoProb[0] = 0;
//	if (Filho[i].myestado_2EstadoProb[0] > 1) Filho[i].myestado_2EstadoProb[0] = 1;
	if (Filho[i].myestado_2EstadoProbValor[0] < 0) Filho[i].myestado_2EstadoProbValor[0] = 0;
	if (Filho[i].myestado_2EstadoProbValor[0] > 16) Filho[i].myestado_2EstadoProbValor[0] = 16;
	if (Filho[i].myestado_F1Deposit[1] < 0) Filho[i].myestado_F1Deposit[1] = 0;
	if (Filho[i].myestado_F1Deposit[1] > 5) Filho[i].myestado_F1Deposit[1] = 5;
	if (Filho[i].myestado_TimeLimit[1] < 0) Filho[i].myestado_TimeLimit[1] = 0;
	if (Filho[i].myestado_TimeLimit[1] > 12) Filho[i].myestado_TimeLimit[1] = 12;
	if (Filho[i].myestado_RaioSensor[1] < 0) Filho[i].myestado_RaioSensor[1] = 0;
	if (Filho[i].myestado_RaioSensor[1] > 2) Filho[i].myestado_RaioSensor[1] = 2;
	if (Filho[i].myestado_PosSensor[1] < 0) Filho[i].myestado_PosSensor[1] = 0;
	if (Filho[i].myestado_PosSensor[1] > 5) Filho[i].myestado_PosSensor[1] = 5;
	if (Filho[i].myestado_BehaviorConfig[1] < 1) Filho[i].myestado_BehaviorConfig[1] = 1;
	if (Filho[i].myestado_BehaviorConfig[1] > 3) Filho[i].myestado_BehaviorConfig[1] = 3;
//	if (Filho[i].myestado_1EstadoProb[1] < 0) Filho[i].myestado_1EstadoProb[1] = 0;
//	if (Filho[i].myestado_1EstadoProb[1] > 1) Filho[i].myestado_1EstadoProb[1] = 1;
	if (Filho[i].myestado_1EstadoProbValor[1] < 0) Filho[i].myestado_1EstadoProbValor[1] = 0;
	if (Filho[i].myestado_1EstadoProbValor[1] > 16) Filho[i].myestado_1EstadoProbValor[1] = 16;
//	if (Filho[i].myestado_2EstadoProb[1] < 0) Filho[i].myestado_2EstadoProb[1] = 0;
//	if (Filho[i].myestado_2EstadoProb[1] > 1) Filho[i].myestado_2EstadoProb[1] = 1;
//	if (Filho[i].myestado_2EstadoProbValor[1] < 0) Filho[i].myestado_2EstadoProbValor[1] = 0;
//	if (Filho[i].myestado_2EstadoProbValor[1] > 16) Filho[i].myestado_2EstadoProbValor[1] = 16;
	if (Filho[i].myestado_F1Deposit[2] < 0) Filho[i].myestado_F1Deposit[2] = 0;
	if (Filho[i].myestado_F1Deposit[2] > 5) Filho[i].myestado_F1Deposit[2] = 5;
	if (Filho[i].myestado_TimeLimit[2] < 0) Filho[i].myestado_TimeLimit[2] = 0;
	if (Filho[i].myestado_TimeLimit[2] > 12) Filho[i].myestado_TimeLimit[2] = 12;
	if (Filho[i].myestado_RaioSensor[2] < 0) Filho[i].myestado_RaioSensor[2] = 0;
	if (Filho[i].myestado_RaioSensor[2] > 2) Filho[i].myestado_RaioSensor[2] = 2;
	if (Filho[i].myestado_PosSensor[2] < 0) Filho[i].myestado_PosSensor[2] = 0;
	if (Filho[i].myestado_PosSensor[2] > 5) Filho[i].myestado_PosSensor[2] = 5;
	if (Filho[i].myestado_BehaviorConfig[2] < 1) Filho[i].myestado_BehaviorConfig[2] = 1;
	if (Filho[i].myestado_BehaviorConfig[2] > 3) Filho[i].myestado_BehaviorConfig[2] = 3;
//	if (Filho[i].myestado_1EstadoProb[2] < 0) Filho[i].myestado_1EstadoProb[2] = 0;
//	if (Filho[i].myestado_1EstadoProb[2] > 1) Filho[i].myestado_1EstadoProb[2] = 1;
	if (Filho[i].myestado_1EstadoProbValor[2] < 0) Filho[i].myestado_1EstadoProbValor[2] = 0;
	if (Filho[i].myestado_1EstadoProbValor[2] > 16) Filho[i].myestado_1EstadoProbValor[2] = 16;
//	if (Filho[i].myestado_2EstadoProb[2] < 0) Filho[i].myestado_2EstadoProb[2] = 0;
//	if (Filho[i].myestado_2EstadoProb[2] > 1) Filho[i].myestado_2EstadoProb[2] = 1;
//	if (Filho[i].myestado_2EstadoProbValor[2] < 0) Filho[i].myestado_2EstadoProbValor[2] = 0;
//	if (Filho[i].myestado_2EstadoProbValor[2] > 16) Filho[i].myestado_2EstadoProbValor[2] = 16;
	if (Filho[i].myestado_F1Deposit[3] < 0) Filho[i].myestado_F1Deposit[3] = 0;
	if (Filho[i].myestado_F1Deposit[3] > 5) Filho[i].myestado_F1Deposit[3] = 5;
	if (Filho[i].myestado_TimeLimit[3] < 0) Filho[i].myestado_TimeLimit[3] = 0;
	if (Filho[i].myestado_TimeLimit[3] > 12) Filho[i].myestado_TimeLimit[3] = 12;
	if (Filho[i].myestado_RaioSensor[3] < 0) Filho[i].myestado_RaioSensor[3] = 0;
	if (Filho[i].myestado_RaioSensor[3] > 2) Filho[i].myestado_RaioSensor[3] = 2;
	if (Filho[i].myestado_PosSensor[3] < 0) Filho[i].myestado_PosSensor[3] = 0;
	if (Filho[i].myestado_PosSensor[3] > 5) Filho[i].myestado_PosSensor[3] = 5;
	if (Filho[i].myestado_BehaviorConfig[3] < 1) Filho[i].myestado_BehaviorConfig[3] = 1;
	if (Filho[i].myestado_BehaviorConfig[3] > 3) Filho[i].myestado_BehaviorConfig[3] = 3;
//	if (Filho[i].myestado_1EstadoProb[3] < 0) Filho[i].myestado_1EstadoProb[3] = 0;
//	if (Filho[i].myestado_1EstadoProb[3] > 1) Filho[i].myestado_1EstadoProb[3] = 1;
	if (Filho[i].myestado_1EstadoProbValor[3] < 0) Filho[i].myestado_1EstadoProbValor[3] = 0;
	if (Filho[i].myestado_1EstadoProbValor[3] > 16) Filho[i].myestado_1EstadoProbValor[3] = 16;
//	if (Filho[i].myestado_2EstadoProb[3] < 0) Filho[i].myestado_2EstadoProb[3] = 0;
//	if (Filho[i].myestado_2EstadoProb[3] > 1) Filho[i].myestado_2EstadoProb[3] = 1;
	if (Filho[i].myestado_2EstadoProbValor[3] < 0) Filho[i].myestado_2EstadoProbValor[3] = 0;
	if (Filho[i].myestado_2EstadoProbValor[3] > 16) Filho[i].myestado_2EstadoProbValor[3] = 16;
	if (Filho[i].myestado_F1Deposit[4] < 0) Filho[i].myestado_F1Deposit[4] = 0;
	if (Filho[i].myestado_F1Deposit[4] > 5) Filho[i].myestado_F1Deposit[4] = 5;
	if (Filho[i].myestado_TimeLimit[4] < 0) Filho[i].myestado_TimeLimit[4] = 0;
	if (Filho[i].myestado_TimeLimit[4] > 12) Filho[i].myestado_TimeLimit[4] = 12;
	if (Filho[i].myestado_RaioSensor[4] < 0) Filho[i].myestado_RaioSensor[4] = 0;
	if (Filho[i].myestado_RaioSensor[4] > 2) Filho[i].myestado_RaioSensor[4] = 2;
	if (Filho[i].myestado_PosSensor[4] < 0) Filho[i].myestado_PosSensor[4] = 0;
	if (Filho[i].myestado_PosSensor[4] > 5) Filho[i].myestado_PosSensor[4] = 5;
	if (Filho[i].myestado_BehaviorConfig[4] < 1) Filho[i].myestado_BehaviorConfig[4] = 1;
	if (Filho[i].myestado_BehaviorConfig[4] > 3) Filho[i].myestado_BehaviorConfig[4] = 3;
//	if (Filho[i].myestado_1EstadoProb[4] < 0) Filho[i].myestado_1EstadoProb[4] = 0;
//	if (Filho[i].myestado_1EstadoProb[4] > 1) Filho[i].myestado_1EstadoProb[4] = 1;
	if (Filho[i].myestado_1EstadoProbValor[4] < 0) Filho[i].myestado_1EstadoProbValor[4] = 0;
	if (Filho[i].myestado_1EstadoProbValor[4] > 16) Filho[i].myestado_1EstadoProbValor[4] = 16;
//	if (Filho[i].myestado_2EstadoProb[4] < 0) Filho[i].myestado_2EstadoProb[4] = 0;
//	if (Filho[i].myestado_2EstadoProb[4] > 1) Filho[i].myestado_2EstadoProb[4] = 1;
	if (Filho[i].myestado_2EstadoProbValor[4] < 0) Filho[i].myestado_2EstadoProbValor[4] = 0;
	if (Filho[i].myestado_2EstadoProbValor[4] > 16) Filho[i].myestado_2EstadoProbValor[4] = 16;

	if (Filho[i].myanguloTransicao[0] < 0) Filho[i].myanguloTransicao[0] = 0;
	if (Filho[i].myanguloTransicao[0] > 8) Filho[i].myanguloTransicao[0] = 8;
	if (Filho[i].myanguloTransicao[1] < 0) Filho[i].myanguloTransicao[1] = 0;
	if (Filho[i].myanguloTransicao[1] > 8) Filho[i].myanguloTransicao[1] = 8;
	if (Filho[i].myanguloTransicao[2] < 0) Filho[i].myanguloTransicao[2] = 0;
	if (Filho[i].myanguloTransicao[2] > 8) Filho[i].myanguloTransicao[2] = 8;
	if (Filho[i].myanguloTransicao[3] < 0) Filho[i].myanguloTransicao[3] = 0;
	if (Filho[i].myanguloTransicao[3] > 8) Filho[i].myanguloTransicao[3] = 8;
	if (Filho[i].myanguloTransicao[4] < 0) Filho[i].myanguloTransicao[4] = 0;
	if (Filho[i].myanguloTransicao[4] > 8) Filho[i].myanguloTransicao[4] = 8;
	if (Filho[i].myanguloTransicao[5] < 0) Filho[i].myanguloTransicao[5] = 0;
	if (Filho[i].myanguloTransicao[5] > 8) Filho[i].myanguloTransicao[5] = 8;
	if (Filho[i].myanguloTransicao[6] < 0) Filho[i].myanguloTransicao[6] = 0;
	if (Filho[i].myanguloTransicao[6] > 8) Filho[i].myanguloTransicao[6] = 8;
	if (Filho[i].myanguloTransicao[7] < 0) Filho[i].myanguloTransicao[7] = 0;
	if (Filho[i].myanguloTransicao[7] > 8) Filho[i].myanguloTransicao[7] = 8;
	if (Filho[i].myanguloTransicao[8] < 0) Filho[i].myanguloTransicao[8] = 0;
	if (Filho[i].myanguloTransicao[8] > 8) Filho[i].myanguloTransicao[8] = 8;
	if (Filho[i].myanguloTransicao[9] < 0) Filho[i].myanguloTransicao[9] = 0;
	if (Filho[i].myanguloTransicao[9] > 8) Filho[i].myanguloTransicao[9] = 8;
	if (Filho[i].myanguloTransicao[10] < 0) Filho[i].myanguloTransicao[10] = 0;
	if (Filho[i].myanguloTransicao[10] > 8) Filho[i].myanguloTransicao[10] = 8;
	if (Filho[i].myanguloTransicao[11] < 0) Filho[i].myanguloTransicao[11] = 0;
	if (Filho[i].myanguloTransicao[11] > 8) Filho[i].myanguloTransicao[11] = 8;
	if (Filho[i].myanguloTransicao[12] < 0) Filho[i].myanguloTransicao[12] = 0;
	if (Filho[i].myanguloTransicao[12] > 8) Filho[i].myanguloTransicao[12] = 8;
	if (Filho[i].myanguloTransicao[13] < 0) Filho[i].myanguloTransicao[13] = 0;
	if (Filho[i].myanguloTransicao[13] > 8) Filho[i].myanguloTransicao[13] = 8;
}
//---------------------------------------------------------------------------

void __fastcall TForm1::SpeedButton2Click(TObject *Sender)
{
        static int valores1[] = { 0, 2, 5, 10, 20, 40, 80, 160, 240, 320, 500, 680, 840, 920, 960, 980, 990, 995, 998, 1000 };
        static int valores2[] = { 0, 10, 25, 50, 100, 150, 200, 275, 350, 400, 800, 1600, 3200, 6400, 9600, 12800, 25600, 2000000000 };
        static int valores3[] = { 0, 1, 2, 4, 8, 16, 32, 64, 128, 256, 512, 768, 1024 };
//        static int valores4[] = { 0, 4, 14, 32, 29, 48, 56, 60, 62, 63, 64, 65, 66, 68, 72, 80, 89, 96, 114, 124, 128 };
        static float valores5[] = { 0.65, 0.80, 0.85, 0.90, 0.95, 0.96, 0.97, 0.98, 0.985, 0.99, 0.995, 1.00 };
        static int valores6[] = { 128, 512, 4096, 16384, 65536, 2000000000 };
        static int valores7[] = { 0, 2, 16 };
        static int valores8[] = { 14, 16, 18, 28, 30, 32 };
        static int valores9[] = { 0, 2, 4, 6, 18, 30, 32, 34, 36 };
        int nota;
        float maiornota;
        int i, j;
        FILE *f, *fr;
        int min, max;
        int notas[10];
        static int F1a, F2a, melhor;
        static int somaprob;

        geracao = 0;
        // geracao inicial
        if (MessageDlg((AnsiString)"Gerar filhos aleat�rios?", mtConfirmation, TMsgDlgButtons() << mbYes << mbNo, 0) == mrYes) {
                for(i=0; i<FILHOSPORGERACAO; i++) {
                        geraFilhoRandomico(i);
                }

                // so configurarei o primeiro com os valores do form
		Filho[0].myprob_virar[1] = 4;
		Filho[0].myprob_virar[2] = 4;
		Filho[0].myprob_virar[3] = 4;
		Filho[0].myprob_virar[4] = 4;
		Filho[0].myprob_virar[5] = 4;
		Filho[0].myprob_virar[6] = 4;

		Filho[0].myRateF1 = 1;
		Filho[0].myIntervalF1 = 4;
		Filho[0].mySaturation = 3;

		Filho[0].mydecay = 2;

		Filho[0].myconf_FollowF1[0] = 0;
		Filho[0].myconf_FollowF1ThrMin[0] = 0;
		Filho[0].myconf_FollowF1ThrMax[0] = 0;
		Filho[0].myconf_AgainstF1[0] = 17;
		Filho[0].myconf_AgainstF1ThrMin[0] = 0;
		Filho[0].myconf_AgainstF1ThrMax[0] = 17;
		Filho[0].myconf_HardFollow[0] = 1;
		Filho[0].myconf_ThrRelativo[0] = 1;
		Filho[0].myconf_FollowF1[1] = 17;
		Filho[0].myconf_FollowF1ThrMin[1] = 0;
		Filho[0].myconf_FollowF1ThrMax[1] = 17;
		Filho[0].myconf_AgainstF1[1] = 0;
		Filho[0].myconf_AgainstF1ThrMin[1] = 0;
		Filho[0].myconf_AgainstF1ThrMax[1] = 0;
		Filho[0].myconf_HardFollow[1] = 1;
		Filho[0].myconf_ThrRelativo[1] = 1;
		Filho[0].myconf_FollowF1[2] = 0;
		Filho[0].myconf_FollowF1ThrMin[2] = 0;
		Filho[0].myconf_FollowF1ThrMax[2] = 0;
		Filho[0].myconf_AgainstF1[2] = 0;
		Filho[0].myconf_AgainstF1ThrMin[2] = 0;
		Filho[0].myconf_AgainstF1ThrMax[2] = 0;
		Filho[0].myconf_HardFollow[2] = 1;
		Filho[0].myconf_ThrRelativo[2] = 1;

		Filho[0].myestado_F1Deposit[0] = 4 ;
		Filho[0].myestado_TimeLimit[0] = 5;
		Filho[0].myestado_RaioSensor[0] = 2;
		Filho[0].myestado_PosSensor[0] = 1;
		Filho[0].myestado_BehaviorConfig[0] = 1;
		Filho[0].myestado_1EstadoProb[0] = 0;
		Filho[0].myestado_1EstadoProbValor[0] = 16;
		Filho[0].myestado_2EstadoProb[0] = 0;
		Filho[0].myestado_2EstadoProbValor[0] = 16;
		Filho[0].myestado_F1Deposit[1] = 8;
		Filho[0].myestado_TimeLimit[1] = 7;
		Filho[0].myestado_RaioSensor[1] = 2;
		Filho[0].myestado_PosSensor[1] = 4;
		Filho[0].myestado_BehaviorConfig[1] = 2;
		Filho[0].myestado_1EstadoProb[1] = 0;
		Filho[0].myestado_1EstadoProbValor[1] = 16;
		Filho[0].myestado_2EstadoProb[1] = 0;
		Filho[0].myestado_2EstadoProbValor[1] = 16;
		Filho[0].myestado_F1Deposit[2] = 2;
		Filho[0].myestado_TimeLimit[2] = 5;
		Filho[0].myestado_RaioSensor[2] = 2;
		Filho[0].myestado_PosSensor[2] = 1;
		Filho[0].myestado_BehaviorConfig[2] = 1;
		Filho[0].myestado_1EstadoProb[2] = 0;
		Filho[0].myestado_1EstadoProbValor[2] = 16;
		Filho[0].myestado_2EstadoProb[2] = 0;
		Filho[0].myestado_2EstadoProbValor[2] = 16;
		Filho[0].myestado_F1Deposit[3] = 4;
		Filho[0].myestado_TimeLimit[3] = 5;
		Filho[0].myestado_RaioSensor[3] = 2;
		Filho[0].myestado_PosSensor[3] = 4;
		Filho[0].myestado_BehaviorConfig[3] = 2;
		Filho[0].myestado_1EstadoProb[3] = 2;
		Filho[0].myestado_1EstadoProbValor[3] = 11;
		Filho[0].myestado_2EstadoProb[3] = 0;
		Filho[0].myestado_2EstadoProbValor[3] = 16;
		Filho[0].myestado_F1Deposit[4] = 2;
		Filho[0].myestado_TimeLimit[4] = 5;
		Filho[0].myestado_RaioSensor[4] = 2;
		Filho[0].myestado_PosSensor[4] = 4;
		Filho[0].myestado_BehaviorConfig[4] = 2;
		Filho[0].myestado_1EstadoProb[4] = 0;
		Filho[0].myestado_1EstadoProbValor[4] = 16;
		Filho[0].myestado_2EstadoProb[4] = 0;
		Filho[0].myestado_2EstadoProbValor[4] = 16;

		Filho[0].myanguloTransicao[0] = 8;
		Filho[0].myanguloTransicao[1] = 8;
		Filho[0].myanguloTransicao[2] = 0;
		Filho[0].myanguloTransicao[3] = 8;
		Filho[0].myanguloTransicao[4] = 8;
		Filho[0].myanguloTransicao[5] = 0;
		Filho[0].myanguloTransicao[6] = 8;
		Filho[0].myanguloTransicao[7] = 8;
		Filho[0].myanguloTransicao[8] = 0;
		Filho[0].myanguloTransicao[9] = 8;
		Filho[0].myanguloTransicao[10] = 0;
		Filho[0].myanguloTransicao[11] = 8;
		Filho[0].myanguloTransicao[12] = 0;
		Filho[0].myanguloTransicao[13] = 0;
        }
        else {
                OpenDialog2->Execute();
                fr = fopen(OpenDialog2->FileName.c_str(), "r");
                if (!(fr)) { ShowMessage("Erro abrindo arquivo"); return; }
                for(i=0; i<FILHOSPORGERACAO; i++) {
                        fscanf(fr, "%f %f %d %d %d %d %d %d %d %d %d %f %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d ",
                                &maiornota, &Filho[i].nota, &Filho[i].myprob_virar[0], &Filho[i].myprob_virar[1], &Filho[i].myprob_virar[2], &Filho[i].myprob_virar[3], &Filho[i].myprob_virar[4], &Filho[i].myprob_virar[5], &Filho[i].myprob_virar[6], &Filho[i].myRateF1, &Filho[i].myIntervalF1, &Filho[i].mySaturation, &Filho[i].mydecay, &Filho[i].myconf_FollowF1[0], &Filho[i].myconf_FollowF1ThrMin[0], &Filho[i].myconf_FollowF1ThrMax[0], &Filho[i].myconf_AgainstF1[0], &Filho[i].myconf_AgainstF1ThrMin[0], &Filho[i].myconf_AgainstF1ThrMax[0], &Filho[i].myconf_HardFollow[0], &Filho[i].myconf_ThrRelativo[0], &Filho[i].myconf_FollowF1[1], &Filho[i].myconf_FollowF1ThrMin[1], &Filho[i].myconf_FollowF1ThrMax[1], &Filho[i].myconf_AgainstF1[1], &Filho[i].myconf_AgainstF1ThrMin[1], &Filho[i].myconf_AgainstF1ThrMax[1],
                                &Filho[i].myconf_HardFollow[1], &Filho[i].myconf_ThrRelativo[1], &Filho[i].myconf_FollowF1[2], &Filho[i].myconf_FollowF1ThrMin[2], &Filho[i].myconf_FollowF1ThrMax[2], &Filho[i].myconf_AgainstF1[2], &Filho[i].myconf_AgainstF1ThrMin[2], &Filho[i].myconf_AgainstF1ThrMax[2], &Filho[i].myconf_HardFollow[2], &Filho[i].myconf_ThrRelativo[2], &Filho[i].myestado_F1Deposit[0], &Filho[i].myestado_TimeLimit[0], &Filho[i].myestado_RaioSensor[0], &Filho[i].myestado_PosSensor[0], &Filho[i].myestado_BehaviorConfig[0], &Filho[i].myestado_1EstadoProb[0], &Filho[i].myestado_1EstadoProbValor[0], &Filho[i].myestado_2EstadoProb[0], &Filho[i].myestado_2EstadoProbValor[0], &Filho[i].myestado_F1Deposit[1], &Filho[i].myestado_TimeLimit[1], &Filho[i].myestado_RaioSensor[1],
                                &Filho[i].myestado_PosSensor[1], &Filho[i].myestado_BehaviorConfig[1], &Filho[i].myestado_1EstadoProb[1], &Filho[i].myestado_1EstadoProbValor[1], &Filho[i].myestado_2EstadoProb[1], &Filho[i].myestado_2EstadoProbValor[1], &Filho[i].myestado_F1Deposit[2], &Filho[i].myestado_TimeLimit[2], &Filho[i].myestado_RaioSensor[2], &Filho[i].myestado_PosSensor[2], &Filho[i].myestado_BehaviorConfig[2], &Filho[i].myestado_1EstadoProb[2], &Filho[i].myestado_1EstadoProbValor[2], &Filho[i].myestado_2EstadoProb[2], &Filho[i].myestado_2EstadoProbValor[2], &Filho[i].myestado_F1Deposit[3], &Filho[i].myestado_TimeLimit[3], &Filho[i].myestado_RaioSensor[3], &Filho[i].myestado_PosSensor[3], &Filho[i].myestado_BehaviorConfig[3], &Filho[i].myestado_1EstadoProb[3], &Filho[i].myestado_1EstadoProbValor[3],
                                &Filho[i].myestado_2EstadoProb[3], &Filho[i].myestado_2EstadoProbValor[3], &Filho[i].myestado_F1Deposit[4], &Filho[i].myestado_TimeLimit[4], &Filho[i].myestado_RaioSensor[4], &Filho[i].myestado_PosSensor[4], &Filho[i].myestado_BehaviorConfig[4], &Filho[i].myestado_1EstadoProb[4], &Filho[i].myestado_1EstadoProbValor[4], &Filho[i].myestado_2EstadoProb[4], &Filho[i].myestado_2EstadoProbValor[4], &Filho[i].myanguloTransicao[0], &Filho[i].myanguloTransicao[1], &Filho[i].myanguloTransicao[2], &Filho[i].myanguloTransicao[3], &Filho[i].myanguloTransicao[4], &Filho[i].myanguloTransicao[5], &Filho[i].myanguloTransicao[6], &Filho[i].myanguloTransicao[7], &Filho[i].myanguloTransicao[8], &Filho[i].myanguloTransicao[9], &Filho[i].myanguloTransicao[10], &Filho[i].myanguloTransicao[11], &Filho[i].myanguloTransicao[12], &Filho[i].myanguloTransicao[13]);
                }
                fclose(fr);

        }

        ForceDirectories("c:\\ants\\geracoes\\");
        ForceDirectories("c:\\ants\\geracoes_raw\\");

        maiornota = -1;

        while(1) {
                for(i=0; i<FILHOSPORGERACAO; i++) {
			myFilho.myprob_virar[1] = valores1[Filho[i].myprob_virar[1]];
			myFilho.myprob_virar[2] = valores1[Filho[i].myprob_virar[2]];
			myFilho.myprob_virar[3] = valores1[Filho[i].myprob_virar[3]];
			myFilho.myprob_virar[4] = valores1[Filho[i].myprob_virar[4]];
			myFilho.myprob_virar[5] = valores1[Filho[i].myprob_virar[5]];
			myFilho.myprob_virar[6] = valores1[Filho[i].myprob_virar[6]];
			myFilho.myprob_virar[0] = 1000 - myFilho.myprob_virar[1] - myFilho.myprob_virar[2] - myFilho.myprob_virar[3] - myFilho.myprob_virar[4] - myFilho.myprob_virar[5] - myFilho.myprob_virar[6];
			Filho[i].myprob_virar[0] = myFilho.myprob_virar[0];

			myFilho.myRateF1 = valores3[Filho[i].myRateF1];
			myFilho.myIntervalF1 = valores3[Filho[i].myIntervalF1+3];
			myFilho.mySaturation = valores6[Filho[i].mySaturation];

			myFilho.mydecay = valores5[(int)Filho[i].mydecay];

			myFilho.myconf_FollowF1[0] = valores1[Filho[i].myconf_FollowF1[0]];
			myFilho.myconf_FollowF1ThrMin[0] = valores2[Filho[i].myconf_FollowF1ThrMin[0]];
			myFilho.myconf_FollowF1ThrMax[0] = valores2[Filho[i].myconf_FollowF1ThrMax[0]];
			myFilho.myconf_AgainstF1[0] = valores1[Filho[i].myconf_AgainstF1[0]];
			myFilho.myconf_AgainstF1ThrMin[0] = valores2[Filho[i].myconf_AgainstF1ThrMin[0]];
			myFilho.myconf_AgainstF1ThrMax[0] = valores2[Filho[i].myconf_AgainstF1ThrMax[0]];
			myFilho.myconf_HardFollow[0] = Filho[i].myconf_HardFollow[0];
			myFilho.myconf_ThrRelativo[0] = Filho[i].myconf_ThrRelativo[0];
			myFilho.myconf_FollowF1[1] = valores1[Filho[i].myconf_FollowF1[1]];
			myFilho.myconf_FollowF1ThrMin[1] = valores2[Filho[i].myconf_FollowF1ThrMin[1]];
			myFilho.myconf_FollowF1ThrMax[1] = valores2[Filho[i].myconf_FollowF1ThrMax[1]];
			myFilho.myconf_AgainstF1[1] = valores1[Filho[i].myconf_AgainstF1[1]];
			myFilho.myconf_AgainstF1ThrMin[1] = valores2[Filho[i].myconf_AgainstF1ThrMin[1]];
			myFilho.myconf_AgainstF1ThrMax[1] = valores2[Filho[i].myconf_AgainstF1ThrMax[1]];
			myFilho.myconf_HardFollow[1] = Filho[i].myconf_HardFollow[1];
			myFilho.myconf_ThrRelativo[1] = Filho[i].myconf_ThrRelativo[1];
			myFilho.myconf_FollowF1[2] = valores1[Filho[i].myconf_FollowF1[2]];
			myFilho.myconf_FollowF1ThrMin[2] = valores2[Filho[i].myconf_FollowF1ThrMin[2]];
			myFilho.myconf_FollowF1ThrMax[2] = valores2[Filho[i].myconf_FollowF1ThrMax[2]];
			myFilho.myconf_AgainstF1[2] = valores1[Filho[i].myconf_AgainstF1[2]];
			myFilho.myconf_AgainstF1ThrMin[2] = valores2[Filho[i].myconf_AgainstF1ThrMin[2]];
			myFilho.myconf_AgainstF1ThrMax[2] = valores2[Filho[i].myconf_AgainstF1ThrMax[2]];
			myFilho.myconf_HardFollow[2] = Filho[i].myconf_HardFollow[2];
			myFilho.myconf_ThrRelativo[2] = Filho[i].myconf_ThrRelativo[2];

			myFilho.myestado_F1Deposit[0] = valores3[Filho[i].myestado_F1Deposit[0]];
			myFilho.myestado_TimeLimit[0] = valores2[Filho[i].myestado_TimeLimit[0]];
			myFilho.myestado_RaioSensor[0] = valores7[Filho[i].myestado_RaioSensor[0]];
			myFilho.myestado_PosSensor[0] = valores8[Filho[i].myestado_PosSensor[0]];
			myFilho.myestado_BehaviorConfig[0] = Filho[i].myestado_BehaviorConfig[0];
			myFilho.myestado_1EstadoProb[0] = 4;
			myFilho.myestado_1EstadoProbValor[0] = valores2[Filho[i].myestado_1EstadoProbValor[0]+1];
			myFilho.myestado_2EstadoProb[0] = 5;
			myFilho.myestado_2EstadoProbValor[0] = valores2[Filho[i].myestado_2EstadoProbValor[0]+1];
			myFilho.myestado_F1Deposit[1] = valores3[Filho[i].myestado_F1Deposit[1]];
			myFilho.myestado_TimeLimit[1] = valores2[Filho[i].myestado_TimeLimit[1]];
			myFilho.myestado_RaioSensor[1] = valores7[Filho[i].myestado_RaioSensor[1]];
			myFilho.myestado_PosSensor[1] = valores8[Filho[i].myestado_PosSensor[1]];
			myFilho.myestado_BehaviorConfig[1] = Filho[i].myestado_BehaviorConfig[1];
			myFilho.myestado_1EstadoProb[1] = 3;
			myFilho.myestado_1EstadoProbValor[1] = valores2[Filho[i].myestado_1EstadoProbValor[1]+1];
			myFilho.myestado_2EstadoProb[1] = 2;
			myFilho.myestado_2EstadoProbValor[1] = 16;
			myFilho.myestado_F1Deposit[2] = valores3[Filho[i].myestado_F1Deposit[2]];
			myFilho.myestado_TimeLimit[2] = valores2[Filho[i].myestado_TimeLimit[2]];
			myFilho.myestado_RaioSensor[2] = valores7[Filho[i].myestado_RaioSensor[2]];
			myFilho.myestado_PosSensor[2] = valores8[Filho[i].myestado_PosSensor[2]];
			myFilho.myestado_BehaviorConfig[2] = Filho[i].myestado_BehaviorConfig[2];
			myFilho.myestado_1EstadoProb[2] = 2;
			myFilho.myestado_1EstadoProbValor[2] = valores2[Filho[i].myestado_1EstadoProbValor[2]+1];
			myFilho.myestado_2EstadoProb[2] = 3;
			myFilho.myestado_2EstadoProbValor[2] = 16;
			myFilho.myestado_F1Deposit[3] = valores3[Filho[i].myestado_F1Deposit[3]];
			myFilho.myestado_TimeLimit[3] = valores2[Filho[i].myestado_TimeLimit[3]];
			myFilho.myestado_RaioSensor[3] = valores7[Filho[i].myestado_RaioSensor[3]];
			myFilho.myestado_PosSensor[3] = valores8[Filho[i].myestado_PosSensor[3]];
			myFilho.myestado_BehaviorConfig[3] = Filho[i].myestado_BehaviorConfig[3];
			myFilho.myestado_1EstadoProb[3] = 1;
			myFilho.myestado_1EstadoProbValor[3] = valores2[Filho[i].myestado_1EstadoProbValor[3]+1];
			myFilho.myestado_2EstadoProb[3] = 5;
			myFilho.myestado_2EstadoProbValor[3] = valores2[Filho[i].myestado_2EstadoProbValor[3]+1];
			myFilho.myestado_F1Deposit[4] = valores3[Filho[i].myestado_F1Deposit[4]];
			myFilho.myestado_TimeLimit[4] = valores2[Filho[i].myestado_TimeLimit[4]];
			myFilho.myestado_RaioSensor[4] = valores7[Filho[i].myestado_RaioSensor[4]];
			myFilho.myestado_PosSensor[4] = valores8[Filho[i].myestado_PosSensor[4]];
			myFilho.myestado_BehaviorConfig[4] = Filho[i].myestado_BehaviorConfig[4];
			myFilho.myestado_1EstadoProb[4] = 1;
			myFilho.myestado_1EstadoProbValor[4] = valores2[Filho[i].myestado_1EstadoProbValor[4]+1];
			myFilho.myestado_2EstadoProb[4] = 4;
			myFilho.myestado_2EstadoProbValor[4] = valores2[Filho[i].myestado_2EstadoProbValor[4]+1];

			myFilho.myanguloTransicao[0] = valores9[Filho[i].myanguloTransicao[0]];
			myFilho.myanguloTransicao[1] = valores9[Filho[i].myanguloTransicao[1]];
			myFilho.myanguloTransicao[2] = valores9[Filho[i].myanguloTransicao[2]];
			myFilho.myanguloTransicao[3] = valores9[Filho[i].myanguloTransicao[3]];
			myFilho.myanguloTransicao[4] = valores9[Filho[i].myanguloTransicao[4]];
			myFilho.myanguloTransicao[5] = valores9[Filho[i].myanguloTransicao[5]];
			myFilho.myanguloTransicao[6] = valores9[Filho[i].myanguloTransicao[6]];
			myFilho.myanguloTransicao[7] = valores9[Filho[i].myanguloTransicao[7]];
			myFilho.myanguloTransicao[8] = valores9[Filho[i].myanguloTransicao[8]];
			myFilho.myanguloTransicao[9] = valores9[Filho[i].myanguloTransicao[9]];
			myFilho.myanguloTransicao[10] = valores9[Filho[i].myanguloTransicao[10]];
			myFilho.myanguloTransicao[11] = valores9[Filho[i].myanguloTransicao[11]];
			myFilho.myanguloTransicao[12] = valores9[Filho[i].myanguloTransicao[12]];
			myFilho.myanguloTransicao[13] = valores9[Filho[i].myanguloTransicao[13]];

                        for(j=0; j<4; j++) {
                                Reset();

                                srand(480);
                                SetNestF(185, 200, 25);
                                srand(j);
                                SetFoodF(90, 52, 30);
                                SetFoodF(170, 75, 30);

				configurar(myWIDTH, myHEIGHT, myid_formigas, myF, myFormiga, myCasa, myComida, myF1, myObstaculo,
					   myFilho.myprob_virar, myFilho.myRateF1, myFilho.myIntervalF1, myFilho.mySaturation, myFilho.mydecay, myFilho.myconf_FollowF1, myFilho.myconf_FollowF1ThrMin, myFilho.myconf_FollowF1ThrMax, myFilho.myconf_AgainstF1, myFilho.myconf_AgainstF1ThrMin, myFilho.myconf_AgainstF1ThrMax, myFilho.myconf_HardFollow, myFilho.myconf_ThrRelativo, myFilho.myestado_F1Deposit, myFilho.myestado_TimeLimit, myFilho.myestado_RaioSensor, myFilho.myestado_PosSensor, myFilho.myestado_BehaviorConfig, myFilho.myestado_1EstadoProb, myFilho.myestado_1EstadoProbValor, myFilho.myestado_2EstadoProb, myFilho.myestado_2EstadoProbValor, myFilho.myanguloTransicao);

Application->ProcessMessages();
                                notas[j] = fitness(myINTERACOES);
RefreshChao();
Refresh();
Application->ProcessMessages();
                        }

                        min = 0;
                        max = 1;

                        for(j=0; j<4; j++) {
                                if (notas[j] < notas[min]) min = j;
                                if (notas[j] > notas[max]) max = j;
                        }

                        Filho[i].nota = 0;
                        for(j=0; j<4; j++) {
                                if ((j != min) && (j != max)) {
                                        Filho[i].nota += notas[j];
                                }
                        }

/*
SetNestF(280, 280, 30);
SetFoodF(90, 130, 30);
SetFoodF(270, 140, 30);

configurar(myWIDTH, myHEIGHT, mymyprob_virar, valores3[Filho[i].myRateF1], valores3[Filho[i].myIntervalF1]+1, valores3[Filho[i].myestado1_FoodDeposit], valores3[Filho[i].myestado2_FoodDeposit], valores1[Filho[i].myestado1_FollowF1], valores1[Filho[i].myestado2_FollowF1],
                                                              valores2[Filho[i].myestado1_FollowF1ThrMin], valores2[Filho[i].myestado2_FollowF1ThrMin], valores2[Filho[i].myestado1_FollowF1ThrMax], valores2[Filho[i].myestado2_FollowF1ThrMax], valores1[Filho[i].myestado1_AgainstF1], valores1[Filho[i].myestado2_AgainstF1], valores2[Filho[i].myestado1_AgainstF1ThrMin], valores2[Filho[i].myestado2_AgainstF1ThrMin], valores2[Filho[i].myestado1_AgainstF1ThrMax], valores2[Filho[i].myestado2_AgainstF1ThrMax], valores2[Filho[i].myestado1_Time], valores2[Filho[i].myestado2_Time], valores3[Filho[i].myestado1_RaioSensor], valores3[Filho[i].myestado2_RaioSensor], valores4[Filho[i].myestado1_PosSensor], valores4[Filho[i].myestado2_PosSensor], myid_formigas, myF, myFormiga, myCasa, myComida, myF1, myObstaculo, Filho[i].myHardFollow, valores2[Filho[i].myProbExplorar]+1, Filho[i].myanguloParaVirar, valores5[(int)Filho[i].mydecay]);
Filho[i].nota = fitness(10);
*/
                        Application->ProcessMessages();

                        Label24->Caption = IntToStr(geracao+1);
                        Label75->Caption = IntToStr(i+1);
                        if (Filho[i].nota > maiornota) {
                                maiornota = Filho[i].nota;

                                SpeedButton2->Caption = IntToStr((int)maiornota);
                                SpeedButton2->Refresh();

				Edit7->Text = IntToStr(Filho[i].myprob_virar[0]);
				Edit8->Text = IntToStr(valores1[Filho[i].myprob_virar[1]]);
				Edit9->Text = IntToStr(valores1[Filho[i].myprob_virar[2]]);
				Edit10->Text = IntToStr(valores1[Filho[i].myprob_virar[3]]);
				Edit11->Text = IntToStr(valores1[Filho[i].myprob_virar[4]]);
				Edit37->Text = IntToStr(valores1[Filho[i].myprob_virar[5]]);
				Edit38->Text = IntToStr(valores1[Filho[i].myprob_virar[6]]);

				Edit4->Text = IntToStr(valores3[Filho[i].myRateF1]);
				Edit5->Text = IntToStr(valores3[Filho[i].myIntervalF1+3]);
				Edit1->Text = IntToStr(valores6[Filho[i].mySaturation]);

				Edit17->Text = FloatToStr(valores5[(int)Filho[i].mydecay]);

				Edit34->Text = IntToStr(valores1[Filho[i].myconf_FollowF1[0]]);
				Edit43->Text = IntToStr(valores2[Filho[i].myconf_FollowF1ThrMin[0]]);
				Edit42->Text = IntToStr(valores2[Filho[i].myconf_FollowF1ThrMax[0]]);
				Edit39->Text = IntToStr(valores1[Filho[i].myconf_AgainstF1[0]]);
				Edit35->Text = IntToStr(valores2[Filho[i].myconf_AgainstF1ThrMin[0]]);
				Edit36->Text = IntToStr(valores2[Filho[i].myconf_AgainstF1ThrMax[0]]);
				CheckBox1->Checked = Filho[i].myconf_HardFollow[0];
				CheckBox2->Checked = Filho[i].myconf_ThrRelativo[0];
				Edit12->Text = IntToStr(valores1[Filho[i].myconf_FollowF1[1]]);
				Edit13->Text = IntToStr(valores2[Filho[i].myconf_FollowF1ThrMin[1]]);
				Edit14->Text = IntToStr(valores2[Filho[i].myconf_FollowF1ThrMax[1]]);
				Edit24->Text = IntToStr(valores1[Filho[i].myconf_AgainstF1[1]]);
				Edit23->Text = IntToStr(valores2[Filho[i].myconf_AgainstF1ThrMin[1]]);
				Edit21->Text = IntToStr(valores2[Filho[i].myconf_AgainstF1ThrMax[1]]);
				CheckBox3->Checked = Filho[i].myconf_HardFollow[1];
				CheckBox4->Checked = Filho[i].myconf_ThrRelativo[1];
				Edit25->Text = IntToStr(valores1[Filho[i].myconf_FollowF1[2]]);
				Edit27->Text = IntToStr(valores2[Filho[i].myconf_FollowF1ThrMin[2]]);
				Edit28->Text = IntToStr(valores2[Filho[i].myconf_FollowF1ThrMax[2]]);
				Edit31->Text = IntToStr(valores1[Filho[i].myconf_AgainstF1[2]]);
				Edit30->Text = IntToStr(valores2[Filho[i].myconf_AgainstF1ThrMin[2]]);
				Edit29->Text = IntToStr(valores2[Filho[i].myconf_AgainstF1ThrMax[2]]);
				CheckBox5->Checked = Filho[i].myconf_HardFollow[2];
				CheckBox6->Checked = Filho[i].myconf_ThrRelativo[2];

				Edit19->Text = IntToStr(valores3[Filho[i].myestado_F1Deposit[0]]);
				Edit26->Text = IntToStr(valores2[Filho[i].myestado_TimeLimit[0]]);
				Edit44->Text = IntToStr(valores7[Filho[i].myestado_RaioSensor[0]]);
				Edit45->Text = IntToStr(valores8[Filho[i].myestado_PosSensor[0]]);
				Edit18->Text = IntToStr(Filho[i].myestado_BehaviorConfig[0]);
				Edit20->Text = IntToStr(Filho[i].myestado_1EstadoProb[0]);
				Edit22->Text = IntToStr(valores1[Filho[i].myestado_1EstadoProbValor[0]]);
				Edit40->Text = IntToStr(Filho[i].myestado_2EstadoProb[0]);
				Edit41->Text = IntToStr(valores1[Filho[i].myestado_2EstadoProbValor[0]]);
				Edit53->Text = IntToStr(valores3[Filho[i].myestado_F1Deposit[1]]);
				Edit49->Text = IntToStr(valores2[Filho[i].myestado_TimeLimit[1]]);
				Edit52->Text = IntToStr(valores7[Filho[i].myestado_RaioSensor[1]]);
				Edit50->Text = IntToStr(valores8[Filho[i].myestado_PosSensor[1]]);
				Edit48->Text = IntToStr(Filho[i].myestado_BehaviorConfig[1]);
				Edit46->Text = IntToStr(Filho[i].myestado_1EstadoProb[1]);
				Edit47->Text = IntToStr(valores1[Filho[i].myestado_1EstadoProbValor[1]]);
				Edit33->Text = IntToStr(Filho[i].myestado_2EstadoProb[1]);
				Edit32->Text = IntToStr(valores1[Filho[i].myestado_2EstadoProbValor[1]]);
				Edit80->Text = IntToStr(valores3[Filho[i].myestado_F1Deposit[2]]);
				Edit77->Text = IntToStr(valores2[Filho[i].myestado_TimeLimit[2]]);
				Edit79->Text = IntToStr(valores7[Filho[i].myestado_RaioSensor[2]]);
				Edit78->Text = IntToStr(valores8[Filho[i].myestado_PosSensor[2]]);
				Edit76->Text = IntToStr(Filho[i].myestado_BehaviorConfig[2]);
				Edit74->Text = IntToStr(Filho[i].myestado_1EstadoProb[2]);
				Edit75->Text = IntToStr(valores1[Filho[i].myestado_1EstadoProbValor[2]]);
				Edit73->Text = IntToStr(Filho[i].myestado_2EstadoProb[2]);
				Edit72->Text = IntToStr(valores1[Filho[i].myestado_2EstadoProbValor[2]]);
				Edit71->Text = IntToStr(valores3[Filho[i].myestado_F1Deposit[3]]);
				Edit68->Text = IntToStr(valores2[Filho[i].myestado_TimeLimit[3]]);
				Edit70->Text = IntToStr(valores7[Filho[i].myestado_RaioSensor[3]]);
				Edit69->Text = IntToStr(valores8[Filho[i].myestado_PosSensor[3]]);
				Edit67->Text = IntToStr(Filho[i].myestado_BehaviorConfig[3]);
				Edit65->Text = IntToStr(Filho[i].myestado_1EstadoProb[3]);
				Edit66->Text = IntToStr(valores1[Filho[i].myestado_1EstadoProbValor[3]]);
				Edit64->Text = IntToStr(Filho[i].myestado_2EstadoProb[3]);
				Edit63->Text = IntToStr(valores1[Filho[i].myestado_2EstadoProbValor[3]]);
				Edit62->Text = IntToStr(valores3[Filho[i].myestado_F1Deposit[4]]);
				Edit59->Text = IntToStr(valores2[Filho[i].myestado_TimeLimit[4]]);
				Edit61->Text = IntToStr(valores7[Filho[i].myestado_RaioSensor[4]]);
				Edit60->Text = IntToStr(valores8[Filho[i].myestado_PosSensor[4]]);
				Edit58->Text = IntToStr(Filho[i].myestado_BehaviorConfig[4]);
				Edit56->Text = IntToStr(Filho[i].myestado_1EstadoProb[4]);
				Edit57->Text = IntToStr(valores1[Filho[i].myestado_1EstadoProbValor[4]]);
				Edit55->Text = IntToStr(Filho[i].myestado_2EstadoProb[4]);
				Edit54->Text = IntToStr(valores1[Filho[i].myestado_2EstadoProbValor[4]]);

				Edit2->Text = IntToStr(valores9[Filho[i].myanguloTransicao[0]]);
				Edit81->Text = IntToStr(valores9[Filho[i].myanguloTransicao[1]]);
				Edit82->Text = IntToStr(valores9[Filho[i].myanguloTransicao[2]]);
				Edit83->Text = IntToStr(valores9[Filho[i].myanguloTransicao[3]]);
				Edit84->Text = IntToStr(valores9[Filho[i].myanguloTransicao[4]]);
				Edit90->Text = IntToStr(valores9[Filho[i].myanguloTransicao[5]]);
				Edit85->Text = IntToStr(valores9[Filho[i].myanguloTransicao[6]]);
				Edit86->Text = IntToStr(valores9[Filho[i].myanguloTransicao[7]]);
				Edit87->Text = IntToStr(valores9[Filho[i].myanguloTransicao[8]]);
				Edit88->Text = IntToStr(valores9[Filho[i].myanguloTransicao[9]]);
				Edit89->Text = IntToStr(valores9[Filho[i].myanguloTransicao[10]]);
				Edit91->Text = IntToStr(valores9[Filho[i].myanguloTransicao[11]]);
				Edit16->Text = IntToStr(valores9[Filho[i].myanguloTransicao[12]]);
				Edit92->Text = IntToStr(valores9[Filho[i].myanguloTransicao[13]]);
                        }
                }

                geracao++;

                // ordena por nota
                qsort((void *)Filho, FILHOSPORGERACAO, sizeof(Filho[0]), comparar);

                f = fopen(((AnsiString)"c:\\ants\\geracoes\\" + IntToStr(geracao) + ".txt").c_str(), "w");
                fr = fopen(((AnsiString)"c:\\ants\\geracoes_raw\\" + IntToStr(geracao) + ".txt").c_str(), "w");

                somaprob = 0;
                for(i=0; i<FILHOSPORGERACAO; i++) {
                        TmpFilho[i] = Filho[i];
                        somaprob += Filho[i].nota;

                        fprintf(fr, "%f %f %d %d %d %d %d %d %d %d %d %f %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d ",
                                maiornota, Filho[i].nota, Filho[i].myprob_virar[0], Filho[i].myprob_virar[1], Filho[i].myprob_virar[2], Filho[i].myprob_virar[3], Filho[i].myprob_virar[4], Filho[i].myprob_virar[5], Filho[i].myprob_virar[6], Filho[i].myRateF1, Filho[i].myIntervalF1, Filho[i].mySaturation, Filho[i].mydecay, Filho[i].myconf_FollowF1[0], Filho[i].myconf_FollowF1ThrMin[0], Filho[i].myconf_FollowF1ThrMax[0], Filho[i].myconf_AgainstF1[0], Filho[i].myconf_AgainstF1ThrMin[0], Filho[i].myconf_AgainstF1ThrMax[0], Filho[i].myconf_HardFollow[0], Filho[i].myconf_ThrRelativo[0], Filho[i].myconf_FollowF1[1], Filho[i].myconf_FollowF1ThrMin[1], Filho[i].myconf_FollowF1ThrMax[1], Filho[i].myconf_AgainstF1[1], Filho[i].myconf_AgainstF1ThrMin[1], Filho[i].myconf_AgainstF1ThrMax[1],
                                Filho[i].myconf_HardFollow[1], Filho[i].myconf_ThrRelativo[1], Filho[i].myconf_FollowF1[2], Filho[i].myconf_FollowF1ThrMin[2], Filho[i].myconf_FollowF1ThrMax[2], Filho[i].myconf_AgainstF1[2], Filho[i].myconf_AgainstF1ThrMin[2], Filho[i].myconf_AgainstF1ThrMax[2], Filho[i].myconf_HardFollow[2], Filho[i].myconf_ThrRelativo[2], Filho[i].myestado_F1Deposit[0], Filho[i].myestado_TimeLimit[0], Filho[i].myestado_RaioSensor[0], Filho[i].myestado_PosSensor[0], Filho[i].myestado_BehaviorConfig[0], Filho[i].myestado_1EstadoProb[0], Filho[i].myestado_1EstadoProbValor[0], Filho[i].myestado_2EstadoProb[0], Filho[i].myestado_2EstadoProbValor[0], Filho[i].myestado_F1Deposit[1], Filho[i].myestado_TimeLimit[1], Filho[i].myestado_RaioSensor[1],
                                Filho[i].myestado_PosSensor[1], Filho[i].myestado_BehaviorConfig[1], Filho[i].myestado_1EstadoProb[1], Filho[i].myestado_1EstadoProbValor[1], Filho[i].myestado_2EstadoProb[1], Filho[i].myestado_2EstadoProbValor[1], Filho[i].myestado_F1Deposit[2], Filho[i].myestado_TimeLimit[2], Filho[i].myestado_RaioSensor[2], Filho[i].myestado_PosSensor[2], Filho[i].myestado_BehaviorConfig[2], Filho[i].myestado_1EstadoProb[2], Filho[i].myestado_1EstadoProbValor[2], Filho[i].myestado_2EstadoProb[2], Filho[i].myestado_2EstadoProbValor[2], Filho[i].myestado_F1Deposit[3], Filho[i].myestado_TimeLimit[3], Filho[i].myestado_RaioSensor[3], Filho[i].myestado_PosSensor[3], Filho[i].myestado_BehaviorConfig[3], Filho[i].myestado_1EstadoProb[3], Filho[i].myestado_1EstadoProbValor[3],
                                Filho[i].myestado_2EstadoProb[3], Filho[i].myestado_2EstadoProbValor[3], Filho[i].myestado_F1Deposit[4], Filho[i].myestado_TimeLimit[4], Filho[i].myestado_RaioSensor[4], Filho[i].myestado_PosSensor[4], Filho[i].myestado_BehaviorConfig[4], Filho[i].myestado_1EstadoProb[4], Filho[i].myestado_1EstadoProbValor[4], Filho[i].myestado_2EstadoProb[4], Filho[i].myestado_2EstadoProbValor[4], Filho[i].myanguloTransicao[0], Filho[i].myanguloTransicao[1], Filho[i].myanguloTransicao[2], Filho[i].myanguloTransicao[3], Filho[i].myanguloTransicao[4], Filho[i].myanguloTransicao[5], Filho[i].myanguloTransicao[6], Filho[i].myanguloTransicao[7], Filho[i].myanguloTransicao[8], Filho[i].myanguloTransicao[9], Filho[i].myanguloTransicao[10], Filho[i].myanguloTransicao[11], Filho[i].myanguloTransicao[12], Filho[i].myanguloTransicao[13]);

			fprintf(f, "------------------------------------------------------------------\n");
			fprintf(f, "MAIOR NOTA TODAS GERACOES: %f\n\n", maiornota);

			fprintf(f, "NOTA.....................: %f\n\n", Filho[i].nota);

			fprintf(f, "myprob_virar[0].............: %d\n", Filho[i].myprob_virar[0]);
			fprintf(f, "myprob_virar[1].............: %d\n", valores1[Filho[i].myprob_virar[1]]);
			fprintf(f, "myprob_virar[2].............: %d\n", valores1[Filho[i].myprob_virar[2]]);
			fprintf(f, "myprob_virar[3].............: %d\n", valores1[Filho[i].myprob_virar[3]]);
			fprintf(f, "myprob_virar[4].............: %d\n", valores1[Filho[i].myprob_virar[4]]);
			fprintf(f, "myprob_virar[5].............: %d\n", valores1[Filho[i].myprob_virar[5]]);
			fprintf(f, "myprob_virar[6].............: %d\n", valores1[Filho[i].myprob_virar[6]]);

			fprintf(f, "myRateF1....................: %d\n", valores3[Filho[i].myRateF1]);
			fprintf(f, "myIntervalF1................: %d\n", valores3[Filho[i].myIntervalF1+3]);
			fprintf(f, "mySaturation................: %d\n", valores6[Filho[i].mySaturation]);

			fprintf(f, "mydecay.....................: %f\n", valores5[(int)Filho[i].mydecay]);

			fprintf(f, "myconf_FollowF1[0]..........: %d\n", valores1[Filho[i].myconf_FollowF1[0]]);
			fprintf(f, "myconf_FollowF1ThrMin[0]....: %d\n", valores2[Filho[i].myconf_FollowF1ThrMin[0]]);
			fprintf(f, "myconf_FollowF1ThrMax[0]....: %d\n", valores2[Filho[i].myconf_FollowF1ThrMax[0]]);
			fprintf(f, "myconf_AgainstF1[0].........: %d\n", valores1[Filho[i].myconf_AgainstF1[0]]);
			fprintf(f, "myconf_AgainstF1ThrMin[0]...: %d\n", valores2[Filho[i].myconf_AgainstF1ThrMin[0]]);
			fprintf(f, "myconf_AgainstF1ThrMax[0]...: %d\n", valores2[Filho[i].myconf_AgainstF1ThrMax[0]]);
			fprintf(f, "myconf_HardFollow[0]........: %d\n", Filho[i].myconf_HardFollow[0]);
			fprintf(f, "myconf_ThrRelativo[0].......: %d\n", Filho[i].myconf_ThrRelativo[0]);
			fprintf(f, "myconf_FollowF1[1]..........: %d\n", valores1[Filho[i].myconf_FollowF1[1]]);
			fprintf(f, "myconf_FollowF1ThrMin[1]....: %d\n", valores2[Filho[i].myconf_FollowF1ThrMin[1]]);
			fprintf(f, "myconf_FollowF1ThrMax[1]....: %d\n", valores2[Filho[i].myconf_FollowF1ThrMax[1]]);
			fprintf(f, "myconf_AgainstF1[1].........: %d\n", valores1[Filho[i].myconf_AgainstF1[1]]);
			fprintf(f, "myconf_AgainstF1ThrMin[1]...: %d\n", valores2[Filho[i].myconf_AgainstF1ThrMin[1]]);
			fprintf(f, "myconf_AgainstF1ThrMax[1]...: %d\n", valores2[Filho[i].myconf_AgainstF1ThrMax[1]]);
			fprintf(f, "myconf_HardFollow[1]........: %d\n", Filho[i].myconf_HardFollow[1]);
			fprintf(f, "myconf_ThrRelativo[1].......: %d\n", Filho[i].myconf_ThrRelativo[1]);
			fprintf(f, "myconf_FollowF1[2]..........: %d\n", valores1[Filho[i].myconf_FollowF1[2]]);
			fprintf(f, "myconf_FollowF1ThrMin[2]....: %d\n", valores2[Filho[i].myconf_FollowF1ThrMin[2]]);
			fprintf(f, "myconf_FollowF1ThrMax[2]....: %d\n", valores2[Filho[i].myconf_FollowF1ThrMax[2]]);
			fprintf(f, "myconf_AgainstF1[2].........: %d\n", valores1[Filho[i].myconf_AgainstF1[2]]);
			fprintf(f, "myconf_AgainstF1ThrMin[2]...: %d\n", valores2[Filho[i].myconf_AgainstF1ThrMin[2]]);
			fprintf(f, "myconf_AgainstF1ThrMax[2]...: %d\n", valores2[Filho[i].myconf_AgainstF1ThrMax[2]]);
			fprintf(f, "myconf_HardFollow[2]........: %d\n", Filho[i].myconf_HardFollow[2]);
			fprintf(f, "myconf_ThrRelativo[2].......: %d\n", Filho[i].myconf_ThrRelativo[2]);

			fprintf(f, "myestado_F1Deposit[0].......: %d\n", valores3[Filho[i].myestado_F1Deposit[0]]);
			fprintf(f, "myestado_TimeLimit[0].......: %d\n", valores2[Filho[i].myestado_TimeLimit[0]]);
			fprintf(f, "myestado_RaioSensor[0]......: %d\n", valores7[Filho[i].myestado_RaioSensor[0]]);
			fprintf(f, "myestado_PosSensor[0].......: %d\n", valores8[Filho[i].myestado_PosSensor[0]]);
			fprintf(f, "myestado_BehaviorConfig[0]..: %d\n", Filho[i].myestado_BehaviorConfig[0]);
			fprintf(f, "myestado_1EstadoProb[0].....: %d\n", 4);
			fprintf(f, "myestado_1EstadoProbValor[0]: %d\n", valores1[Filho[i].myestado_1EstadoProbValor[0]+1]);
			fprintf(f, "myestado_2EstadoProb[0].....: %d\n", 5);
			fprintf(f, "myestado_2EstadoProbValor[0]: %d\n", valores1[Filho[i].myestado_2EstadoProbValor[0]+1]);
			fprintf(f, "myestado_F1Deposit[1].......: %d\n", valores3[Filho[i].myestado_F1Deposit[1]]);
			fprintf(f, "myestado_TimeLimit[1].......: %d\n", valores2[Filho[i].myestado_TimeLimit[1]]);
			fprintf(f, "myestado_RaioSensor[1]......: %d\n", valores7[Filho[i].myestado_RaioSensor[1]]);
			fprintf(f, "myestado_PosSensor[1].......: %d\n", valores8[Filho[i].myestado_PosSensor[1]]);
			fprintf(f, "myestado_BehaviorConfig[1]..: %d\n", Filho[i].myestado_BehaviorConfig[1]);
			fprintf(f, "myestado_1EstadoProb[1].....: %d\n", 3);
			fprintf(f, "myestado_1EstadoProbValor[1]: %d\n", valores1[Filho[i].myestado_1EstadoProbValor[1]+1]);
			fprintf(f, "myestado_2EstadoProb[1].....: %d\n", 2);
			fprintf(f, "myestado_2EstadoProbValor[1]: %d\n", valores1[16+1]);
			fprintf(f, "myestado_F1Deposit[2].......: %d\n", valores3[Filho[i].myestado_F1Deposit[2]]);
			fprintf(f, "myestado_TimeLimit[2].......: %d\n", valores2[Filho[i].myestado_TimeLimit[2]]);
			fprintf(f, "myestado_RaioSensor[2]......: %d\n", valores7[Filho[i].myestado_RaioSensor[2]]);
			fprintf(f, "myestado_PosSensor[2].......: %d\n", valores8[Filho[i].myestado_PosSensor[2]]);
			fprintf(f, "myestado_BehaviorConfig[2]..: %d\n", Filho[i].myestado_BehaviorConfig[2]);
			fprintf(f, "myestado_1EstadoProb[2].....: %d\n", 2);
			fprintf(f, "myestado_1EstadoProbValor[2]: %d\n", valores1[Filho[i].myestado_1EstadoProbValor[2]+1]);
			fprintf(f, "myestado_2EstadoProb[2].....: %d\n", 3);
			fprintf(f, "myestado_2EstadoProbValor[2]: %d\n", valores1[16+1]);
			fprintf(f, "myestado_F1Deposit[3].......: %d\n", valores3[Filho[i].myestado_F1Deposit[3]]);
			fprintf(f, "myestado_TimeLimit[3].......: %d\n", valores2[Filho[i].myestado_TimeLimit[3]]);
			fprintf(f, "myestado_RaioSensor[3]......: %d\n", valores7[Filho[i].myestado_RaioSensor[3]]);
			fprintf(f, "myestado_PosSensor[3].......: %d\n", valores8[Filho[i].myestado_PosSensor[3]]);
			fprintf(f, "myestado_BehaviorConfig[3]..: %d\n", Filho[i].myestado_BehaviorConfig[3]);
			fprintf(f, "myestado_1EstadoProb[3].....: %d\n", 1);
			fprintf(f, "myestado_1EstadoProbValor[3]: %d\n", valores1[Filho[i].myestado_1EstadoProbValor[3]+1]);
			fprintf(f, "myestado_2EstadoProb[3].....: %d\n", 5);
			fprintf(f, "myestado_2EstadoProbValor[3]: %d\n", valores1[Filho[i].myestado_2EstadoProbValor[3]+1]);
			fprintf(f, "myestado_F1Deposit[4].......: %d\n", valores3[Filho[i].myestado_F1Deposit[4]]);
			fprintf(f, "myestado_TimeLimit[4].......: %d\n", valores2[Filho[i].myestado_TimeLimit[4]]);
			fprintf(f, "myestado_RaioSensor[4]......: %d\n", valores7[Filho[i].myestado_RaioSensor[4]]);
			fprintf(f, "myestado_PosSensor[4].......: %d\n", valores8[Filho[i].myestado_PosSensor[4]]);
			fprintf(f, "myestado_BehaviorConfig[4]..: %d\n", Filho[i].myestado_BehaviorConfig[4]);
			fprintf(f, "myestado_1EstadoProb[4].....: %d\n", 1);
			fprintf(f, "myestado_1EstadoProbValor[4]: %d\n", valores1[Filho[i].myestado_1EstadoProbValor[4]+1]);
			fprintf(f, "myestado_2EstadoProb[4].....: %d\n", 4);
			fprintf(f, "myestado_2EstadoProbValor[4]: %d\n", valores1[Filho[i].myestado_2EstadoProbValor[4]+1]);

			fprintf(f, "myanguloTransicao[0]........: %d\n", valores9[Filho[i].myanguloTransicao[0]]);
			fprintf(f, "myanguloTransicao[1]........: %d\n", valores9[Filho[i].myanguloTransicao[1]]);
			fprintf(f, "myanguloTransicao[2]........: %d\n", valores9[Filho[i].myanguloTransicao[2]]);
			fprintf(f, "myanguloTransicao[3]........: %d\n", valores9[Filho[i].myanguloTransicao[3]]);
			fprintf(f, "myanguloTransicao[4]........: %d\n", valores9[Filho[i].myanguloTransicao[4]]);
			fprintf(f, "myanguloTransicao[5]........: %d\n", valores9[Filho[i].myanguloTransicao[5]]);
			fprintf(f, "myanguloTransicao[6]........: %d\n", valores9[Filho[i].myanguloTransicao[6]]);
			fprintf(f, "myanguloTransicao[7]........: %d\n", valores9[Filho[i].myanguloTransicao[7]]);
			fprintf(f, "myanguloTransicao[8]........: %d\n", valores9[Filho[i].myanguloTransicao[8]]);
			fprintf(f, "myanguloTransicao[9]........: %d\n", valores9[Filho[i].myanguloTransicao[9]]);
			fprintf(f, "myanguloTransicao[10].......: %d\n", valores9[Filho[i].myanguloTransicao[10]]);
			fprintf(f, "myanguloTransicao[11].......: %d\n", valores9[Filho[i].myanguloTransicao[11]]);
			fprintf(f, "myanguloTransicao[12].......: %d\n", valores9[Filho[i].myanguloTransicao[12]]);
			fprintf(f, "myanguloTransicao[13].......: %d\n", valores9[Filho[i].myanguloTransicao[13]]);
			fprintf(f, "------------------------------------------------------------------\n\n");
                }
                fclose(f);
                fclose(fr);

                Filho[0] = TmpFilho[0]; // nao faz nada
                melhor = rand() % 100;
                if (melhor < 60) cruza(1, 0, rand() % 5);
                else cruza(1, 0, rand() % FILHOSPORGERACAO);
                melhor = rand() % 100;
                if (melhor < 60) cruza(1, 0, rand() % 5);
                else cruza(1, 0, rand() % FILHOSPORGERACAO);
                melhor = rand() % 100;
                if (melhor < 60) cruza(1, 0, rand() % 5);
                else cruza(1, 0, rand() % FILHOSPORGERACAO);
                for(i=4; i<FILHOSPORGERACAO; i++) {
                        F1a = rand() % FILHOSPORGERACAO;
                        F2a = rand() % FILHOSPORGERACAO;

                        if (Filho[F1a].nota > Filho[F2a].nota) melhor = F1a;
                        else melhor = F2a;

                        F1a = rand() % FILHOSPORGERACAO;
                        F2a = rand() % FILHOSPORGERACAO;

                        if (Filho[F1a].nota > Filho[F2a].nota) cruza(i, melhor, F1a);
                        else cruza(i, melhor, F2a);
                }

                if (geracao % acadaqtasgeracoes == 0) {
                        for(i=0; i<filhosaleatorios; i++) {
                                geraFilhoRandomico(FILHOSPORGERACAO-i-1);
                        }
                }
        }
}
//---------------------------------------------------------------------------


void __fastcall TForm1::SaveClick(TObject *Sender)
{
        int i, j;
        FILE *f;

        SaveDialog1->Execute();
        f = fopen(SaveDialog1->FileName.c_str(), "w");
        if (!(f)) { ShowMessage("Erro abrindo arquivo"); return; }
	fprintf(f, "%s\n", IntToStr(myWIDTH).c_str());
	fprintf(f, "%s\n", IntToStr(myHEIGHT).c_str());

	fprintf(f, "%s\n", ((Edit7->Text != "") ? Edit7->Text.c_str() : ""));
	fprintf(f, "%s\n", ((Edit8->Text != "") ? Edit8->Text.c_str() : ""));
	fprintf(f, "%s\n", ((Edit9->Text != "") ? Edit9->Text.c_str() : ""));
	fprintf(f, "%s\n", ((Edit10->Text != "") ? Edit10->Text.c_str() : ""));
	fprintf(f, "%s\n", ((Edit11->Text != "") ? Edit11->Text.c_str() : ""));
	fprintf(f, "%s\n", ((Edit37->Text != "") ? Edit37->Text.c_str() : ""));
	fprintf(f, "%s\n", ((Edit38->Text != "") ? Edit38->Text.c_str() : ""));

	fprintf(f, "%s\n", ((Edit4->Text != "") ? Edit4->Text.c_str() : ""));
	fprintf(f, "%s\n", ((Edit5->Text != "") ? Edit5->Text.c_str() : ""));
	fprintf(f, "%s\n", ((Edit1->Text != "") ? Edit1->Text.c_str() : ""));

	fprintf(f, "%s\n", ((Edit17->Text != "") ? Edit17->Text.c_str() : ""));

	fprintf(f, "%s\n", ((Edit34->Text != "") ? Edit34->Text.c_str() : ""));
	fprintf(f, "%s\n", ((Edit43->Text != "") ? Edit43->Text.c_str() : ""));
	fprintf(f, "%s\n", ((Edit42->Text != "") ? Edit42->Text.c_str() : ""));
	fprintf(f, "%s\n", ((Edit39->Text != "") ? Edit39->Text.c_str() : ""));
	fprintf(f, "%s\n", ((Edit35->Text != "") ? Edit35->Text.c_str() : ""));
	fprintf(f, "%s\n", ((Edit36->Text != "") ? Edit36->Text.c_str() : ""));
	fprintf(f, "%d\n", (CheckBox1->Checked ? 1 : 0));
	fprintf(f, "%d\n", (CheckBox2->Checked ? 1 : 0));
	fprintf(f, "%s\n", ((Edit12->Text != "") ? Edit12->Text.c_str() : ""));
	fprintf(f, "%s\n", ((Edit13->Text != "") ? Edit13->Text.c_str() : ""));
	fprintf(f, "%s\n", ((Edit14->Text != "") ? Edit14->Text.c_str() : ""));
	fprintf(f, "%s\n", ((Edit24->Text != "") ? Edit24->Text.c_str() : ""));
	fprintf(f, "%s\n", ((Edit23->Text != "") ? Edit23->Text.c_str() : ""));
	fprintf(f, "%s\n", ((Edit21->Text != "") ? Edit21->Text.c_str() : ""));
	fprintf(f, "%d\n", (CheckBox3->Checked ? 1 : 0));
	fprintf(f, "%d\n", (CheckBox4->Checked ? 1 : 0));
	fprintf(f, "%s\n", ((Edit25->Text != "") ? Edit25->Text.c_str() : ""));
	fprintf(f, "%s\n", ((Edit27->Text != "") ? Edit27->Text.c_str() : ""));
	fprintf(f, "%s\n", ((Edit28->Text != "") ? Edit28->Text.c_str() : ""));
	fprintf(f, "%s\n", ((Edit31->Text != "") ? Edit31->Text.c_str() : ""));
	fprintf(f, "%s\n", ((Edit30->Text != "") ? Edit30->Text.c_str() : ""));
	fprintf(f, "%s\n", ((Edit29->Text != "") ? Edit29->Text.c_str() : ""));
	fprintf(f, "%d\n", (CheckBox5->Checked ? 1 : 0));
	fprintf(f, "%d\n", (CheckBox6->Checked ? 1 : 0));

	fprintf(f, "%s\n", ((Edit19->Text != "") ? Edit19->Text.c_str() : ""));
	fprintf(f, "%s\n", ((Edit26->Text != "") ? Edit26->Text.c_str() : ""));
	fprintf(f, "%s\n", ((Edit44->Text != "") ? Edit44->Text.c_str() : ""));
	fprintf(f, "%s\n", ((Edit45->Text != "") ? Edit45->Text.c_str() : ""));
	fprintf(f, "%s\n", ((Edit18->Text != "") ? Edit18->Text.c_str() : ""));
	fprintf(f, "%s\n", ((Edit20->Text != "") ? Edit20->Text.c_str() : ""));
	fprintf(f, "%s\n", ((Edit22->Text != "") ? Edit22->Text.c_str() : ""));
	fprintf(f, "%s\n", ((Edit40->Text != "") ? Edit40->Text.c_str() : ""));
	fprintf(f, "%s\n", ((Edit41->Text != "") ? Edit41->Text.c_str() : ""));
	fprintf(f, "%s\n", ((Edit53->Text != "") ? Edit53->Text.c_str() : ""));
	fprintf(f, "%s\n", ((Edit49->Text != "") ? Edit49->Text.c_str() : ""));
	fprintf(f, "%s\n", ((Edit52->Text != "") ? Edit52->Text.c_str() : ""));
	fprintf(f, "%s\n", ((Edit50->Text != "") ? Edit50->Text.c_str() : ""));
	fprintf(f, "%s\n", ((Edit48->Text != "") ? Edit48->Text.c_str() : ""));
	fprintf(f, "%s\n", ((Edit46->Text != "") ? Edit46->Text.c_str() : ""));
	fprintf(f, "%s\n", ((Edit47->Text != "") ? Edit47->Text.c_str() : ""));
	fprintf(f, "%s\n", ((Edit33->Text != "") ? Edit33->Text.c_str() : ""));
	fprintf(f, "%s\n", ((Edit32->Text != "") ? Edit32->Text.c_str() : ""));
	fprintf(f, "%s\n", ((Edit80->Text != "") ? Edit80->Text.c_str() : ""));
	fprintf(f, "%s\n", ((Edit77->Text != "") ? Edit77->Text.c_str() : ""));
	fprintf(f, "%s\n", ((Edit79->Text != "") ? Edit79->Text.c_str() : ""));
	fprintf(f, "%s\n", ((Edit78->Text != "") ? Edit78->Text.c_str() : ""));
	fprintf(f, "%s\n", ((Edit76->Text != "") ? Edit76->Text.c_str() : ""));
	fprintf(f, "%s\n", ((Edit74->Text != "") ? Edit74->Text.c_str() : ""));
	fprintf(f, "%s\n", ((Edit75->Text != "") ? Edit75->Text.c_str() : ""));
	fprintf(f, "%s\n", ((Edit73->Text != "") ? Edit73->Text.c_str() : ""));
	fprintf(f, "%s\n", ((Edit72->Text != "") ? Edit72->Text.c_str() : ""));
	fprintf(f, "%s\n", ((Edit71->Text != "") ? Edit71->Text.c_str() : ""));
	fprintf(f, "%s\n", ((Edit68->Text != "") ? Edit68->Text.c_str() : ""));
	fprintf(f, "%s\n", ((Edit70->Text != "") ? Edit70->Text.c_str() : ""));
	fprintf(f, "%s\n", ((Edit69->Text != "") ? Edit69->Text.c_str() : ""));
	fprintf(f, "%s\n", ((Edit67->Text != "") ? Edit67->Text.c_str() : ""));
	fprintf(f, "%s\n", ((Edit65->Text != "") ? Edit65->Text.c_str() : ""));
	fprintf(f, "%s\n", ((Edit66->Text != "") ? Edit66->Text.c_str() : ""));
	fprintf(f, "%s\n", ((Edit64->Text != "") ? Edit64->Text.c_str() : ""));
	fprintf(f, "%s\n", ((Edit63->Text != "") ? Edit63->Text.c_str() : ""));
	fprintf(f, "%s\n", ((Edit62->Text != "") ? Edit62->Text.c_str() : ""));
	fprintf(f, "%s\n", ((Edit59->Text != "") ? Edit59->Text.c_str() : ""));
	fprintf(f, "%s\n", ((Edit61->Text != "") ? Edit61->Text.c_str() : ""));
	fprintf(f, "%s\n", ((Edit60->Text != "") ? Edit60->Text.c_str() : ""));
	fprintf(f, "%s\n", ((Edit58->Text != "") ? Edit58->Text.c_str() : ""));
	fprintf(f, "%s\n", ((Edit56->Text != "") ? Edit56->Text.c_str() : ""));
	fprintf(f, "%s\n", ((Edit57->Text != "") ? Edit57->Text.c_str() : ""));
	fprintf(f, "%s\n", ((Edit55->Text != "") ? Edit55->Text.c_str() : ""));
	fprintf(f, "%s\n", ((Edit54->Text != "") ? Edit54->Text.c_str() : ""));

	fprintf(f, "%s\n", ((Edit2->Text != "") ? Edit2->Text.c_str() : ""));
	fprintf(f, "%s\n", ((Edit81->Text != "") ? Edit81->Text.c_str() : ""));
	fprintf(f, "%s\n", ((Edit82->Text != "") ? Edit82->Text.c_str() : ""));
	fprintf(f, "%s\n", ((Edit83->Text != "") ? Edit83->Text.c_str() : ""));
	fprintf(f, "%s\n", ((Edit84->Text != "") ? Edit84->Text.c_str() : ""));
	fprintf(f, "%s\n", ((Edit90->Text != "") ? Edit90->Text.c_str() : ""));
	fprintf(f, "%s\n", ((Edit85->Text != "") ? Edit85->Text.c_str() : ""));
	fprintf(f, "%s\n", ((Edit86->Text != "") ? Edit86->Text.c_str() : ""));
	fprintf(f, "%s\n", ((Edit87->Text != "") ? Edit87->Text.c_str() : ""));
	fprintf(f, "%s\n", ((Edit88->Text != "") ? Edit88->Text.c_str() : ""));
	fprintf(f, "%s\n", ((Edit89->Text != "") ? Edit89->Text.c_str() : ""));
	fprintf(f, "%s\n", ((Edit91->Text != "") ? Edit91->Text.c_str() : ""));

        for(i=0; i<myHEIGHT; i++) {
                for(j=0; j<myWIDTH; j++) {
                        fprintf(f, "%d ", myFormiga[i][j]);
                        fprintf(f, "%d ", myCasa[i][j]);
                        fprintf(f, "%d ", myComida[i][j]);
                        fprintf(f, "%d ", myF1[i][j]);
                        fprintf(f, "%d ", myObstaculo[i][j]);
                }
        }

        fprintf(f, "%d ", myid_formigas);

        for(i=0; i<myid_formigas; i++) {
                fprintf(f, "%d %d %d %d %d %d %d %d %d %d %d %d ", myF[i].x, myF[i].y, myF[i].angulo, myF[i].dirx, myF[i].diry, myF[i].erroxy, myF[i].estado, myF[i].contador[0], myF[i].contador[1], myF[i].contador[2], myF[i].contador[3], myF[i].contador[4]);
        }

        fclose(f);
}
//---------------------------------------------------------------------------

void __fastcall TForm1::LoadClick(TObject *Sender)
{
        int i, j;
        FILE *f;
        char param[20];

        OpenDialog1->Execute();
        f = fopen(OpenDialog1->FileName.c_str(), "r");
        if (!(f)) { ShowMessage("Erro abrindo arquivo"); return; }
	fgets(param, 15, f); param[strlen(param)-1] = '\0'; Edit1->Text = param;
	fgets(param, 15, f); param[strlen(param)-1] = '\0'; Edit2->Text = param;

        myWIDTH = StrToInt(Edit1->Text);
        myHEIGHT = StrToInt(Edit2->Text);

        Reset();

	fgets(param, 15, f); param[strlen(param)-1] = '\0'; Edit7->Text = param;
	fgets(param, 15, f); param[strlen(param)-1] = '\0'; Edit8->Text = param;
	fgets(param, 15, f); param[strlen(param)-1] = '\0'; Edit9->Text = param;
	fgets(param, 15, f); param[strlen(param)-1] = '\0'; Edit10->Text = param;
	fgets(param, 15, f); param[strlen(param)-1] = '\0'; Edit11->Text = param;
	fgets(param, 15, f); param[strlen(param)-1] = '\0'; Edit37->Text = param;
	fgets(param, 15, f); param[strlen(param)-1] = '\0'; Edit38->Text = param;

	fgets(param, 15, f); param[strlen(param)-1] = '\0'; Edit4->Text = param;
	fgets(param, 15, f); param[strlen(param)-1] = '\0'; Edit5->Text = param;
	fgets(param, 15, f); param[strlen(param)-1] = '\0'; Edit1->Text = param;

	fgets(param, 15, f); param[strlen(param)-1] = '\0'; Edit17->Text = param;

	fgets(param, 15, f); param[strlen(param)-1] = '\0'; Edit34->Text = param;
	fgets(param, 15, f); param[strlen(param)-1] = '\0'; Edit43->Text = param;
	fgets(param, 15, f); param[strlen(param)-1] = '\0'; Edit42->Text = param;
	fgets(param, 15, f); param[strlen(param)-1] = '\0'; Edit39->Text = param;
	fgets(param, 15, f); param[strlen(param)-1] = '\0'; Edit35->Text = param;
	fgets(param, 15, f); param[strlen(param)-1] = '\0'; Edit36->Text = param;
	fgets(param, 15, f); param[strlen(param)-1] = '\0'; CheckBox1->Checked = (param[0] == '1' ? 1 : 0);
	fgets(param, 15, f); param[strlen(param)-1] = '\0'; CheckBox2->Checked = (param[0] == '1' ? 1 : 0);
	fgets(param, 15, f); param[strlen(param)-1] = '\0'; Edit12->Text = param;
	fgets(param, 15, f); param[strlen(param)-1] = '\0'; Edit13->Text = param;
	fgets(param, 15, f); param[strlen(param)-1] = '\0'; Edit14->Text = param;
	fgets(param, 15, f); param[strlen(param)-1] = '\0'; Edit24->Text = param;
	fgets(param, 15, f); param[strlen(param)-1] = '\0'; Edit23->Text = param;
	fgets(param, 15, f); param[strlen(param)-1] = '\0'; Edit21->Text = param;
	fgets(param, 15, f); param[strlen(param)-1] = '\0'; CheckBox3->Checked = (param[0] == '1' ? 1 : 0);
	fgets(param, 15, f); param[strlen(param)-1] = '\0'; CheckBox4->Checked = (param[0] == '1' ? 1 : 0);
	fgets(param, 15, f); param[strlen(param)-1] = '\0'; Edit25->Text = param;
	fgets(param, 15, f); param[strlen(param)-1] = '\0'; Edit27->Text = param;
	fgets(param, 15, f); param[strlen(param)-1] = '\0'; Edit28->Text = param;
	fgets(param, 15, f); param[strlen(param)-1] = '\0'; Edit31->Text = param;
	fgets(param, 15, f); param[strlen(param)-1] = '\0'; Edit30->Text = param;
	fgets(param, 15, f); param[strlen(param)-1] = '\0'; Edit29->Text = param;
	fgets(param, 15, f); param[strlen(param)-1] = '\0'; CheckBox5->Checked = (param[0] == '1' ? 1 : 0);
	fgets(param, 15, f); param[strlen(param)-1] = '\0'; CheckBox6->Checked = (param[0] == '1' ? 1 : 0);

	fgets(param, 15, f); param[strlen(param)-1] = '\0'; Edit19->Text = param;
	fgets(param, 15, f); param[strlen(param)-1] = '\0'; Edit26->Text = param;
	fgets(param, 15, f); param[strlen(param)-1] = '\0'; Edit44->Text = param;
	fgets(param, 15, f); param[strlen(param)-1] = '\0'; Edit45->Text = param;
	fgets(param, 15, f); param[strlen(param)-1] = '\0'; Edit18->Text = param;
	fgets(param, 15, f); param[strlen(param)-1] = '\0'; Edit20->Text = param;
	fgets(param, 15, f); param[strlen(param)-1] = '\0'; Edit22->Text = param;
	fgets(param, 15, f); param[strlen(param)-1] = '\0'; Edit40->Text = param;
	fgets(param, 15, f); param[strlen(param)-1] = '\0'; Edit41->Text = param;
	fgets(param, 15, f); param[strlen(param)-1] = '\0'; Edit53->Text = param;
	fgets(param, 15, f); param[strlen(param)-1] = '\0'; Edit49->Text = param;
	fgets(param, 15, f); param[strlen(param)-1] = '\0'; Edit52->Text = param;
	fgets(param, 15, f); param[strlen(param)-1] = '\0'; Edit50->Text = param;
	fgets(param, 15, f); param[strlen(param)-1] = '\0'; Edit48->Text = param;
	fgets(param, 15, f); param[strlen(param)-1] = '\0'; Edit46->Text = param;
	fgets(param, 15, f); param[strlen(param)-1] = '\0'; Edit47->Text = param;
	fgets(param, 15, f); param[strlen(param)-1] = '\0'; Edit33->Text = param;
	fgets(param, 15, f); param[strlen(param)-1] = '\0'; Edit32->Text = param;
	fgets(param, 15, f); param[strlen(param)-1] = '\0'; Edit80->Text = param;
	fgets(param, 15, f); param[strlen(param)-1] = '\0'; Edit77->Text = param;
	fgets(param, 15, f); param[strlen(param)-1] = '\0'; Edit79->Text = param;
	fgets(param, 15, f); param[strlen(param)-1] = '\0'; Edit78->Text = param;
	fgets(param, 15, f); param[strlen(param)-1] = '\0'; Edit76->Text = param;
	fgets(param, 15, f); param[strlen(param)-1] = '\0'; Edit74->Text = param;
	fgets(param, 15, f); param[strlen(param)-1] = '\0'; Edit75->Text = param;
	fgets(param, 15, f); param[strlen(param)-1] = '\0'; Edit73->Text = param;
	fgets(param, 15, f); param[strlen(param)-1] = '\0'; Edit72->Text = param;
	fgets(param, 15, f); param[strlen(param)-1] = '\0'; Edit71->Text = param;
	fgets(param, 15, f); param[strlen(param)-1] = '\0'; Edit68->Text = param;
	fgets(param, 15, f); param[strlen(param)-1] = '\0'; Edit70->Text = param;
	fgets(param, 15, f); param[strlen(param)-1] = '\0'; Edit69->Text = param;
	fgets(param, 15, f); param[strlen(param)-1] = '\0'; Edit67->Text = param;
	fgets(param, 15, f); param[strlen(param)-1] = '\0'; Edit65->Text = param;
	fgets(param, 15, f); param[strlen(param)-1] = '\0'; Edit66->Text = param;
	fgets(param, 15, f); param[strlen(param)-1] = '\0'; Edit64->Text = param;
	fgets(param, 15, f); param[strlen(param)-1] = '\0'; Edit63->Text = param;
	fgets(param, 15, f); param[strlen(param)-1] = '\0'; Edit62->Text = param;
	fgets(param, 15, f); param[strlen(param)-1] = '\0'; Edit59->Text = param;
	fgets(param, 15, f); param[strlen(param)-1] = '\0'; Edit61->Text = param;
	fgets(param, 15, f); param[strlen(param)-1] = '\0'; Edit60->Text = param;
	fgets(param, 15, f); param[strlen(param)-1] = '\0'; Edit58->Text = param;
	fgets(param, 15, f); param[strlen(param)-1] = '\0'; Edit56->Text = param;
	fgets(param, 15, f); param[strlen(param)-1] = '\0'; Edit57->Text = param;
	fgets(param, 15, f); param[strlen(param)-1] = '\0'; Edit55->Text = param;
	fgets(param, 15, f); param[strlen(param)-1] = '\0'; Edit54->Text = param;

	fgets(param, 15, f); param[strlen(param)-1] = '\0'; Edit2->Text = param;
	fgets(param, 15, f); param[strlen(param)-1] = '\0'; Edit81->Text = param;
	fgets(param, 15, f); param[strlen(param)-1] = '\0'; Edit82->Text = param;
	fgets(param, 15, f); param[strlen(param)-1] = '\0'; Edit83->Text = param;
	fgets(param, 15, f); param[strlen(param)-1] = '\0'; Edit84->Text = param;
	fgets(param, 15, f); param[strlen(param)-1] = '\0'; Edit90->Text = param;
	fgets(param, 15, f); param[strlen(param)-1] = '\0'; Edit85->Text = param;
	fgets(param, 15, f); param[strlen(param)-1] = '\0'; Edit86->Text = param;
	fgets(param, 15, f); param[strlen(param)-1] = '\0'; Edit87->Text = param;
	fgets(param, 15, f); param[strlen(param)-1] = '\0'; Edit88->Text = param;
	fgets(param, 15, f); param[strlen(param)-1] = '\0'; Edit89->Text = param;
	fgets(param, 15, f); param[strlen(param)-1] = '\0'; Edit91->Text = param;

        for(i=0; i<myHEIGHT; i++) {
                for(j=0; j<myWIDTH; j++) {
                        fscanf(f, "%d ", &myFormiga[i][j]);
                        fscanf(f, "%d ", &myCasa[i][j]);
                        fscanf(f, "%d ", &myComida[i][j]);
                        fscanf(f, "%d ", &myF1[i][j]);
                        fscanf(f, "%d ", &myObstaculo[i][j]);
                }
        }

        fscanf(f, "%d ", &myid_formigas);

        for(i=0; i<myid_formigas; i++) {
                fscanf(f, "%d %d %d %d %d %d %d %d %d %d %d %d ", &myF[i].x, &myF[i].y, &myF[i].angulo, &myF[i].dirx, &myF[i].diry, &myF[i].erroxy, &myF[i].estado, &myF[i].contador[0], &myF[i].contador[1], &myF[i].contador[2], &myF[i].contador[3], &myF[i].contador[4]);
        }

        fclose(f);

        RefreshChao();
}
//---------------------------------------------------------------------------

void __fastcall TForm1::Button1Click(TObject *Sender)
{
        Reset();
        RefreshChao();        
}
//---------------------------------------------------------------------------

void __fastcall TForm1::ChaoMouseUp(TObject *Sender, TMouseButton Button,
      TShiftState Shift, int X, int Y)
{
        if (SpeedButton6->Down) {
                DesenhandoObstaculo = false;
        }
        if (SpeedButton5->Down) {
                DesenhandoFero = false;
        }
}
//---------------------------------------------------------------------------

void __fastcall TForm1::ChaoMouseMove(TObject *Sender, TShiftState Shift,
      int X, int Y)
{
        if (DesenhandoObstaculo) {
                myObstaculo[min(max(X-1, 0), myWIDTH-1)][min(max(Y-1, 0), myHEIGHT-1)] = 1;
                myObstaculo[min(max(X-1, 0), myWIDTH-1)][min(max(Y+0, 0), myHEIGHT-1)] = 1;
                myObstaculo[min(max(X-1, 0), myWIDTH-1)][min(max(Y+1, 0), myHEIGHT-1)] = 1;
                myObstaculo[min(max(X+0, 0), myWIDTH-1)][min(max(Y-1, 0), myHEIGHT-1)] = 1;
                myObstaculo[min(max(X+0, 0), myWIDTH-1)][min(max(Y+0, 0), myHEIGHT-1)] = 1;
                myObstaculo[min(max(X+0, 0), myWIDTH-1)][min(max(Y+1, 0), myHEIGHT-1)] = 1;
                myObstaculo[min(max(X+1, 0), myWIDTH-1)][min(max(Y-1, 0), myHEIGHT-1)] = 1;
                myObstaculo[min(max(X+1, 0), myWIDTH-1)][min(max(Y+0, 0), myHEIGHT-1)] = 1;
                myObstaculo[min(max(X+1, 0), myWIDTH-1)][min(max(Y+1, 0), myHEIGHT-1)] = 1;
                RefreshChao();
        }
        if (DesenhandoFero) {
                myF1[min(max(X-1, 0), myWIDTH-1)][min(max(Y-1, 0), myHEIGHT-1)] += StrToInt(Edit15->Text);
                myF1[min(max(X-1, 0), myWIDTH-1)][min(max(Y+0, 0), myHEIGHT-1)] += StrToInt(Edit15->Text);
                myF1[min(max(X-1, 0), myWIDTH-1)][min(max(Y+1, 0), myHEIGHT-1)] += StrToInt(Edit15->Text);
                myF1[min(max(X+0, 0), myWIDTH-1)][min(max(Y-1, 0), myHEIGHT-1)] += StrToInt(Edit15->Text);
                myF1[min(max(X+0, 0), myWIDTH-1)][min(max(Y+0, 0), myHEIGHT-1)] += StrToInt(Edit15->Text);
                myF1[min(max(X+0, 0), myWIDTH-1)][min(max(Y+1, 0), myHEIGHT-1)] += StrToInt(Edit15->Text);
                myF1[min(max(X+1, 0), myWIDTH-1)][min(max(Y-1, 0), myHEIGHT-1)] += StrToInt(Edit15->Text);
                myF1[min(max(X+1, 0), myWIDTH-1)][min(max(Y+0, 0), myHEIGHT-1)] += StrToInt(Edit15->Text);
                myF1[min(max(X+1, 0), myWIDTH-1)][min(max(Y+1, 0), myHEIGHT-1)] += StrToInt(Edit15->Text);
                RefreshChao();
        }
}
//---------------------------------------------------------------------------




