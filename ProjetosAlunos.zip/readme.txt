O guia de instalação se encontra no link:
https://www.dropbox.com/s/rf7vkawx9ite01r/Guia%20OpenGL.pdf?dl=0

E também tem slides e códigos de exemplo no site (Aulas práticas):
https://sites.google.com/site/computacaograficaicmc2017t2/


Para compilar o código do braço robótico basta estar na pasta (já extraida) e digitar "make" no terminal.
Para rodar digite o comando "make run". Ambos comandos sem aspas. (instruções no próprio programa)

Caso deseje compilar um código com um único arquivo .c basta incluir as seguintes flags "-lglut -lGLU -lGL -lm".

Ficaria assim: "gcc -o exemplo exemplo.c -lglut -lGLU -lGL -lm".

Caso tenha alguma dúvida fico disponível: luiz.miyazaki@usp.br