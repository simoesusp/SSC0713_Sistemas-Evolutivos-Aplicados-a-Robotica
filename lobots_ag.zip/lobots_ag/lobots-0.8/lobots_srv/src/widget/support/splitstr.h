#ifndef splitstr_H
#define splitstr_H

void splitstr(const char *orig, const char sep, char *str1, char *str2);


#endif