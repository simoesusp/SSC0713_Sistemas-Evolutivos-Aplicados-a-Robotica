#include "buttonconnectable.h"

ButtonConnectable::ButtonConnectable() {
}
