#ifndef string_exec_H
#define string_exec_H

#include <string>

std::string exec(const char* cmd);

#endif