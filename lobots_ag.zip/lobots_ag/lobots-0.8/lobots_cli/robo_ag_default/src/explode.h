#ifndef explode_H
#define explode_H

#include <iostream>
#include <vector>
#include <string>

using namespace std;

vector<string> explode( const string &delimiter, const string &explodeme); 


#endif