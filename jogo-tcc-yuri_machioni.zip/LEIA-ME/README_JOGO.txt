� necess�rio ter ambas chipmunk e SDL2 devidamente instaladas e linkadas para compilar o c�digo.
a vers�o da chipmunk utilizada foi a 6.2.1
a vers�o da SDL2 utilizada foi a 2.0.1
a vers�o da SDLimage utilizada foi a 2.0.0
neste mesmo diret�rio h� outros .txt com algumas dicas para compilar as bibliotecas.

Para execu��o do jogo basta ter as DLLs contidas nesta pasta no mesmo diret�rio do .exe
o jogo foi testado em Windows 7 em alguns hardwares diferentes, a apresenta taxa de quadros consistente

Os controles do jogo s�o:

->  move personagem para a direita (seta para a direita)
<-  move personagem para a esquerda (seta para a esquerda)
^   mira arma para cima (seta para cima)
3   dispara arma
2   pula
R   reseta partida
0   ganha vida

O jogo n�o t�m condi��o de vit�ria nem limite de gera��es.
Caso o jogador perca toda a vida, a partida � resetada (inclusive inimigos).

No caso de algum problema ou d�vida envie um email para yurimachioni@gmail.com 