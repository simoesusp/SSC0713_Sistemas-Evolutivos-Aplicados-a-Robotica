

int collidePlayerGround(cpArbiter* arb, cpSpace* space, void* unused){
    inAir = true;
    return 0;
}
