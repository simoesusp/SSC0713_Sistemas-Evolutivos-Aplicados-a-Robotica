ZantArena

This game was programmed by Marcio Kassouf Crocomo.
Special thanks to:
Francisco Krug, for the musics composed for this game.
Reiner Prokein, for the images used in this game, downloaded from: http://reinerstileset.4players.de/

This game is still in development, this is a beta version. Report bugs and suggestions to: marciokc at gmail.com. If reporting bugs, please send the "log.txt" file (created by your last game) attached to your e-mail.

Description of the game:
	This game is based in the open D20 system : http://www.wizards.com/default.asp?x=d20/welcome
Two teams fight each other in a arena. Each team is composed by 2 fighters and 2 wizards. The goal of the player is to elaborate strategies used by his team. To achieve this objective, the player must fill a script file ("input1.txt" for the blue team, or "input2.txt" for the red team). To run the game, just run the "ZantArena.exe" file

How to write a script?
	The scripts should follow the "inputModel.txt" that will be explained here:
	warrior1:  This word shall not be replaced or deleted
	warrior2:  This word shall not be replaced or deleted
	mage1:     This word shall not be replaced or deleted
	mage2:     This word shall not be replaced or deleted
	<action>   It can be replaced by any word of the file "actionList.txt"
	<target>   It can be replaced by any word of the file "targetList.txt"
	potions:   this shall not be replaced
	<potion>   It can be replaced by any word of the file "potionList.txt"
	spells:	   this shall not be replaced or deleted
	<spell>	   It can be replaced by any spell of the file "spellList.txt"
	end 	   This word shall not be replaced or deleted

Note that you shall save your script with the name input1.txt for the blue team, or input2.txt for the red team. If the game does not start after running the file "ZantArena.exe", there are errors in your script that you can find in "errors.txt"
